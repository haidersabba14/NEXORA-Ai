import { chromium } from "playwright-core";
import { mkdir } from "node:fs/promises";
import assert from "node:assert/strict";
const base = process.env.TEST_BASE_URL || "http://127.0.0.1:8787";
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
  headless: true,
  args: [
    "--no-sandbox",
    "--disable-dev-shm-usage",
    "--proxy-bypass-list=localhost;127.0.0.1",
  ],
});
const page = await browser.newPage({
  viewport: { width: 390, height: 844 },
  deviceScaleFactor: 1,
  isMobile: true,
  hasTouch: true,
});
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
await mkdir("artifacts", { recursive: true });
try {
  await page.goto(base, { waitUntil: "domcontentloaded" });
  await page.getByRole("heading", { name: /أفكار بلا حدود/ }).waitFor();
  assert.equal(await page.evaluate(() => document.documentElement.dir), "rtl");
  assert.ok(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
    "No horizontal overflow on phone",
  );
  await page.screenshot({
    path: "artifacts/nexora-mobile-ar.png",
    fullPage: true,
  });
  await page.getByRole("button", { name: "Open menu" }).click();
  await page
    .getByRole("button", { name: "مقارنة النماذج", exact: false })
    .first()
    .click();
  await page.getByRole("heading", { name: "لا تكتفِ بإجابة واحدة." }).waitFor();
  await page.getByPlaceholder("اسأل، ابتكر، أو فكّر بصوت عالٍ…").fill("مرحبا");
  await page.getByRole("button", { name: "Send message" }).click();
  await page.getByRole("heading", { name: "أهلًا بك في NEXORA" }).waitFor();
  await page
    .getByText("خدمة الحسابات لم تُضبط بعد.", { exact: false })
    .waitFor();
  await page.getByRole("button", { name: "EN", exact: true }).click();
  assert.equal(await page.evaluate(() => document.documentElement.dir), "ltr");
  await page.getByRole("button", { name: "Open menu" }).click();
  await page.getByRole("button", { name: "Overview", exact: true }).click();
  await page.getByRole("heading", { name: /Think beyond/ }).waitFor();
  await page.setViewportSize({ width: 1440, height: 1080 });
  await page.screenshot({
    path: "artifacts/nexora-desktop-en.png",
    fullPage: true,
  });
  assert.ok(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
    "No desktop overflow",
  );
  await page.getByRole("button", { name: "Privacy", exact: true }).click();
  await page
    .getByRole("heading", { name: "Privacy policy", exact: true })
    .waitFor();
  await page.getByRole("button", { name: "Terms", exact: true }).click();
  await page
    .getByRole("heading", { name: "Terms of service", exact: true })
    .waitFor();
  await page
    .getByRole("button", { name: "Capability center", exact: true })
    .click();
  await page
    .getByRole("heading", { name: "Capability center", exact: true })
    .waitFor();
  await page.getByRole("button", { name: "File studio", exact: true }).click();
  await page.getByLabel("Document title").fill("NEXORA test");
  await page
    .getByLabel("Content", { exact: true })
    .fill("Real file generated in a browser.");
  const pdfEvent = page.waitForEvent("download");
  await page.getByRole("button", { name: "Download PDF", exact: true }).click();
  const pdf = await pdfEvent;
  assert.ok(pdf.suggestedFilename().endsWith(".pdf"));
  await page.screenshot({
    path: "artifacts/nexora-file-studio-en.png",
    fullPage: true,
  });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForFunction(
    () => document.querySelector(".sidebar").getBoundingClientRect().right <= 1,
  );
  assert.ok(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
    "No tools overflow on phone",
  );
  await page.screenshot({
    path: "artifacts/nexora-file-studio-mobile.png",
    fullPage: true,
  });
  assert.deepEqual(errors, [], "No uncaught browser errors");
  console.log(
    "PASS: mobile RTL, phone overflow, navigation, compare auth gate, honest setup state, English LTR, desktop, privacy, terms, capability auth gate, real PDF browser download, tools phone overflow, browser errors.",
  );
} finally {
  await browser.close();
}
