// Run only in a trusted executor with secrets injected as environment variables.
// Secret values travel to Wrangler over stdin and never enter files or arguments.
import { spawnSync } from "node:child_process";
import { readFileSync, writeFileSync, existsSync } from "node:fs";
const required = [
  "CLOUDFLARE_API_TOKEN",
  "CLOUDFLARE_ACCOUNT_ID",
  "SUPABASE_URL",
  "SUPABASE_ANON_KEY",
  "OPENAI_API_KEY",
  "GEMINI_API_KEY",
  "DEEPSEEK_API_KEY",
  "ANTHROPIC_API_KEY",
  "TURNSTILE_SITE_KEY",
  "TURNSTILE_SECRET_KEY",
  "MODEL_CONFIG_JSON",
  "RECOVERY_PEPPER",
  "SUPABASE_SERVICE_ROLE_KEY",
  "GLOBAL_DAILY_USD",
  "GLOBAL_MONTHLY_USD",
];
const missing = required.filter((k) => !process.env[k]);
if (missing.length)
  throw Error("Missing secure configuration: " + missing.join(", "));
for (const name of ["GLOBAL_DAILY_USD", "GLOBAL_MONTHLY_USD"])
  if (
    !Number.isFinite(Number(process.env[name])) ||
    Number(process.env[name]) <= 0
  )
    throw Error(name + " must be an explicitly approved positive USD budget.");
const config = JSON.parse(process.env.MODEL_CONFIG_JSON);
for (const id of ["openai", "gemini", "deepseek", "anthropic"]) {
  if (!config[id]?.model || !(config[id].input > 0) || !(config[id].output > 0))
    throw Error(
      "Model and conservative per-million-token prices required for " + id,
    );
}
if (process.env.RECOVERY_PEPPER.length < 32)
  throw Error("RECOVERY_PEPPER must contain at least 32 random characters.");
const account = process.env.CLOUDFLARE_ACCOUNT_ID;
if (!/^[a-f0-9]{32}$/i.test(account))
  throw Error("Invalid Cloudflare account ID");
async function cf(path, method = "GET", body, accountScoped = true) {
  const response = await fetch(
    `https://api.cloudflare.com/client/v4${accountScoped ? "/accounts/" + account : ""}${path}`,
    {
      method,
      headers: {
        Authorization: `Bearer ${process.env.CLOUDFLARE_API_TOKEN}`,
        "Content-Type": "application/json",
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
      signal: AbortSignal.timeout(30000),
    },
  );
  const data = await response.json();
  if (!response.ok || !data.success)
    throw Error(
      "Cloudflare API " +
        method +
        " " +
        path +
        " failed (HTTP " +
        response.status +
        "). Check token permissions in the dashboard.",
    );
  return data.result;
}
function run(args, input) {
  const result = spawnSync(
    process.execPath,
    ["node_modules/wrangler/bin/wrangler.js", ...args],
    {
      stdio: input ? ["pipe", "inherit", "inherit"] : "inherit",
      input,
      env: { ...process.env, WRANGLER_SEND_METRICS: "false" },
    },
  );
  if (result.status !== 0) throw Error("Wrangler operation failed: " + args[0]);
}
const project = JSON.parse(readFileSync("worker/wrangler.jsonc", "utf8"));
const target = JSON.parse(readFileSync("deployment.json", "utf8"));
const origin = target.origin;
if (
  !/^https:\/\/[a-z0-9.-]+$/.test(origin) ||
  !target.customDomains.includes(new URL(origin).hostname)
)
  throw Error("Invalid production domain configuration in deployment.json.");
// Fail before creating D1 or deploying if the domain is not active in this account.
for (const domain of target.customDomains) {
  const zones = await cf(
    "/zones?name=" + encodeURIComponent(domain) + "&account.id=" + account,
    "GET",
    undefined,
    false,
  );
  if (!zones.some((zone) => zone.name === domain && zone.status === "active"))
    throw Error(
      "Domain " +
        domain +
        " must be an active Cloudflare zone in this account. Resolve any registrar hold and verify ownership first; no domain is bought or transferred by this script.",
    );
}
project.routes = target.customDomains.map((pattern) => ({
  pattern,
  custom_domain: true,
}));
project.workers_dev = target.workersDev;
project.triggers = { crons: ["0 * * * *"] };
if (process.env.STUDIO_CONFIG_JSON && !process.env.R2_BUCKET_NAME)
  throw Error(
    "Studio generation requires an existing private R2_BUCKET_NAME; no bucket billing is activated automatically.",
  );
if (process.env.R2_BUCKET_NAME) {
  const bucket = process.env.R2_BUCKET_NAME;
  if (!/^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$/.test(bucket))
    throw Error("Invalid R2 bucket name");
  await cf("/r2/buckets/" + encodeURIComponent(bucket));
  project.r2_buckets = [{ binding: "BUCKET", bucket_name: bucket }];
}
if (!!process.env.BRAVE_SEARCH_API_KEY !== !!process.env.SEARCH_CONFIG_JSON)
  throw Error(
    "Web research requires both BRAVE_SEARCH_API_KEY and SEARCH_CONFIG_JSON.",
  );
const authOrigin = new URL(process.env.SUPABASE_URL);
if (
  authOrigin.protocol !== "https:" ||
  !authOrigin.hostname.endsWith(".supabase.co")
)
  throw Error("Use the hosted Supabase HTTPS project URL.");
const jwks = await fetch(
  process.env.SUPABASE_URL + "/auth/v1/.well-known/jwks.json",
  { signal: AbortSignal.timeout(10000) },
);
const keyset = await jwks.json();
if (!jwks.ok || !keyset.keys?.some((x) => ["ES256", "RS256"].includes(x.alg)))
  throw Error(
    "Supabase requires an active asymmetric ES256 or RS256 JWT signing key.",
  );
if (!existsSync("out/index.html"))
  throw Error("Run npm run build before deployment.");
const list = await cf("/d1/database?per_page=100");
let db = list.find((x) => x.name === "nexora");
if (!db) db = await cf("/d1/database", "POST", { name: "nexora" });
project.d1_databases[0].database_id = db.uuid;
project.vars = {
  APP_ORIGIN: origin,
  GLOBAL_DAILY_USD: process.env.GLOBAL_DAILY_USD,
  GLOBAL_MONTHLY_USD: process.env.GLOBAL_MONTHLY_USD,
};
const path = "worker/wrangler.deploy.json";
writeFileSync(path, JSON.stringify(project, null, 2) + "\n");
run(["d1", "migrations", "apply", "nexora", "--remote", "--config", path]);
const secrets = {};
for (const key of required.filter(
  (k) =>
    ![
      "CLOUDFLARE_API_TOKEN",
      "CLOUDFLARE_ACCOUNT_ID",
      "GLOBAL_DAILY_USD",
      "GLOBAL_MONTHLY_USD",
    ].includes(k),
))
  secrets[key] = process.env[key];
for (const key of [
  "STUDIO_CONFIG_JSON",
  "BRAVE_SEARCH_API_KEY",
  "SEARCH_CONFIG_JSON",
])
  if (process.env[key]) secrets[key] = process.env[key];
run(
  ["deploy", "--config", path, "--secrets-file", "/dev/stdin"],
  JSON.stringify(secrets),
);
let healthy = false;
for (let attempt = 1; attempt <= 6; attempt++) {
  try {
    const health = await fetch(origin + "/api/health", {
      signal: AbortSignal.timeout(10000),
    });
    const data = await health.json();
    healthy = health.ok && data.database === "connected";
  } catch {
    /* DNS and TLS may still be propagating; never disable certificate verification. */
  }
  if (healthy) break;
  console.log(`Waiting for verified DNS/TLS/backend health (${attempt}/6)...`);
  if (attempt < 6) await new Promise((resolve) => setTimeout(resolve, 5000));
}
if (!healthy)
  throw Error(
    "Worker upload completed, but the custom domain's HTTPS/D1 health is not verified. Check Cloudflare domain validation and certificate status before claiming the site is live.",
  );
console.log("Verified deployed backend and D1 health: " + origin);
console.log(
  "Next: complete the real account, TOTP, OAuth, recovery and provider chat acceptance checklist in docs/ACCEPTANCE.md.",
);
