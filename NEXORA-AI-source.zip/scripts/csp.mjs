import { readdir, readFile, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
const hashes = new Set();
async function scan(dir) {
  for (const file of await readdir(dir, { withFileTypes: true })) {
    const path = dir + "/" + file.name;
    if (file.isDirectory()) await scan(path);
    else if (path.endsWith(".html")) {
      const html = await readFile(path, "utf8");
      for (const match of html.matchAll(
        /<script\b([^>]*)>([\s\S]*?)<\/script>/g,
      )) {
        if (!/\bsrc=/.test(match[1]) && match[2])
          hashes.add(createHash("sha256").update(match[2]).digest("base64"));
      }
    }
  }
}
await scan("out");
await writeFile(
  "worker/src/csp.generated.json",
  JSON.stringify([...hashes], null, 2) + "\n",
);
console.log(`CSP: hashed ${hashes.size} inline scripts for this build.`);
