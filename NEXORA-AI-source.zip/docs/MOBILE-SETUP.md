# إكمال NEXORA من الجوال

لا تحتاج كمبيوتر. الدومين الرئيسي المطلوب هو **https://nexoraai.com**، مضبوط في `deployment.json`. افحص ملكيته وحالة المسجّل قبل إعداد بقية الخدمات. افتح الروابط من متصفح الجوال، واستخدم «موقع سطح المكتب» فقط إذا أخفى GitHub أو Cloudflare خيارًا إداريًا.

## 0. حالة الدومين nexoraai.com

بتاريخ 25 أكتوبر 2026 أظهرت بيانات Verisign RDAP أن الدومين مسجل لدى **Squarespace Domains II LLC**، وحالته **clientHold**. وأعاد فحص DNS العام NXDOMAIN. هذا ليس دليلًا على ملكية المستخدم، ولا يعني أن الدومين متاح للشراء.

إذا كان الدومين ملكك، افتح https://account.squarespace.com/domains وأكمل متطلبات المسجّل لرفع التعليق، ثم أضف الدومين إلى حساب Cloudflare واضبط nameservers حسب ما يعرضه حسابك. لا يمكن للوكيل معرفة سبب التعليق أو رفعه دون صلاحية حساب المسجّل. إن لم يكن ملكك، يلزم إذن المالك؛ لن يشتريه هذا المشروع أو ينقله تلقائيًا.

سكربت النشر يتحقق من وجود zone نشطة في حساب Cloudflare، ويضيف **Custom Domain route** للدومين نفسه. ضبط APP_ORIGIN وحده لا يربط DNS. HTTPS يتطلب نجاح التحقق وإصدار الشهادة بواسطة Cloudflare.

## 1. Cloudflare

- افتح https://dash.cloudflare.com/ وأنشئ حسابًا أو سجّل الدخول.
- افتح Workers & Pages واضبط نطاق `workers.dev` للحساب إن لم يكن موجودًا. لا تحتاج شراء دومين.
- انسخ **Account ID** من لوحة الحساب، وأنشئ API Token محدودًا للحساب بصلاحيات **Workers Scripts: Edit** و**D1: Edit** و**Zone: Read** و**Workers Routes: Edit** للدومين المحدد. لا ترسل الرمز في المحادثة.
- أنشئ Turnstile widget للمضيف الذي ستستخدمه، مثل `nexoraai.com`. احفظ Site Key وSecret Key بشكل آمن. فعل CAPTCHA نفسه في Supabase.
- استخدم الخطط المجانية حيث تناسبك. قد يحتاج ضغط الاستخدام ترقية لاحقًا؛ لا يتم تفعيل خطة مدفوعة تلقائيًا.

## 2. Supabase

- افتح https://supabase.com/dashboard وأنشئ مشروعًا على الخطة المناسبة لك.
- من Project Settings / API احفظ Project URL وanon key وservice_role key. الأخير سري جدًا ويستخدم فقط لاسترداد عوامل المصادقة؛ لا يوضع في الواجهة.
- Authentication / URL Configuration: اضبط Site URL على `https://nexoraai.com`، وأضف `https://nexoraai.com/` و`https://nexoraai.com/?reset=1` إلى Redirect URLs. احذف عناوين المعاينة المؤقتة عند عدم الحاجة.
- فعل Email/Password، وتأكيد البريد، وكلمات مرور 12 حرفًا على الأقل. اضبط SMTP موثوقًا للبريد الإنتاجي، مع تحديد حصص ومعدلات مناسبة. بريد Supabase الافتراضي مقيّد وقد لا يخدم المستخدمين العامين.
- Authentication / MFA: فعل TOTP؛ واجهة التطبيق تُلزم كل مستخدم بإعداده قبل بياناته. التحقق في Worker إلزامي أيضًا.
- Authentication / Signing Keys: استخدم مفتاح JWT غير متماثل **ES256 أو RS256** منشورًا في JWKS. مفاتيح HS256 القديمة مرفوضة عمدًا، ولا تُرسل JWT secret إلى المتصفح.
- Authentication / Bot protection: فعل Turnstile بمفتاحه السري. طلبات التسجيل والدخول والاسترداد ترسل captchaToken.
- Authentication / Rate Limits: اضبط حدود البريد وتسجيل الدخول/الرموز. هذه الحماية ضرورية لأن Supabase Auth يمكن استدعاؤه مباشرة.
- اختياريًا فعل Google provider بعد إنشاء OAuth Client في https://console.cloud.google.com/apis/credentials وإضافة عنوان callback الذي يعرضه Supabase بالضبط. خزّن Google Client Secret في لوحة Supabase فقط.

## 3. مزودو AI

أنشئ مفاتيح خادمية من لوحات OpenAI وGoogle AI Studio وDeepSeek وAnthropic، وفعّل حدود الإنفاق لدى كل مزود. الاشتراك في ChatGPT أو Gemini أو Claude للمحادثة **لا يضمن رصيد API**. بعض المزودين يتطلب رصيدًا مدفوعًا؛ لا تشترِ رصيدًا إلا باختيارك. لا يفعّل المشروع فوترةً ولا يشتري رصيدًا.

اختر model IDs متاحة لحسابك من وثائق/قائمة نماذج كل مزود. `MODEL_CONFIG_JSON` يلزم أربعة إدخالات، وأسعار **USD لكل مليون رمز** موجبة ومحافظة تعكس النموذج والحساب. مثال الشكل فقط (يجب استبدال أسماء النماذج والأسعار قبل التشغيل؛ الأرقام ليست تسعيرة مزود):

```json
{
  "openai": { "model": "YOUR_OPENAI_MODEL", "input": 1, "output": 2 },
  "gemini": { "model": "YOUR_GEMINI_MODEL", "input": 1, "output": 2 },
  "deepseek": { "model": "YOUR_DEEPSEEK_MODEL", "input": 1, "output": 2 },
  "anthropic": { "model": "YOUR_ANTHROPIC_MODEL", "input": 1, "output": 2 }
}
```

لـClaude اختر نموذجًا يعمل دون extended thinking؛ ولـGemini تأكد من عدم تجاوز reasoning/thinking للحدود. تُحسب رموز التفكير إذا أبلغ المزود عنها. الحجوزات تعتمد على الحد الأقصى للإخراج وعلى حجم سياق UTF-8 المحافظ؛ لا تستخدم تسعيرًا أقل من تكلفة المزود الفعلية. حدود الميزانية هنا ضابط تطبيقي وليست حد فوترة تعاقديًا لدى المزود.

## 4. GitHub Secrets

المستودع: https://github.com/haidersabba14/NEXORA-Ai

Settings → Secrets and variables → Actions → New repository secret:

```
CLOUDFLARE_API_TOKEN
CLOUDFLARE_ACCOUNT_ID
SUPABASE_URL
SUPABASE_ANON_KEY
SUPABASE_SERVICE_ROLE_KEY
OPENAI_API_KEY
GEMINI_API_KEY
DEEPSEEK_API_KEY
ANTHROPIC_API_KEY
TURNSTILE_SITE_KEY
TURNSTILE_SECRET_KEY
RECOVERY_PEPPER
```

`RECOVERY_PEPPER` سر عشوائي قوي، لا يقل عن 32 حرفًا، أنشئه بمولد كلمات مرور آمن. تغييره يبطل رموز الاسترداد القائمة.

في تبويب Variables أضف:

- `MODEL_CONFIG_JSON`: إعداد النماذج والأسعار.
- `GLOBAL_DAILY_USD`: ميزانية عامة يومية تختارها بالدولار.
- `GLOBAL_MONTHLY_USD`: ميزانية عامة شهرية تختارها بالدولار.

الدومين مضبوط مسبقًا في `deployment.json`؛ لا تحتاج متغير APP_ORIGIN في GitHub. يبني سكربت النشر APP_ORIGIN وCustom Domain route من هذا الملف ويعطّل workers.dev في الإنتاج.

لا تستخدم بادئة `NEXT_PUBLIC_` لأي سر. `SUPABASE_URL` وanon key وTurnstile Site Key عامة بطبيعتها وتُرسل للمتصفح، بينما مفاتيح AI وservice_role وTurnstile Secret لا تُرسل.

## 5. شغّل النشر

بعد وجود تغييرات التطبيق وملفات Workflow على الفرع الرئيسي، افتح Actions → **Deploy NEXORA to Cloudflare** → Run workflow. إن كانت التغييرات على Pull Request فقط فادمجها أولًا بعد مراجعة الاختبارات. النشر يدوي عمدًا حتى لا يستهلك ميزانية أو يستخدم أسرارًا لمجرد رفع الكود.

العملية تتوقف قبل أي نشر عند غياب الإعدادات. بعد نجاحها يظهر الرابط الحقيقي في نهاية سجل النشر، وتتحقق من الخادم وD1. هذا لا يُعد اختبار محادثة أو تسجيل دخول؛ أكمل [اختبارات القبول](ACCEPTANCE.md).

لإعداد ميزات البحث والصور والفيديو وR2 والجدولة راجع [دليل القدرات الإضافية](CAPABILITIES.md). هذه الإعدادات منفصلة عن مفاتيح المحادثة ولا تُفعّل خدمات مدفوعة تلقائيًا.

## 6. تعيين مسؤول

أنشئ حسابك عبر الموقع، فعّل البريد وTOTP، ثم من أداة Supabase الإدارية الموثوقة اضبط **app_metadata.role = "admin"** لهذا المستخدم. لا تستخدم user_metadata، ولا تضع service_role في SQL أو ملف عام. سيُقرأ الدور من Supabase على الخادم. إذا استعملت API الإدارة فليكن عبر عميل موثوق وبسر خادمي؛ لا تحتاج مشاركته في المحادثة.

إذا تعذر إعداد الأسرار من الجوال، استخدم إعدادات البيئة السحابية الآمنة المتصلة بهذه المهمة ثم أخبر الوكيل بأسماء الإعدادات الجاهزة فقط. لا تشارك قيمها.
