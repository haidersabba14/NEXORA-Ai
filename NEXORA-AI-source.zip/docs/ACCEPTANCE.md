# Live acceptance checklist — pending credentials and deployment

These checks require real configured accounts. Local tests and successful builds do not satisfy them. Do not mark a check complete without evidence.

- [ ] `/api/health` on the deployed HTTPS URL returns 200 and `database: connected`.
- [ ] `/api/config` exposes only public configuration; AI/service/Turnstile secret values never occur in JS assets, HTML, API bodies or logs.
- [ ] Register a real email, receive confirmation, reject unconfirmed sign-in/data access, and verify reset-password delivery and redirect.
- [ ] TOTP: enroll using QR with Google or Microsoft Authenticator, reject a wrong six-digit code, and obtain AAL2 with the correct code.
- [ ] Call a protected endpoint directly with no JWT, forged JWT, expired JWT and a valid AAL1 JWT: all must be rejected. Do not trust the UI gate alone.
- [ ] Confirm a real AAL2 account can create/reload/search/delete/export conversations across devices; a second account cannot read or delete them.
- [ ] Run connection checks for each configured model. A successful model metadata lookup is not proof of successful generation.
- [ ] Send a harmless real prompt to OpenAI, Gemini, DeepSeek and Claude individually; verify streamed provider text, saved results and provider-reported usage where available.
- [ ] Test the same prompt in comparison mode: four distinct requests, no cross-user grant reuse, each answer stored independently.
- [ ] Stop a response and test provider 429/authentication/stream interruption handling. No provider error body or credential may appear in user-visible errors.
- [ ] Verify current provider prices, maximum input/output costs and provider-side spending controls. At quota boundaries, simultaneous requests must be rejected before upstream generation.
- [ ] Verify Google OAuth after registering its exact Supabase callback and permitted Site URLs.
- [ ] At AAL2, generate and safely store recovery codes. Sign in with a fresh password at AAL1, redeem one code, reauthenticate and enroll a new TOTP. The consumed code must fail on reuse; an old session/refresh token must not regain access. This intentionally changes factors: test on a dedicated real test account.
- [ ] Global logout invalidates active data access and refresh sessions on a second device.
- [ ] Supabase's untrusted user_metadata cannot grant admin; legitimate app_metadata role can. Disable a test account and verify immediate API denial; change user limits and inspect actual recorded usage.
- [ ] Validate phone/tablet/desktop, Arabic/English, Markdown/code, copying, exporting, regeneration, profile changes and recovery-code downloads on the actual HTTPS origin.
- [ ] Approve operator contact details, policy text, retention/backups and incident recovery; confirm no paid plan was activated by automation.

Live provider calls can consume existing API credits. No script here automatically buys credits or enables billing.

## Expanded live checks

- [ ] In supported browsers, explicitly allow microphone access, dictate, send a real model request and play speech; stop both input and output. Verify unsupported-browser messaging and privacy consent.
- [ ] Analyze a benign real screenshot with configured vision models. DeepSeek and unsupported image types/sizes must be rejected; image bytes must not appear in persisted chat rows or logs.
- [ ] Enable Brave research with its actual key and price, confirm real sources and accounted search fee, and reject missing configuration without any external call.
- [ ] Opt in to memory, inspect how preferences affect a real reply, switch off, then delete. A second account must never see the first account's settings.
- [ ] Run a real bounded agent council and confirm each paid call is reserved/recorded separately. Cancel, reload and reconcile an interrupted run; no result may claim actual execution/training without tools.
- [ ] Configure a private existing R2 bucket and explicit generation ceilings. Generate an actual image and actual video, poll, download, check another user cannot access either, and validate billed estimates against provider records.
- [ ] Deploy Cron, create a small real scheduled task, confirm one run per claim, in-app result delivery, pause/delete, quotas and disabled-user skipping. This does not establish external server monitoring or email notification.
- [ ] Download and open Arabic PDF, editable PPTX and XLSX on the user's phone. Check unsupported-glyph feedback and formula-like values stay text.
