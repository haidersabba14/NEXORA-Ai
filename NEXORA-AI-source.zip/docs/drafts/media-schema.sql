-- Draft for the parent to append as a NEW migration; do not alter applied migrations.
-- Media billing rows remain in requests if users delete their generated artifact.
CREATE TABLE studio_jobs (
 id TEXT PRIMARY KEY,
 user_id TEXT NOT NULL REFERENCES users(id),
 request_id TEXT NOT NULL REFERENCES requests(id),
 conversation_id TEXT REFERENCES conversations(id) ON DELETE SET NULL,
 kind TEXT NOT NULL CHECK(kind IN ('image','video')),
 provider TEXT NOT NULL,
 model TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'running' CHECK(status IN ('running','complete','error')),
 operation_name TEXT,
 object_key TEXT,
 content_type TEXT,
 byte_length INTEGER,
 max_bytes INTEGER NOT NULL,
 error_code TEXT,
 poll_locked_until INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);
CREATE INDEX studio_jobs_owner ON studio_jobs(user_id,created_at);
