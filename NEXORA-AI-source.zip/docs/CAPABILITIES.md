# Expanded NEXORA capabilities

All integrations below still need the real accounts and live acceptance checks. A source implementation and fixture tests are not proof of a deployed service.

| Requested capability       | Implemented behavior                                                                            | Boundary / remaining setup                                                                             |
| -------------------------- | ----------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------ |
| Deep thinking              | Dedicated analysis mode asks the chosen model to compare options, assumptions and uncertainty   | Prompt-driven analysis; no claim of hidden reasoning access                                            |
| Website/application coding | Coding mode and App Factory/Tool Creator pipelines produce code, tests and deployment proposals | Does not run generated code or deploy arbitrary apps                                                   |
| Independent agent          | Multi-stage runs with saved outputs, cancellation, quota per model call                         | No arbitrary browser/server execution                                                                  |
| Images                     | Official OpenAI Images API, private R2 artifact download                                        | Image model/key, R2 and explicit conservative price needed                                             |
| Video                      | Official Google Veo long-running generation and owner-only polling/download                     | Veo model availability, API credit, R2 and price needed                                                |
| Voice                      | Browser microphone dictation and browser speech synthesis                                       | Turn-based, depends on browser/OS support; not a full-duplex Realtime API                              |
| Vision                     | PNG/JPEG sent to configured OpenAI/Gemini/Claude models; text documents inserted into prompt    | No DeepSeek vision, no direct PDF parsing; image not retained in history                               |
| Internet research          | Brave Search snippets provided to the model, URLs appended to response                          | Requires a Brave API key and explicit per-query price                                                  |
| PowerPoint / PDF / Excel   | Real local PPTX/PDF/XLSX downloads, Arabic PDF font, bounded CSV parser                         | Content comes from user input or pasted real AI output                                                 |
| Automation                 | User-managed hourly-to-weekly prompt or internal DB-health jobs on Cloudflare Cron              | In-app results only; no external message/service actions                                               |
| Memory                     | Opt-in preferences, read/update/delete and use in owned chat/scheduled jobs                     | No automatic extraction or cross-user memory                                                           |
| Multiple models            | Four official text API adapters, switching and side-by-side comparison                          | All provider accounts/models need live tests                                                           |
| HIVE MIND                  | Specialists critique and synthesize a task                                                      | 2–4 specialists, not dozens of autonomous tool-executing workers                                       |
| DIGITAL WORKFORCE          | Role-specific analysis workflow                                                                 | Plans/proposals; no virtual-company external authority                                                 |
| WORLD SIMULATION           | Scenario assumptions, sensitivities and uncertainty analysis                                    | LLM scenario analysis; not thousands of executed numeric simulations                                   |
| AI SCIENTIST               | Hypotheses, experiment proposals and evaluation                                                 | No claim of empirical discoveries or executed experiments                                              |
| INFINITE APP FACTORY       | Requirements, design, code and delivery-plan pipeline                                           | Sandbox/runtime/deployment integrations not connected                                                  |
| SELF-EVOLVING ENGINE       | Critique/evaluation template suggests improvements                                              | No automatic mutation of running code, prompts or model weights                                        |
| AI TOOL CREATOR            | Tool specifications and code proposals                                                          | No execution of untrusted code                                                                         |
| PREDICTIVE INTELLIGENCE    | Forecast assumptions, ranges and validation plan                                                | No guarantee or calibrated predictive model                                                            |
| UNIVERSAL CONTROL CENTER   | Current user's real D1 workspace snapshot                                                       | Cannot control disconnected servers/apps                                                               |
| AUTONOMOUS BUSINESS        | Operations/support/invoice workflow planning                                                    | No billing issuance, payment or store mutation                                                         |
| PRIVATE MODEL FACTORY      | Infrastructure boundary explained                                                               | Training/hosting open models is not implemented; needs a selected GPU/training stack and licensed data |
| ALWAYS-ON                  | Real Cloudflare Cron handler, safe task claims, saved results                                   | Requires deployment with Cron; no live schedule exists before deployment                               |
| GOD MODE                   | Name of the capability center                                                                   | Does not bypass permissions, budgets or service limits                                                 |

## Optional secure settings

In addition to the base settings in MOBILE-SETUP.md:

- `BRAVE_SEARCH_API_KEY`: server-only search key.
- `SEARCH_CONFIG_JSON`: e.g. `{"costPerRequestUsd":0.01}`. Example is not a provider price quote; set a conservative price for your plan.
- `STUDIO_CONFIG_JSON`: optional object with `image` and/or `video`. Each needs a supported model ID and `worstCaseUsd`; video also supports `durationSeconds` 4/6/8. Image generation is fixed to a single 1024×1024 low-quality PNG. Set a ceiling that covers the bounded prompt and actual provider pricing; code does not discover invoices automatically.
- `R2_BUCKET_NAME`: existing private bucket. Deployment verifies it and binds it as `BUCKET`; it does not create a bucket or enable R2 billing. Add R2 read/write token permissions for this bucket/account as required by Cloudflare.

The deployment adds an hourly `0 * * * *` Cron trigger. Nothing invokes an AI provider on schedule until an authenticated user creates a task, and every run still requires enabled budgets and configured models.
