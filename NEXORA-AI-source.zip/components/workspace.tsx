"use client";
import { useEffect, useRef, useState, useCallback } from "react";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import {
  Sparkles,
  Plus,
  Search,
  MessageSquare,
  Columns2,
  LayoutDashboard,
  Settings,
  ShieldCheck,
  ArrowUp,
  ArrowUpRight,
  Globe,
  Menu,
  X,
  Copy,
  Download,
  RotateCcw,
  Square,
  Code2,
  PenLine,
  Lightbulb,
  ChevronDown,
  LogOut,
  Trash2,
  Activity,
  Check,
  LockKeyhole,
  Command,
  Orbit,
} from "lucide-react";
import Markdown from "react-markdown";
import remarkGfm from "remark-gfm";
import Auth from "./auth";
import CapabilitiesHub from "./capabilities-hub";
import VoiceControls from "./voice-controls";
import VisionInput from "./vision-input";
import Turnstile from "./turnstile";
import {
  request,
  consumeEvents,
  providerNames,
  download,
  type Config,
  type Profile,
  type Message,
  type Conversation,
  type Provider,
} from "@/lib/client";
type Page =
  | "home"
  | "chat"
  | "compare"
  | "dashboard"
  | "settings"
  | "admin"
  | "auth"
  | "privacy"
  | "terms"
  | "lab";
const initialProviders: Provider[] = Object.keys(providerNames).map((id) => ({
  id,
  configured: false,
  model: null,
}));
const icons: Record<string, string> = {
  openai: "◉",
  gemini: "✦",
  deepseek: "≈",
  anthropic: "✳",
};
export default function Workspace() {
  const [ar, setAr] = useState(true),
    [page, setPage] = useState<Page>("home"),
    [menu, setMenu] = useState(false),
    [config, setConfig] = useState<Config | null>(null),
    [auth, setAuth] = useState<SupabaseClient | null>(null),
    [profile, setProfile] = useState<Profile | null>(null),
    [providers, setProviders] = useState<Provider[]>(initialProviders),
    [history, setHistory] = useState<Conversation[]>([]),
    [query, setQuery] = useState(""),
    [conversation, setConversation] = useState<string | null>(null),
    [messages, setMessages] = useState<Message[]>([]),
    [model, setModel] = useState("openai"),
    [chatMode, setChatMode] = useState("standard"),
    [image, setImage] = useState(""),
    [prompt, setPrompt] = useState(""),
    [busy, setBusy] = useState(false),
    [token, setToken] = useState(""),
    [captchaReset, setCaptchaReset] = useState(0),
    [notice, setNotice] = useState(""),
    [usage, setUsage] = useState<any>(null),
    [admin, setAdmin] = useState<any>(null),
    [compare, setCompare] = useState<Record<string, string>>({}),
    [compareIds, setCompareIds] = useState<string[]>([]),
    [name, setName] = useState(""),
    [avatar, setAvatar] = useState(""),
    [recovery, setRecovery] = useState<string[]>([]),
    [lastPrompt, setLastPrompt] = useState(""),
    [connected, setConnected] = useState<boolean | null>(null);
  const abort = useRef<AbortController | null>(null),
    bottom = useRef<HTMLDivElement>(null),
    promptRef = useRef<HTMLTextAreaElement>(null);
  const t = (a: string, e: string) => (ar ? a : e);
  const ready = profile?.aal === "aal2";
  const sync = useCallback(
    async (client: SupabaseClient | null = auth) => {
      if (!client) {
        setProfile(null);
        return;
      }
      const { data } = await client.auth.getSession();
      if (!data.session) {
        setProfile(null);
        setHistory([]);
        setMessages([]);
        return;
      }
      const p = await request<Profile>(client, "/session");
      setProfile(p);
      setName(p.name || "");
      setAvatar(p.avatar || "");
      if (p.aal === "aal2") {
        setHistory(await request(client, "/conversations"));
        const r = await request(client, "/providers");
        setProviders(r.providers);
      } else setPage("auth");
    },
    [auth],
  );
  useEffect(() => {
    const stored = localStorage.getItem("nexora-language");
    if (stored) setAr(stored === "ar");
    let off: (() => void) | undefined;
    request<Config>(null, "/config")
      .then(async (c) => {
        setConfig(c);
        setProviders(c.providers);
        if (c.supabaseUrl && c.supabaseAnonKey) {
          const client = createClient(c.supabaseUrl, c.supabaseAnonKey, {
            auth: {
              detectSessionInUrl: true,
              persistSession: true,
              autoRefreshToken: true,
              flowType: "pkce",
            },
          });
          setAuth(client);
          const { data } = client.auth.onAuthStateChange((event) => {
            if (event === "PASSWORD_RECOVERY") setPage("auth");
            setTimeout(() => {
              void sync(client).catch((e) => setNotice(e.message));
            }, 0);
          });
          off = () => data.subscription.unsubscribe();
          await sync(client);
        }
      })
      .catch(() => setNotice("SERVER_UNAVAILABLE"));
    fetch("/api/health")
      .then((r) => setConnected(r.ok))
      .catch(() => setConnected(false));
    return () => off?.();
  }, []); // Initialize one auth client for this browser session.
  useEffect(() => {
    document.documentElement.lang = ar ? "ar" : "en";
    document.documentElement.dir = ar ? "rtl" : "ltr";
    localStorage.setItem("nexora-language", ar ? "ar" : "en");
  }, [ar]);
  useEffect(() => {
    if (!ready) return;
    const timer = setTimeout(() => {
      request<Conversation[]>(
        auth,
        "/conversations?q=" + encodeURIComponent(query),
      )
        .then(setHistory)
        .catch((e) => setNotice(e.message));
    }, 250);
    return () => clearTimeout(timer);
  }, [query, ready, auth]);
  useEffect(() => {
    bottom.current?.scrollIntoView({
      behavior: busy ? "instant" : "smooth",
      block: "end",
    });
  }, [messages, compare, busy]);
  async function act(fn: () => Promise<void>) {
    setNotice("");
    try {
      await fn();
    } catch (e) {
      setNotice(e instanceof Error ? e.message : "REQUEST_FAILED");
    }
  }
  function go(p: Page) {
    setPage(p);
    setMenu(false);
    setNotice("");
    if (p === "dashboard" && ready)
      void act(async () => setUsage(await request(auth, "/usage")));
    if (p === "admin" && ready)
      void act(async () => setAdmin(await request(auth, "/admin/overview")));
  }
  function newChat() {
    if (busy) return;
    setConversation(null);
    setMessages([]);
    setImage("");
    setCompare({});
    setPrompt("");
    go("chat");
    setTimeout(() => promptRef.current?.focus(), 0);
  }
  async function load(id: string) {
    if (busy) return;
    await act(async () => {
      const c = await request(auth, "/conversations/" + id);
      setConversation(c.id);
      setMessages(c.messages);
      go("chat");
    });
  }
  async function makeConversation(title: string) {
    return (
      await request<Conversation>(auth, "/conversations", {
        method: "POST",
        body: JSON.stringify({ title: title.slice(0, 100) }),
      })
    ).id;
  }
  async function runStream(
    provider: string,
    id: string,
    text: string,
    onDelta: (text: string) => void,
    signal: AbortSignal,
    challenge: string,
  ) {
    const session = (await auth!.auth.getSession()).data.session;
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session!.access_token}`,
      },
      body: JSON.stringify({
        provider,
        conversationId: id,
        message: text,
        mode: chatMode,
        ...(page !== "compare" && image ? { image } : {}),
        turnstileToken: challenge,
      }),
      signal,
    });
    if (!response.ok) {
      const r = (await response.json()) as any;
      throw Error(r.error || "REQUEST_FAILED");
    }
    let finished = false;
    await consumeEvents(response, (event, data) => {
      if (event === "delta") onDelta(data.text);
      if (event === "error") throw Error(data.error);
      if (event === "done") finished = true;
    });
    if (!finished && !signal.aborted) throw Error("STREAM_INTERRUPTED");
  }
  async function send(override?: string) {
    const text = (override || prompt).trim();
    if (!ready) {
      go("auth");
      return;
    }
    if (!text || busy) return;
    if (!token) {
      setNotice(
        t("أكمل التحقق الأمني أولًا.", "Complete the security check first."),
      );
      return;
    }
    if (!config?.budgetEnabled) {
      setNotice(
        t(
          "المحادثة متوقفة حتى يضبط المسؤول ميزانية الاستخدام.",
          "Chat is paused until an administrator enables a spending budget.",
        ),
      );
      return;
    }
    if (
      page !== "compare" &&
      !providers.find((p) => p.id === model)?.configured
    ) {
      setNotice(
        t(
          "هذا المزود يحتاج إعداد مفتاح ونموذج وتسعير.",
          "This provider requires a key, model and pricing configuration.",
        ),
      );
      return;
    }
    setBusy(true);
    setNotice("");
    setPrompt("");
    setLastPrompt(text);
    const controller = new AbortController();
    abort.current = controller;
    const challenge = token;
    setToken("");
    try {
      if (page === "compare") {
        // Turnstile tokens are single-use. Verify once at a dedicated comparison endpoint before issuing one-use provider grants.
        const grant = await request<{ grants: Record<string, string> }>(
          auth,
          "/comparison/grants",
          {
            method: "POST",
            body: JSON.stringify({ turnstileToken: challenge }),
          },
        );
        setCompare({});
        const ids: string[] = [];
        await Promise.all(
          providers.map(async (p) => {
            if (!p.configured) {
              setCompare((prev) => ({
                ...prev,
                [p.id]: t("غير مُعدّ", "Not configured"),
              }));
              return;
            }
            const id = await makeConversation(
              "[Compare · " + providerNames[p.id] + "] " + text,
            );
            ids.push(id);
            try {
              await runStream(
                p.id,
                id,
                text,
                (delta) =>
                  setCompare((prev) => ({
                    ...prev,
                    [p.id]: (prev[p.id] || "") + delta,
                  })),
                controller.signal,
                "grant:" + grant.grants[p.id],
              );
            } catch (e) {
              if (!controller.signal.aborted)
                setCompare((prev) => ({
                  ...prev,
                  [p.id]:
                    (prev[p.id] || "") +
                    "\n\n" +
                    (e instanceof Error ? e.message : "ERROR"),
                }));
            }
          }),
        );
        setCompareIds(ids);
      } else {
        const id = conversation || (await makeConversation(text));
        setConversation(id);
        const answer = crypto.randomUUID();
        setMessages((prev) => [
          ...prev,
          { id: crypto.randomUUID(), role: "user", content: text },
          {
            id: answer,
            role: "assistant",
            content: "",
            provider: model,
            status: "streaming",
          },
        ]);
        setPage("chat");
        await runStream(
          model,
          id,
          text,
          (delta) =>
            setMessages((prev) =>
              prev.map((m) =>
                m.id === answer ? { ...m, content: m.content + delta } : m,
              ),
            ),
          controller.signal,
          challenge,
        );
        const saved = await request(auth, "/conversations/" + id);
        setMessages(saved.messages);
      }
    } catch (e) {
      if (!controller.signal.aborted)
        setNotice(e instanceof Error ? e.message : "GENERATION_FAILED");
    } finally {
      setBusy(false);
      abort.current = null;
      setCaptchaReset((x) => x + 1);
      setImage("");
      setHistory(await request(auth, "/conversations").catch(() => history));
    }
  }
  async function logout() {
    abort.current?.abort();
    await act(async () => {
      if (ready)
        await request(auth, "/session/revoke", { method: "POST", body: "{}" });
      await auth?.auth.signOut({ scope: "global" });
      setProfile(null);
      setHistory([]);
      setMessages([]);
      setConversation(null);
      setUsage(null);
      setAdmin(null);
      setRecovery([]);
      setPage("home");
    });
  }
  const nav: [Page, React.ReactNode, string][] = [
    ["home", <Orbit size={19} />, t("المساحة الرئيسية", "Overview")],
    ["chat", <MessageSquare size={19} />, t("المحادثة", "AI Chat")],
    ["compare", <Columns2 size={19} />, t("مقارنة النماذج", "Compare models")],
    ["dashboard", <LayoutDashboard size={19} />, t("لوحة التحكم", "Dashboard")],
    ["lab", <Sparkles size={19} />, t("مختبر الإمكانات", "Capability center")],
  ];
  function renderMessage(m: Message) {
    return (
      <article key={m.id} className={"message " + m.role}>
        <div className={"message-icon " + (m.provider || "")}>
          {m.role === "user"
            ? profile?.name?.[0] || "U"
            : icons[m.provider || model]}
        </div>
        <div className="message-body">
          <div className="message-label">
            {m.role === "user"
              ? profile?.name || t("أنت", "You")
              : providerNames[m.provider || model]}{" "}
            <span>{m.status && m.status !== "complete" ? m.status : ""}</span>
          </div>
          <div className="markdown">
            <Markdown remarkPlugins={[remarkGfm]}>
              {m.content ||
                (busy
                  ? "…"
                  : t("لم يتم حفظ نص إجابة.", "No answer text was saved."))}
            </Markdown>
          </div>
          {m.role === "assistant" && m.content && (
            <div className="message-tools">
              <button
                aria-label="Copy"
                onClick={() =>
                  act(async () => {
                    await navigator.clipboard.writeText(m.content);
                    setNotice(t("تم النسخ", "Copied"));
                  })
                }
              >
                <Copy size={14} />
              </button>
              <button
                aria-label="Export answer"
                onClick={() => download("nexora-answer.md", m.content)}
              >
                <Download size={14} />
              </button>
            </div>
          )}
        </div>
      </article>
    );
  }
  return (
    <div className="app-shell">
      <div className="ambient" />
      {menu && <div className="scrim" onClick={() => setMenu(false)} />}
      <aside className={"sidebar " + (menu ? "open" : "")}>
        <a
          href="#"
          className="brand"
          onClick={(e) => {
            e.preventDefault();
            go("home");
          }}
        >
          <div className="brand-mark">
            <Command size={23} />
          </div>
          <span>
            NEXORA<span className="ai"> AI</span>
            <small>INTELLIGENCE, CONNECTED.</small>
          </span>
        </a>
        <button className="new-chat primary" onClick={newChat} disabled={busy}>
          <Plus size={18} />
          {t("محادثة جديدة", "New conversation")}
          <kbd>＋</kbd>
        </button>
        <div className="nav-label">{t("مساحتك", "WORKSPACE")}</div>
        <nav>
          {nav.map(([id, icon, label]) => (
            <button
              key={id}
              className={page === id ? "active" : ""}
              onClick={() => go(id)}
            >
              {icon}
              {label}
              {id === "compare" && <span className="new-tag">4 AI</span>}
            </button>
          ))}
        </nav>
        <div className="history-heading">
          <span>{t("المحادثات الأخيرة", "RECENT CONVERSATIONS")}</span>
          <Search size={14} />
        </div>
        <label className="search-field">
          <Search size={14} />
          <input
            aria-label="Search conversations"
            placeholder={t("ابحث في المحادثات…", "Search conversations…")}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            disabled={!ready}
          />
        </label>
        <div className="history-list">
          {history.map((c) => (
            <div
              key={c.id}
              className={
                "history-row " + (conversation === c.id ? "current" : "")
              }
            >
              <button disabled={busy} onClick={() => load(c.id)}>
                <MessageSquare size={14} />
                <span>{c.title}</span>
              </button>
              <button
                aria-label="Delete conversation"
                disabled={busy}
                onClick={() =>
                  act(async () => {
                    if (
                      !window.confirm(
                        t(
                          "حذف هذه المحادثة نهائيًا؟",
                          "Permanently delete this conversation?",
                        ),
                      )
                    )
                      return;
                    await request(auth, "/conversations/" + c.id, {
                      method: "DELETE",
                      body: "{}",
                    });
                    setHistory((h) => h.filter((x) => x.id !== c.id));
                    if (conversation === c.id) newChat();
                  })
                }
              >
                <Trash2 size={13} />
              </button>
            </div>
          ))}
          {!history.length && (
            <p className="empty-history">
              {t(
                "أفكارك القادمة تبدأ بمحادثة.",
                "Your next idea starts with a conversation.",
              )}
            </p>
          )}
        </div>
        <div className="sidebar-bottom">
          <div className="private-card">
            <ShieldCheck size={20} />
            <div>
              <b>{t("مساحتك. خصوصيتك.", "Your space. Your privacy.")}</b>
              <small>
                {t(
                  "وصول محمي بالمصادقة الثنائية",
                  "Protected with two-factor authentication",
                )}
              </small>
            </div>
          </div>
          {profile?.admin && (
            <button className="sidebar-link" onClick={() => go("admin")}>
              <ShieldCheck size={17} />
              {t("لوحة الإدارة", "Administration")}
            </button>
          )}
          <button className="sidebar-link" onClick={() => go("settings")}>
            <Settings size={17} />
            {t("الإعدادات", "Settings")}
          </button>
          <button
            className="profile-button"
            onClick={() => go(profile ? "settings" : "auth")}
          >
            <span className="avatar">
              {profile?.avatar ? (
                <img src={profile.avatar} alt="" />
              ) : (
                profile?.name?.[0] || "N"
              )}
            </span>
            <span>
              <b>{profile?.name || t("مساحتك الشخصية", "Your workspace")}</b>
              <small>
                {profile?.email ||
                  t("سجّل الدخول للبدء", "Sign in to get started")}
              </small>
            </span>
            <ChevronDown size={15} />
          </button>
        </div>
      </aside>
      <div className="main-shell">
        <header className="topbar">
          <div className="breadcrumb">
            <button
              className="mobile-menu icon-button"
              aria-label="Open menu"
              onClick={() => setMenu(true)}
            >
              <Menu size={20} />
            </button>
            <span>NEXORA</span>
            <span className="slash">/</span>
            <b>
              {t(
                {
                  lab: "مختبر الإمكانات",
                  home: "الرئيسية",
                  chat: "المحادثة",
                  compare: "مقارنة النماذج",
                  dashboard: "لوحة التحكم",
                  settings: "الإعدادات",
                  admin: "الإدارة",
                  auth: "الحساب",
                  privacy: "الخصوصية",
                  terms: "الشروط",
                }[page],
                {
                  lab: "Capability center",
                  home: "Overview",
                  chat: "AI Chat",
                  compare: "Compare models",
                  dashboard: "Dashboard",
                  settings: "Settings",
                  admin: "Administration",
                  auth: "Account",
                  privacy: "Privacy",
                  terms: "Terms",
                }[page],
              )}
            </b>
          </div>
          <div className="top-actions">
            <span className="server-pill">
              <i className={connected ? "green" : ""} />
              {connected === null
                ? t("جارٍ الفحص", "Checking")
                : connected
                  ? t("الخادم يعمل", "Server online")
                  : t("غير متصل", "Server offline")}
            </span>
            <button className="language" onClick={() => setAr(!ar)}>
              <Globe size={15} />
              {ar ? "EN" : "العربية"}
            </button>
            {!profile && (
              <button className="login-button" onClick={() => go("auth")}>
                {t("تسجيل الدخول", "Sign in")}
                <ArrowUpRight size={14} />
              </button>
            )}
          </div>
        </header>
        <main
          className={
            "content " +
            (["chat", "compare"].includes(page) ? "chat-content" : "")
          }
        >
          {notice && (
            <div className="toast" role="status">
              <Activity size={16} />
              <span>{notice}</span>
              <button aria-label="Dismiss" onClick={() => setNotice("")}>
                <X size={15} />
              </button>
            </div>
          )}
          {page === "home" && (
            <>
              <section className="hero">
                <div className="hero-tag">
                  <span className="live-dot" />
                  {t("أربع قوى. مساحة واحدة.", "FOUR MINDS. ONE WORKSPACE.")}
                  <ArrowUpRight size={13} />
                </div>
                <div className="orb-scene" aria-hidden="true">
                  <div className="orbit orbit-one" />
                  <div className="orbit orbit-two" />
                  <div className="orb">
                    <Sparkles size={43} />
                  </div>
                  <span className="orb-star s1">✦</span>
                  <span className="orb-star s2">✧</span>
                  <span className="orb-dot" />
                </div>
                <h1>
                  {t("أفكار بلا حدود.", "Think beyond")}
                  <br />
                  <span>{t("ذكاء بلا حواجز.", "every possibility.")}</span>
                </h1>
                <p className="hero-description">
                  {t(
                    "أفضل نماذج الذكاء الاصطناعي، معًا في مساحتك.",
                    "The world’s leading AI models. Together in your space.",
                  )}
                  <br />
                  {t(
                    "اكتب، ابتكر، وبرمج — من فكرة واحدة إلى آفاق جديدة.",
                    "Write, create, and code — from a spark to something extraordinary.",
                  )}
                </p>
                <div className="hero-actions">
                  <button className="primary" onClick={newChat}>
                    {t("ابدأ محادثتك الأولى", "Start a conversation")}
                    <ArrowUpRight size={17} />
                  </button>
                  <button className="secondary" onClick={() => go("compare")}>
                    <Columns2 size={17} />
                    {t("قارن النماذج", "Compare models")}
                  </button>
                </div>
                <div className="hero-caption">
                  <ShieldCheck size={13} />
                  {t(
                    "واجهات API رسمية · بيانات خاصة · مصادقة ثنائية",
                    "Official APIs · Private conversations · Two-factor authentication",
                  )}
                </div>
              </section>
              <section className="models-section">
                <div className="section-heading">
                  <div>
                    <span className="eyebrow">YOUR INTELLIGENCE STACK</span>
                    <h2>
                      {t(
                        "قوة كل نموذج، في متناولك.",
                        "Different strengths. Limitless possibilities.",
                      )}
                    </h2>
                  </div>
                  <span className="subtle-label">
                    {t(
                      "اختر الذكاء المناسب لفكرتك",
                      "THE RIGHT MIND FOR YOUR NEXT IDEA",
                    )}
                  </span>
                </div>
                <div className="model-grid">
                  {providers.map((p, i) => (
                    <button
                      className={"model-card " + p.id}
                      key={p.id}
                      onClick={() => {
                        setModel(p.id);
                        newChat();
                      }}
                    >
                      <div className="model-card-top">
                        <span className={"model-logo " + p.id}>
                          {icons[p.id]}
                        </span>
                        <ArrowUpRight size={17} />
                      </div>
                      <h3>
                        {providerNames[p.id]}
                        <span>
                          {["OPENAI", "GOOGLE", "DEEPSEEK", "ANTHROPIC"][i]}
                        </span>
                      </h3>
                      <p>
                        {
                          [
                            t(
                              "كتابة، تحليل، وحلول لأفكارك اليومية.",
                              "Your versatile partner for writing and reasoning.",
                            ),
                            t(
                              "أفكار واسعة. فهم أعمق. آفاق جديدة.",
                              "Explore big ideas with a broader perspective.",
                            ),
                            t(
                              "منطق متقدم وبرمجة دقيقة.",
                              "Precision thinking for code and complex problems.",
                            ),
                            t(
                              "كتابة متقنة وتحليل يراعي التفاصيل.",
                              "Thoughtful analysis and beautifully crafted writing.",
                            ),
                          ][i]
                        }
                      </p>
                      <div className="model-card-bottom">
                        <span>
                          <i
                            className={p.status === "verified" ? "green" : ""}
                          />
                          {p.status === "verified"
                            ? t("تم اختبار الاتصال", "Connection verified")
                            : p.configured
                              ? t("جاهز للاختبار", "Ready to test")
                              : t("بانتظار الإعداد", "Setup required")}
                        </span>
                        <span>{["↗", "✧", "⌘", "✳"][i]}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </section>
              <section className="start-section">
                <div className="section-heading">
                  <h2>
                    {t("من أين نبدأ؟", "Where will your curiosity take you?")}
                  </h2>
                  <span className="subtle-label">
                    {t("فكرة صغيرة. احتمالات كبيرة.", "A LITTLE INSPIRATION")}
                  </span>
                </div>
                <div className="prompt-grid">
                  {[
                    [
                      <PenLine size={19} />,
                      t("اكتب شيئًا مميزًا", "Make words matter"),
                      t(
                        "ساعدني في كتابة قصة قصيرة بأسلوب إبداعي.",
                        "Help me write a compelling short story with an unexpected ending.",
                      ),
                    ],
                    [
                      <Code2 size={19} />,
                      t("ابنِ فكرتك القادمة", "Build your next idea"),
                      t(
                        "اشرح لي كيفية بناء تطبيق آمن باستخدام TypeScript.",
                        "Explain how to build a secure application with TypeScript.",
                      ),
                    ],
                    [
                      <Lightbulb size={19} />,
                      t("اكتشف منظورًا جديدًا", "Find a fresh perspective"),
                      t(
                        "اقترح أفكارًا عملية لمشروع تقني يخدم المجتمع.",
                        "Brainstorm practical ideas for a technology project that helps communities.",
                      ),
                    ],
                  ].map(([icon, title, text], i) => (
                    <button
                      key={i}
                      className="prompt-card"
                      onClick={() => {
                        newChat();
                        setPrompt(String(text));
                      }}
                    >
                      {icon}
                      <h3>{title}</h3>
                      <p>{text}</p>
                      <ArrowUpRight size={16} />
                    </button>
                  ))}
                </div>
              </section>
            </>
          )}
          {["chat", "compare"].includes(page) && (
            <>
              <div className="chat-toolbar">
                <div className="model-select">
                  <span className={"mini-model " + model}>
                    {page === "compare" ? <Columns2 size={17} /> : icons[model]}
                  </span>
                  {page === "compare" ? (
                    <b>
                      {t(
                        "سؤال واحد. أربع وجهات نظر.",
                        "One prompt. Four perspectives.",
                      )}
                    </b>
                  ) : (
                    <select
                      aria-label="AI model"
                      value={model}
                      disabled={busy}
                      onChange={(e) => setModel(e.target.value)}
                    >
                      {providers.map((p) => (
                        <option key={p.id} value={p.id}>
                          {providerNames[p.id]}
                          {p.model ? " · " + p.model : ""}
                        </option>
                      ))}
                    </select>
                  )}
                </div>
                <div className="toolbar-actions">
                  {messages.length > 0 && (
                    <button
                      className="icon-button"
                      aria-label="Export conversation"
                      onClick={() =>
                        download(
                          "nexora-conversation.md",
                          messages
                            .map(
                              (m) =>
                                "## " +
                                (m.role === "user"
                                  ? "You"
                                  : providerNames[m.provider || model]) +
                                "\n\n" +
                                m.content,
                            )
                            .join("\n\n"),
                        )
                      }
                    >
                      <Download size={17} />
                    </button>
                  )}
                  <span className="secure-label">
                    <LockKeyhole size={12} />
                    {t("مساحة خاصة", "Private workspace")}
                  </span>
                </div>
              </div>
              <div className="chat-scroll">
                {page === "compare" ? (
                  <>
                    <div className="compare-intro">
                      <span className="eyebrow">NEXORA ARENA</span>
                      <h2>
                        {t(
                          "لا تكتفِ بإجابة واحدة.",
                          "Great ideas deserve more than one perspective.",
                        )}
                      </h2>
                      <p>
                        {t(
                          "قارن إجابات المزودين الرسميين جنبًا إلى جنب. يُحتسب كل طلب بشكل مستقل.",
                          "Compare official providers side by side. Each response is billed separately.",
                        )}
                      </p>
                    </div>
                    <div className="comparison-grid">
                      {providers.map((p) => (
                        <article
                          className={"panel comparison " + p.id}
                          key={p.id}
                        >
                          <h3>
                            <span className={"model-logo " + p.id}>
                              {icons[p.id]}
                            </span>
                            {providerNames[p.id]}
                            {compare[p.id] && (
                              <button
                                className="icon-button"
                                aria-label="Export"
                                onClick={() =>
                                  download(p.id + ".md", compare[p.id])
                                }
                              >
                                <Download size={15} />
                              </button>
                            )}
                          </h3>
                          <div className="markdown">
                            <Markdown remarkPlugins={[remarkGfm]}>
                              {compare[p.id] ||
                                t(
                                  "الإجابة ستظهر هنا بعد الإرسال.",
                                  "Your response will appear here.",
                                )}
                            </Markdown>
                          </div>
                        </article>
                      ))}
                    </div>
                    {compareIds.length > 0 && (
                      <p className="fine">
                        {t(
                          "حُفظت المقارنة كمحادثات مستقلة في السجل.",
                          "Comparison responses are saved as individual conversations in history.",
                        )}
                      </p>
                    )}
                  </>
                ) : messages.length ? (
                  messages.map(renderMessage)
                ) : (
                  <div className="chat-empty">
                    <div className="empty-orb">
                      <Sparkles size={30} />
                    </div>
                    <h2>
                      {t("ما الذي يدور في ذهنك؟", "What’s on your mind?")}
                    </h2>
                    <p>
                      {t(
                        "سؤال صعب، فكرة جديدة، أو بداية مشروع. لنفكر معًا.",
                        "A tough question, a new idea, a fresh start. Let’s think together.",
                      )}
                    </p>
                    {!ready && (
                      <button className="secondary" onClick={() => go("auth")}>
                        <LockKeyhole size={16} />
                        {t(
                          "سجّل الدخول وفعّل المصادقة",
                          "Sign in & secure your account",
                        )}
                      </button>
                    )}
                  </div>
                )}
                <div ref={bottom} />
              </div>
              <div className="composer-area">
                <div className="chat-capabilities">
                  <select
                    aria-label="Chat mode"
                    disabled={busy}
                    value={chatMode}
                    onChange={(e) => setChatMode(e.target.value)}
                  >
                    {[
                      ["standard", t("عادي", "Standard")],
                      ["deep", t("تفكير عميق", "Deep analysis")],
                      ["code", t("برمجة", "Coding")],
                      ["web", t("بحث الويب", "Web research")],
                    ].map(([id, label]) => (
                      <option key={id} value={id}>
                        {label}
                      </option>
                    ))}
                  </select>
                  <VoiceControls
                    ar={ar}
                    onTranscript={(text) => setPrompt(text)}
                    text={
                      [...messages]
                        .reverse()
                        .find((m) => m.role === "assistant")?.content || ""
                    }
                    disabled={busy}
                  />
                </div>
                {page !== "compare" && (
                  <VisionInput
                    ar={ar}
                    image={image}
                    onImage={setImage}
                    onText={(text) =>
                      setPrompt((prev) => (prev + "\n" + text).slice(0, 20000))
                    }
                    disabled={busy || model === "deepseek"}
                  />
                )}

                {ready && config?.turnstileSiteKey && (
                  <Turnstile
                    siteKey={config.turnstileSiteKey}
                    action="chat"
                    onToken={setToken}
                    resetKey={captchaReset}
                  />
                )}
                <form
                  className="composer"
                  onSubmit={(e) => {
                    e.preventDefault();
                    void send();
                  }}
                >
                  <textarea
                    ref={promptRef}
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    maxLength={20000}
                    placeholder={t(
                      "اسأل، ابتكر، أو فكّر بصوت عالٍ…",
                      "Ask, create, or think out loud…",
                    )}
                    rows={2}
                    onKeyDown={(e) => {
                      if (
                        e.key === "Enter" &&
                        !e.shiftKey &&
                        !e.nativeEvent.isComposing
                      ) {
                        e.preventDefault();
                        void send();
                      }
                    }}
                  />
                  <div className="composer-bottom">
                    <span>
                      <Sparkles size={14} />
                      {page === "compare"
                        ? t("أربعة نماذج", "Four models")
                        : providerNames[model]}
                      <span className="composer-hint">
                        {" "}
                        ·{" "}
                        {t(
                          "Shift + Enter لسطر جديد",
                          "Shift + Enter for a new line",
                        )}
                      </span>
                    </span>
                    {busy ? (
                      <button
                        type="button"
                        className="send-button"
                        aria-label="Stop generation"
                        onClick={() => abort.current?.abort()}
                      >
                        <Square size={16} />
                      </button>
                    ) : (
                      <button
                        className="send-button"
                        type="submit"
                        aria-label="Send message"
                        disabled={!prompt.trim()}
                      >
                        <ArrowUp size={19} />
                      </button>
                    )}
                  </div>
                </form>
                <div className="composer-footer">
                  <span>
                    {t(
                      "قد يخطئ الذكاء الاصطناعي. تحقّق من المعلومات المهمة.",
                      "AI can make mistakes. Verify important information.",
                    )}
                  </span>
                  {lastPrompt && !busy && page === "chat" && (
                    <button onClick={() => send(lastPrompt)}>
                      <RotateCcw size={12} />
                      {t("إعادة التوليد", "Regenerate")}
                    </button>
                  )}
                </div>
              </div>
            </>
          )}
          {page === "auth" && (
            <Auth
              auth={auth}
              profile={profile}
              siteKey={config?.turnstileSiteKey || null}
              ar={ar}
              onDone={async () => {
                await sync();
                const p = auth
                  ? await request<Profile>(auth, "/session").catch(() => null)
                  : null;
                if (p?.aal === "aal2") go("chat");
              }}
            />
          )}
          {["dashboard", "settings", "admin"].includes(page) && !ready && (
            <Auth
              auth={auth}
              profile={profile}
              siteKey={config?.turnstileSiteKey || null}
              ar={ar}
              onDone={async () => {
                await sync();
              }}
            />
          )}
          {page === "lab" && (
            <CapabilitiesHub
              authorized={!!ready}
              onSignIn={() => go("auth")}
              ar={ar}
              auth={auth}
              siteKey={config?.turnstileSiteKey || null}
            />
          )}
          {page === "dashboard" && ready && (
            <section className="management">
              <span className="eyebrow">YOUR WORKSPACE, AT A GLANCE</span>
              <h1>{t("لوحة التحكم", "Your dashboard")}</h1>
              <p>
                {t(
                  "استهلاك هذا الشهر حسب السجلات الفعلية. الأسعار التقديرية يضبطها المسؤول.",
                  "This month’s recorded usage. Cost estimates use administrator-configured prices.",
                )}
              </p>
              <div className="stats-grid">
                <Stat
                  label={t("المحادثات", "Conversations")}
                  value={usage?.conversations ?? "—"}
                />
                <Stat
                  label={t("طلبات هذا الشهر", "Monthly requests")}
                  value={
                    usage?.models?.reduce(
                      (n: number, m: any) => n + m.requests,
                      0,
                    ) ?? "—"
                  }
                />
                <Stat
                  label={t("تكلفة مسجلة USD", "Recorded cost USD")}
                  value={
                    usage
                      ? "$" +
                        usage.models
                          .reduce(
                            (n: number, m: any) => n + (m.charged_usd || 0),
                            0,
                          )
                          .toFixed(4)
                      : "—"
                  }
                />
              </div>
              <div className="panel">
                <h3>{t("حصص حسابك", "Your spending limits")}</h3>
                <p>
                  {t("يومي", "Daily")}: ${profile?.daily_usd} ·{" "}
                  {t("شهري", "Monthly")}: ${profile?.monthly_usd}
                </p>
                <UsageTable rows={usage?.models || []} ar={ar} />
              </div>
              <div className="panel">
                <div className="section-heading">
                  <h3>{t("اتصال المزودين", "Provider connections")}</h3>
                  <button
                    onClick={() =>
                      act(async () => {
                        const r = await request(auth, "/providers/probe", {
                          method: "POST",
                          body: "{}",
                        });
                        setProviders((prev) =>
                          prev.map((p) => ({
                            ...p,
                            ...r.providers.find((x: any) => x.id === p.id),
                          })),
                        );
                      })
                    }
                  >
                    <Activity size={15} />
                    {t("اختبار الاتصال", "Test connections")}
                  </button>
                </div>
                {providers.map((p) => (
                  <div className="status-row" key={p.id}>
                    <b>{providerNames[p.id]}</b>
                    <span>{p.model || "—"}</span>
                    <span>{p.status || "not_tested"}</span>
                  </div>
                ))}
                <p className="fine">
                  {t(
                    "فحص الاتصال يتحقق من المصادقة وتوفر النموذج؛ اختبار المحادثة مستقل وقد يستهلك رصيدًا.",
                    "Connection checks verify authentication and model availability; a chat test is separate and may use credits.",
                  )}
                </p>
              </div>
            </section>
          )}
          {page === "settings" && ready && (
            <section className="management">
              <span className="eyebrow">MAKE IT YOURS</span>
              <h1>{t("الإعدادات", "Settings")}</h1>
              <div className="settings-grid">
                <div className="panel">
                  <h3>{t("الملف الشخصي", "Personal profile")}</h3>
                  <label>
                    {t("الاسم", "Display name")}
                    <input
                      value={name}
                      maxLength={80}
                      onChange={(e) => setName(e.target.value)}
                    />
                  </label>
                  <label>
                    {t(
                      "الصورة الشخصية (PNG، JPEG، WebP، أقل من 75KB)",
                      "Avatar (PNG, JPEG, WebP, under 75KB)",
                    )}
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/webp"
                      onChange={(e) =>
                        act(async () => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          if (file.size > 75000)
                            throw Error("AVATAR_TOO_LARGE");
                          const data = await new Promise<string>(
                            (resolve, reject) => {
                              const reader = new FileReader();
                              reader.onload = () =>
                                resolve(String(reader.result));
                              reader.onerror = reject;
                              reader.readAsDataURL(file);
                            },
                          );
                          setAvatar(data);
                        })
                      }
                    />
                  </label>
                  <button
                    className="primary"
                    onClick={() =>
                      act(async () => {
                        await request(auth, "/profile", {
                          method: "PATCH",
                          body: JSON.stringify({ name, avatar }),
                        });
                        await sync();
                        setNotice(t("تم الحفظ", "Saved"));
                      })
                    }
                  >
                    {t("حفظ التغييرات", "Save changes")}
                  </button>
                  <label>
                    {t("اللغة", "Language")}
                    <select
                      value={ar ? "ar" : "en"}
                      onChange={(e) => setAr(e.target.value === "ar")}
                    >
                      <option value="ar">العربية</option>
                      <option value="en">English</option>
                    </select>
                  </label>
                </div>
                <div className="panel">
                  <h3>
                    <ShieldCheck size={19} />
                    {t("الأمان والجلسات", "Security & sessions")}
                  </h3>
                  <p className="security-status">
                    <Check size={17} />
                    {t(
                      "المصادقة الثنائية مفعّلة (AAL2)",
                      "Two-factor authentication active (AAL2)",
                    )}
                  </p>
                  <p>
                    {t(
                      "احفظ رموز الاسترداد في مكان آمن خارج جهازك. إنشاء رموز جديدة يُلغي القديمة.",
                      "Store recovery codes safely away from this device. New codes invalidate previous codes.",
                    )}
                  </p>
                  <button
                    disabled={!profile?.recoveryEnabled}
                    onClick={() =>
                      act(async () => {
                        const r = await request(auth, "/recovery/codes", {
                          method: "POST",
                          body: "{}",
                        });
                        setRecovery(r.codes);
                      })
                    }
                  >
                    {t("إنشاء رموز الاسترداد", "Generate recovery codes")}
                  </button>
                  {!profile?.recoveryEnabled && (
                    <p className="fine">
                      {t(
                        "يحتاج الاسترداد إعداد أسرار الخدمة بواسطة المسؤول.",
                        "Recovery requires service secrets configured by an administrator.",
                      )}
                    </p>
                  )}
                  {recovery.length > 0 && (
                    <div className="recovery">
                      <pre>{recovery.join("\n")}</pre>
                      <button
                        onClick={() =>
                          download(
                            "nexora-recovery.txt",
                            recovery.join("\n"),
                            "text/plain",
                          )
                        }
                      >
                        {t("تنزيل الرموز", "Download codes")}
                      </button>
                      <button onClick={() => setRecovery([])}>
                        {t("إخفاء الرموز", "Hide codes")}
                      </button>
                    </div>
                  )}
                  <hr />
                  <button className="danger" onClick={logout}>
                    <LogOut size={16} />
                    {t("الخروج من جميع الأجهزة", "Sign out of all devices")}
                  </button>
                </div>
              </div>
            </section>
          )}
          {page === "admin" && ready && profile?.admin && (
            <section className="management">
              <span className="eyebrow">NEXORA CONTROL CENTER</span>
              <h1>{t("إدارة المنصة", "Platform administration")}</h1>
              <div className="stats-grid">
                <Stat
                  label={t("المستخدمون", "Users")}
                  value={admin?.usersTotal ?? "—"}
                />
                <Stat
                  label={t("المحادثات", "Conversations")}
                  value={admin?.conversations ?? "—"}
                />
                <Stat
                  label={t("الطلبات", "Requests")}
                  value={
                    admin?.usage?.reduce(
                      (n: number, r: any) => n + r.requests,
                      0,
                    ) ?? "—"
                  }
                />
              </div>
              <div className="panel">
                <h3>{t("استهلاك النماذج", "Model usage")}</h3>
                <UsageTable rows={admin?.usage || []} ar={ar} />
              </div>
              <div className="panel">
                <h3>
                  {t("المستخدمون وحدود الاستخدام", "Users & spending limits")}
                </h3>
                {admin?.users?.map((u: any) => (
                  <AdminUser
                    key={u.id}
                    user={u}
                    ar={ar}
                    save={async (data) => {
                      await request(auth, "/admin/users/" + u.id, {
                        method: "PATCH",
                        body: JSON.stringify(data),
                      });
                      setNotice(t("تم تحديث الحساب", "Account updated"));
                    }}
                  />
                ))}
              </div>
              <div className="panel">
                <h3>{t("سجلات أخطاء آمنة", "Safe error logs")}</h3>
                {admin?.errors?.length ? (
                  admin.errors.map((e: any) => (
                    <div className="status-row" key={e.id}>
                      <span>{e.provider}</span>
                      <code>{e.error_code}</code>
                      <small>{e.created_at}</small>
                    </div>
                  ))
                ) : (
                  <p>{t("لا توجد أخطاء مسجلة.", "No recorded errors.")}</p>
                )}
              </div>
            </section>
          )}
          {(page === "privacy" || page === "terms") && (
            <section className="management legal panel">
              <span className="eyebrow">NEXORA AI</span>
              <h1>
                {page === "privacy"
                  ? t("سياسة الخصوصية", "Privacy policy")
                  : t("شروط الاستخدام", "Terms of service")}
              </h1>
              <p>
                {t(
                  "آخر تحديث: 25 أكتوبر 2026",
                  "Last updated: October 25, 2026",
                )}
              </p>
              {page === "privacy" ? (
                <>
                  <h3>{t("البيانات التي نعالجها", "Data we process")}</h3>
                  <p>
                    {t(
                      "نحفظ البريد والاسم والصورة والمحادثات وبيانات الاستهلاك في Supabase Auth وCloudflare D1. لا تُخزن كلمات المرور أو أسرار TOTP في قاعدة بيانات التطبيق.",
                      "We process email, profile details, conversations and usage records with Supabase Auth and Cloudflare D1. Application tables do not store passwords or TOTP secrets.",
                    )}
                  </p>
                  <h3>{t("مزودو الذكاء الاصطناعي", "AI providers")}</h3>
                  <p>
                    {t(
                      "يُرسل نص المحادثة وسياقها إلى المزود الذي تختاره. المقارنة ترسل السؤال إلى أربعة مزودين. يخضع هؤلاء لسياساتهم واحتفاظهم بالبيانات؛ تجنب إرسال معلومات حساسة.",
                      "Your prompt and conversation context are sent to the provider you select. Comparison sends prompts to four providers. Their privacy and retention policies apply; avoid sending sensitive information.",
                    )}
                  </p>
                  <h3>
                    {t("الذاكرة والصوت والوسائط", "Memory, speech and media")}
                  </h3>
                  <p>
                    {t(
                      "الذاكرة اختيارية ومعطلة افتراضيًا، ويمكن حذفها. تُرسل الصور المرفقة إلى مزود الرؤية ولا تُحفظ في سجل المحادثة. قد يعالج مزود متصفحك الصوت. البحث يرسل السؤال إلى Brave عند إعداده. تُحفظ الوسائط المولدة في R2 خاص عند تفعيله. تصدير PDF وPowerPoint وExcel يتم محليًا في المتصفح. نتائج المهام المجدولة تُحفظ في حسابك.",
                      "Memory is opt-in, off by default and deletable. Attached images go to your selected vision provider and are not saved in chat history. Your browser vendor may process speech. Configured web research sends queries to Brave. Generated media uses private R2 when enabled. PDF, PowerPoint and Excel exports run locally in your browser. Scheduled outputs are stored in your account.",
                    )}
                  </p>
                  <h3>{t("التحكم ببياناتك", "Your data controls")}</h3>
                  <p>
                    {t(
                      "يمكنك تصدير المحادثات وحذفها. تبقى سجلات الفوترة والأمان التشغيلية دون نص الرسائل بعد حذف المحادثة. تُحفظ الجلسة في متصفحك لتسجيل الدخول. لطلب حذف الحساب تواصل مع مشغّل المنصة عبر قناة الدعم المعتمدة.",
                      "You can export and delete conversations. Billing and security records retain no message text after deletion. Your browser stores a sign-in session. Request account deletion through the operator’s established support channel.",
                    )}
                  </p>
                </>
              ) : (
                <>
                  <h3>{t("الاستخدام المسؤول", "Responsible use")}</h3>
                  <p>
                    {t(
                      "يجب الالتزام بالقوانين وشروط مزودي الخدمة. لا تستخدم المنصة للإساءة أو تجاوز الحماية أو الوصول إلى بيانات الآخرين. أنت مسؤول عن المدخلات التي ترسلها.",
                      "Follow applicable law and provider terms. Do not abuse the service, bypass security or access other users’ data. You are responsible for your inputs.",
                    )}
                  </p>
                  <h3>{t("حدود الخدمة والتكلفة", "Limits and costs")}</h3>
                  <p>
                    {t(
                      "قد تحتوي الإجابات على أخطاء ولا تغني عن مشورة المختصين. يعتمد التوفر على المزودين وحصص الحساب والميزانية. تكاليف الاستخدام تقديرية وليست فاتورة دفع. قد يستمر احتساب طلب ألغي أو فشل عندما لا يرسل المزود استهلاكًا نهائيًا.",
                      "Answers can be incorrect and do not replace professional advice. Availability depends on providers, quotas and budgets. Usage costs are estimates, not payment invoices. Cancelled or failed calls may retain a conservative cost when final usage is unavailable.",
                    )}
                  </p>
                  <h3>{t("أمان الحساب", "Account security")}</h3>
                  <p>
                    {t(
                      "حافظ على بيانات دخولك ورموز الاسترداد. المصادقة الثنائية إلزامية للوصول إلى المحادثات. يمكن تعليق الحسابات المخالفة وحماية الخدمة بحدود استخدام.",
                      "Protect your credentials and recovery codes. MFA is required for conversation access. Abusive accounts may be suspended and usage limited.",
                    )}
                  </p>
                </>
              )}
            </section>
          )}
        </main>
        {!["chat", "compare"].includes(page) && (
          <footer className="footer">
            <span>
              © 2026 NEXORA AI <span className="footer-dot">·</span>{" "}
              {t("مساحة لأفكار أكبر.", "A space for bigger ideas.")}
            </span>
            <div>
              <button onClick={() => go("privacy")}>
                {t("الخصوصية", "Privacy")}
              </button>
              <button onClick={() => go("terms")}>
                {t("الشروط", "Terms")}
              </button>
              <span>
                <i className={connected ? "green" : ""} />
                {connected ? "Cloudflare-ready" : "Setup in progress"}
              </span>
            </div>
          </footer>
        )}
      </div>
    </div>
  );
}
function Stat({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="panel stat">
      <span>{label}</span>
      <strong>{value}</strong>
      <Activity size={21} />
    </div>
  );
}
function UsageTable({ rows, ar }: { rows: any[]; ar: boolean }) {
  return (
    <div className="table-scroll">
      <table>
        <thead>
          <tr>
            {(ar
              ? [
                  "المزود",
                  "الطلبات",
                  "رموز الإدخال",
                  "رموز الإخراج",
                  "التكلفة USD",
                ]
              : [
                  "Provider",
                  "Requests",
                  "Input tokens",
                  "Output tokens",
                  "Cost USD",
                ]
            ).map((x) => (
              <th key={x}>{x}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={r.provider + (r.model || "") + i}>
              <td>
                {providerNames[r.provider]} {r.model || ""}
              </td>
              <td>{r.requests}</td>
              <td>{r.input_tokens ?? "—"}</td>
              <td>{r.output_tokens ?? "—"}</td>
              <td>${Number(r.charged_usd || 0).toFixed(5)}</td>
            </tr>
          ))}
          {!rows.length && (
            <tr>
              <td colSpan={5}>
                {ar ? "لا يوجد استهلاك مسجل بعد." : "No usage recorded yet."}
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
function AdminUser({
  user,
  ar,
  save,
}: {
  user: any;
  ar: boolean;
  save: (data: any) => Promise<void>;
}) {
  const [daily, setDaily] = useState(user.daily_usd),
    [monthly, setMonthly] = useState(user.monthly_usd),
    [disabled, setDisabled] = useState(!!user.disabled),
    [notice, setNotice] = useState("");
  return (
    <form
      className="admin-user"
      onSubmit={async (e) => {
        e.preventDefault();
        try {
          await save({
            disabled,
            dailyUsd: Number(daily),
            monthlyUsd: Number(monthly),
          });
          setNotice(ar ? "تم الحفظ" : "Saved");
        } catch (e) {
          setNotice(e instanceof Error ? e.message : "FAILED");
        }
      }}
    >
      <span>
        <b>{user.name || user.email}</b>
        <small>{user.email}</small>
      </span>
      <label>
        {ar ? "يومي USD" : "Daily USD"}
        <input
          type="number"
          min="0"
          max="1000"
          step="0.01"
          value={daily}
          onChange={(e) => setDaily(e.target.value)}
        />
      </label>
      <label>
        {ar ? "شهري USD" : "Monthly USD"}
        <input
          type="number"
          min="0"
          max="10000"
          step="0.01"
          value={monthly}
          onChange={(e) => setMonthly(e.target.value)}
        />
      </label>
      <label className="checkbox">
        <input
          type="checkbox"
          checked={disabled}
          onChange={(e) => setDisabled(e.target.checked)}
        />
        {ar ? "تعطيل" : "Disabled"}
      </label>
      <button type="submit">{ar ? "حفظ" : "Save"}</button>
      <small role="status">{notice}</small>
    </form>
  );
}
