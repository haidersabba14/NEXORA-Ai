"use client";
import { useState } from "react";
import {
  Download,
  FileSpreadsheet,
  FileText,
  Presentation,
  ShieldCheck,
} from "lucide-react";
import { exportDocument, type ExportKind } from "@/lib/file-exports";
import styles from "./file-studio.module.css";
export default function FileStudio({ ar }: { ar: boolean }) {
  const [kind, setKind] = useState<ExportKind>("pdf"),
    [title, setTitle] = useState(""),
    [content, setContent] = useState(""),
    [busy, setBusy] = useState(false),
    [notice, setNotice] = useState("");
  const t = (a: string, e: string) => (ar ? a : e);
  const messages: Record<string, string> = {
    CONTENT_REQUIRED: t("أدخل المحتوى أولًا.", "Enter some content first."),
    DOCUMENT_TOO_LARGE: t(
      "الحد الأقصى 50 ألف حرف، والعنوان 120 حرفًا.",
      "Use up to 50,000 content characters and a 120-character title.",
    ),
    INVALID_CSV: t(
      "تحقق من تنسيق CSV وعلامات الاقتباس.",
      "Check your CSV format and quoted values.",
    ),
    TABLE_TOO_LARGE: t(
      "الحد الأقصى 1000 صف و30 عمودًا.",
      "Use up to 1,000 rows and 30 columns.",
    ),
    SLIDES_TOO_DENSE: t(
      "قسّم المحتوى بفواصل أسطر فارغة: حتى 30 قسمًا، و1800 حرف لكل قسم.",
      "Split content into up to 30 sections with blank lines, and no more than 1,800 characters per section.",
    ),
    FONT_UNAVAILABLE: t(
      "تعذر تحميل خط PDF. تحقق من الاتصال بالموقع.",
      "The PDF font could not be loaded. Check your connection to this site.",
    ),
    PDF_UNSUPPORTED_CHARACTER: t(
      "يدعم خط PDF العربية واللاتينية. احذف الرموز التعبيرية أو المحارف غير المدعومة.",
      "The PDF font supports Arabic and Latin. Remove emoji or unsupported characters.",
    ),
    UNSUPPORTED_CONTROL_CHARACTER: t(
      "المحتوى يتضمن محارف تحكم غير مدعومة.",
      "The content contains unsupported control characters.",
    ),
  };
  async function create() {
    setBusy(true);
    setNotice("");
    try {
      await exportDocument(kind, { title, content, ar });
      setNotice(
        t(
          "تم إنشاء الملف وبدء تنزيله.",
          "Your file is ready and its download has started.",
        ),
      );
    } catch (e) {
      const code = e instanceof Error ? e.message : "EXPORT_FAILED";
      setNotice(
        messages[code] ||
          t(
            "تعذر إنشاء الملف. جرّب محتوى أقصر.",
            "The file could not be created. Try shorter content.",
          ),
      );
    } finally {
      setBusy(false);
    }
  }
  const formats: [ExportKind, React.ReactNode, string, string][] = [
    [
      "pdf",
      <FileText size={21} />,
      "PDF",
      t("مستند منسق يدعم العربية", "An Arabic-capable document"),
    ],
    [
      "pptx",
      <Presentation size={21} />,
      "PowerPoint",
      t("شرائح قابلة للتحرير", "Editable presentation slides"),
    ],
    [
      "xlsx",
      <FileSpreadsheet size={21} />,
      "Excel",
      t("جدول بيانات من CSV", "A workbook from CSV data"),
    ],
  ];
  return (
    <section className="management">
      <span className="eyebrow">NEXORA FILE STUDIO</span>
      <h1>
        {t("من الأفكار إلى ملفات حقيقية.", "From ideas to real deliverables.")}
      </h1>
      <p>
        {t(
          "اكتب محتواك أو الصق إجابة من المحادثة، ثم أنشئ ملفًا قابلًا للتنزيل. تُعالج الملفات داخل متصفحك.",
          "Write your content or paste an answer from chat, then create a downloadable file. Files are processed in your browser.",
        )}
      </p>
      <div className={styles.formats}>
        {formats.map(([id, icon, label, description]) => (
          <button
            key={id}
            className={`${styles.format} ${kind === id ? styles.selected : ""}`}
            onClick={() => {
              setKind(id);
              setNotice("");
            }}
            disabled={busy}
            aria-pressed={kind === id}
          >
            {icon}
            <b>{label}</b>
            <span>{description}</span>
          </button>
        ))}
      </div>
      <div className="panel">
        <label>
          {t("اسم الملف والعنوان", "Document title")}
          <input
            value={title}
            maxLength={120}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={t("تقرير المشروع", "Project report")}
          />
        </label>
        <label>
          {kind === "xlsx"
            ? t(
                "بيانات CSV: الصف الأول أسماء الأعمدة",
                "CSV data: first row contains column names",
              )
            : t("المحتوى", "Content")}
          <textarea
            className={styles.content}
            value={content}
            maxLength={50000}
            onChange={(e) => setContent(e.target.value)}
            rows={12}
            dir={kind === "xlsx" ? "auto" : undefined}
            placeholder={
              kind === "xlsx"
                ? t(
                    "الاسم,الحالة\nالمشروع الأول,قيد التنفيذ",
                    "Name,Status\nProject A,In progress",
                  )
                : kind === "pptx"
                  ? t(
                      "# عنوان القسم الأول\nمحتوى الشريحة الأولى.\n\n# عنوان القسم الثاني\nمحتوى الشريحة التالية.",
                      "# First section\nContent for your first slide.\n\n# Second section\nContent for the next slide.",
                    )
                  : t("اكتب نص المستند هنا…", "Write your document here…")
            }
          />
        </label>
        <div className={styles.actions}>
          <div>
            <span className="fine">
              <ShieldCheck size={14} />
              {t(
                "معالجة محلية · لا حاجة إلى مفتاح API",
                "Processed locally · No API key required",
              )}
            </span>
            <small>
              {kind === "pptx"
                ? t(
                    "افصل الأقسام بسطر فارغ، واستخدم # لعنوان اختياري. حتى 30 قسمًا.",
                    "Separate sections with a blank line and optionally start headings with #. Up to 30 sections.",
                  )
                : kind === "xlsx"
                  ? t(
                      "حتى 1000 صف و30 عمودًا. الخلايا نصية؛ لن تُنفذ كمعادلات.",
                      "Up to 1,000 rows and 30 columns. Cells remain text and never execute as formulas.",
                    )
                  : t(
                      "يتضمن الملف خط Amiri المرخص. لا يدعم الرموز التعبيرية.",
                      "PDF embeds the licensed Amiri font. Emoji are not supported.",
                    )}
            </small>
          </div>
          <button
            className="primary"
            onClick={create}
            disabled={busy || !content.trim()}
          >
            <Download size={16} />
            {busy
              ? t("جارٍ إنشاء الملف…", "Creating file…")
              : t(
                  `تنزيل ${kind.toUpperCase()}`,
                  `Download ${kind.toUpperCase()}`,
                )}
          </button>
        </div>
        {notice && (
          <div className="notice" role="status">
            {notice}
          </div>
        )}
      </div>
    </section>
  );
}
