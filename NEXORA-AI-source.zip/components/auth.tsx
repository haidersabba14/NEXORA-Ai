"use client";
import { useState } from "react";
import type { SupabaseClient } from "@supabase/supabase-js";
import { LockKeyhole, Mail, ArrowRight, ShieldCheck } from "lucide-react";
import Turnstile from "./turnstile";
import { request, Profile } from "@/lib/client";
export default function Auth({
  auth,
  profile,
  siteKey,
  ar,
  onDone,
}: {
  auth: SupabaseClient | null;
  profile: Profile | null;
  siteKey: string | null;
  ar: boolean;
  onDone: () => Promise<void>;
}) {
  const [mode, setMode] = useState(
      typeof window !== "undefined" &&
        new URLSearchParams(location.search).has("reset")
        ? "password"
        : "login",
    ),
    [email, setEmail] = useState(""),
    [password, setPassword] = useState(""),
    [token, setToken] = useState(""),
    [reset, setReset] = useState(0),
    [code, setCode] = useState(""),
    [factor, setFactor] = useState<{ id: string; qr: string } | null>(null),
    [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(false);
  const t = (a: string, e: string) => (ar ? a : e);
  async function run(fn: () => Promise<void>) {
    setBusy(true);
    setNotice("");
    try {
      await fn();
    } catch (e) {
      setNotice(e instanceof Error ? e.message : "AUTH_FAILED");
    } finally {
      setBusy(false);
      setToken("");
      setReset((x) => x + 1);
    }
  }
  async function submit() {
    if (!auth) return;
    await run(async () => {
      if (mode === "signup") {
        const { error } = await auth.auth.signUp({
          email,
          password,
          options: { captchaToken: token, emailRedirectTo: location.origin },
        });
        if (error) throw error;
        setNotice(
          t(
            "تحقق من بريدك لتفعيل الحساب.",
            "Check your email to confirm your account.",
          ),
        );
      } else if (mode === "reset") {
        const { error } = await auth.auth.resetPasswordForEmail(email, {
          captchaToken: token,
          redirectTo: location.origin + "/?reset=1",
        });
        if (error) throw error;
        setNotice(
          t(
            "إذا كان الحساب موجودًا ستصلك رسالة الاسترجاع.",
            "If the account exists, a recovery email will arrive.",
          ),
        );
      } else if (mode === "password") {
        const { error } = await auth.auth.updateUser({ password });
        if (error) throw error;
        setNotice(t("تم تغيير كلمة المرور.", "Password updated."));
        setMode("login");
        window.history.replaceState(null, "", location.pathname);
        await onDone();
      } else {
        const { error } = await auth.auth.signInWithPassword({
          email,
          password,
          options: { captchaToken: token },
        });
        if (error) throw error;
        await onDone();
      }
    });
  }
  async function enroll() {
    if (!auth) return;
    await run(async () => {
      const list = await auth.auth.mfa.listFactors();
      if (list.error) throw list.error;
      const verified = list.data.totp.find((x) => x.status === "verified");
      if (verified) {
        setFactor({ id: verified.id, qr: "" });
        return;
      }
      for (const old of list.data.all.filter(
        (x) => x.factor_type === "totp" && x.status === "unverified",
      ))
        await auth.auth.mfa.unenroll({ factorId: old.id });
      const { data, error } = await auth.auth.mfa.enroll({
        factorType: "totp",
        friendlyName: "NEXORA Authenticator",
      });
      if (error) throw error;
      setFactor({ id: data.id, qr: data.totp.qr_code });
    });
  }
  async function verify() {
    if (!auth || !factor) return;
    await run(async () => {
      const { error } = await auth.auth.mfa.challengeAndVerify({
        factorId: factor.id,
        code,
      });
      if (error) throw error;
      await auth.auth.refreshSession();
      await onDone();
    });
  }
  if (profile?.aal === "aal2" && mode !== "password")
    return (
      <div className="panel auth-panel">
        <ShieldCheck size={40} />
        <h2>{t("حسابك محمي", "Your account is protected")}</h2>
        <p>{profile.email}</p>
      </div>
    );
  return (
    <div className="panel auth-panel">
      <div className="icon-tile">
        <LockKeyhole />
      </div>
      <span className="eyebrow">NEXORA ACCOUNT</span>
      <h2>
        {profile
          ? t("تأمين حسابك بخطوتين", "Secure your workspace")
          : t("أهلًا بك في NEXORA", "Welcome to NEXORA")}
      </h2>
      <p>
        {profile
          ? t(
              "استخدم Google أو Microsoft Authenticator. المصادقة مطلوبة للوصول إلى بياناتك.",
              "Use Google or Microsoft Authenticator. MFA protects every data request.",
            )
          : t(
              "مساحة واحدة لأفضل نماذج الذكاء الاصطناعي.",
              "One workspace for the world’s leading AI models.",
            )}
      </p>
      {!auth ? (
        <div className="notice">
          {t(
            "خدمة الحسابات لم تُضبط بعد. لن يتم إنشاء حساب تجريبي.",
            "Authentication is not configured yet. No demo account will be created.",
          )}
        </div>
      ) : profile && mode !== "password" ? (
        <>
          <button className="primary" disabled={busy} onClick={enroll}>
            {t("إعداد أو تحقق من المصادقة", "Set up or verify authenticator")}
          </button>
          {factor && (
            <>
              {factor.qr && (
                <>
                  <img
                    className="qr"
                    src={
                      factor.qr.startsWith("data:")
                        ? factor.qr
                        : "data:image/svg+xml;charset=utf-8," +
                          encodeURIComponent(factor.qr)
                    }
                    alt="Authenticator QR"
                  />
                  <p>
                    {t(
                      "امسح الرمز بتطبيق المصادقة ثم أدخل الرمز.",
                      "Scan with your authenticator, then enter the code.",
                    )}
                  </p>
                </>
              )}
              <input
                inputMode="numeric"
                autoComplete="one-time-code"
                placeholder="000000"
                maxLength={6}
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
              />
              <button
                className="primary"
                disabled={busy || code.length !== 6}
                onClick={verify}
              >
                {t("تحقق وادخل", "Verify & continue")}
              </button>
            </>
          )}
          <details>
            <summary>
              {t("فقدت تطبيق المصادقة؟", "Lost your authenticator?")}
            </summary>
            <p>
              {t(
                "سجّل الدخول بكلمة المرور خلال آخر 5 دقائق ثم استخدم رمز استرداد سبق حفظه.",
                "Sign in with your password within the last 5 minutes, then use a saved recovery code.",
              )}
            </p>
            <input
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="Recovery code"
              autoComplete="off"
            />
            <button
              disabled={busy || !profile.recoveryEnabled}
              onClick={() =>
                run(async () => {
                  await request(auth, "/recovery/redeem", {
                    method: "POST",
                    body: JSON.stringify({ code }),
                  });
                  await auth.auth.signOut({ scope: "global" });
                  setFactor(null);
                  await onDone();
                  setNotice(
                    t(
                      "سجّل الدخول مجددًا لإعداد مصادقة جديدة.",
                      "Sign in again to enroll a new authenticator.",
                    ),
                  );
                })
              }
            >
              {t("استخدام رمز الاسترداد", "Use recovery code")}
            </button>
            {!profile.recoveryEnabled && (
              <p>
                {t(
                  "يحتاج الاسترداد إعداد الخدمة بواسطة المسؤول.",
                  "Recovery requires administrator configuration.",
                )}
              </p>
            )}
          </details>
          <button
            onClick={() =>
              run(async () => {
                await auth.auth.signOut();
                await onDone();
              })
            }
          >
            {t("تسجيل الخروج", "Sign out")}
          </button>
        </>
      ) : (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void submit();
          }}
        >
          {mode !== "password" && (
            <div className="segmented">
              {[
                ["login", t("دخول", "Sign in")],
                ["signup", t("حساب جديد", "Sign up")],
              ].map(([id, label]) => (
                <button
                  type="button"
                  className={mode === id ? "selected" : ""}
                  key={id}
                  onClick={() => setMode(id)}
                >
                  {label}
                </button>
              ))}
            </div>
          )}
          {mode !== "password" && (
            <label>
              <span>{t("البريد الإلكتروني", "Email address")}</span>
              <input
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
              />
            </label>
          )}
          {mode !== "reset" && (
            <label>
              <span>{t("كلمة المرور", "Password")}</span>
              <input
                type="password"
                required
                minLength={mode === "signup" || mode === "password" ? 12 : 1}
                autoComplete={
                  mode === "signup" || mode === "password"
                    ? "new-password"
                    : "current-password"
                }
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
              />
            </label>
          )}
          {!siteKey && mode !== "password" && (
            <div className="notice">
              {t(
                "التحقق الأمني غير مُعدّ. يحتاج المسؤول إلى ضبط Turnstile قبل تسجيل الدخول.",
                "Security verification is not configured. An administrator must configure Turnstile before sign-in.",
              )}
            </div>
          )}
          {siteKey && mode !== "password" && (
            <Turnstile
              siteKey={siteKey}
              action="auth"
              onToken={setToken}
              resetKey={reset}
            />
          )}
          <button
            className="primary"
            disabled={
              busy ||
              (!token && mode !== "password") ||
              (!siteKey && mode !== "password")
            }
            type="submit"
          >
            {busy
              ? t("جارٍ التحقق…", "Working…")
              : mode === "reset"
                ? t("إرسال رابط الاسترجاع", "Send recovery link")
                : mode === "signup"
                  ? t("إنشاء حساب", "Create account")
                  : mode === "password"
                    ? t("حفظ كلمة المرور الجديدة", "Save new password")
                    : t("دخول إلى مساحتك", "Enter your workspace")}{" "}
            <ArrowRight size={16} />
          </button>
          <button
            type="button"
            className="text-button"
            onClick={() => setMode("reset")}
          >
            {t("نسيت كلمة المرور؟", "Forgot password?")}
          </button>
          <button
            type="button"
            onClick={() =>
              run(async () => {
                const { error } = await auth.auth.signInWithOAuth({
                  provider: "google",
                  options: { redirectTo: location.origin },
                });
                if (error) throw error;
              })
            }
          >
            {t("المتابعة باستخدام Google", "Continue with Google")}
          </button>
        </form>
      )}
      {auth &&
        !profile &&
        typeof window !== "undefined" &&
        new URLSearchParams(location.search).has("reset") && (
          <button onClick={() => setMode("password")}>
            {t("تعيين كلمة المرور الجديدة", "Set new password")}
          </button>
        )}
      {notice && (
        <div role="status" className="notice">
          {notice}
        </div>
      )}
      <div className="fine">
        <ShieldCheck size={13} />
        {t(
          "تشفير أثناء النقل · حماية TOTP",
          "Encrypted in transit · TOTP protected",
        )}
      </div>
    </div>
  );
}
