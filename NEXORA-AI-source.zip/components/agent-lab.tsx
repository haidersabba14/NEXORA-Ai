"use client";
import { useEffect, useRef, useState } from "react";
import type { SupabaseClient } from "@supabase/supabase-js";
import Markdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  Activity,
  ArrowUpRight,
  Download,
  Layers3,
  Square,
  Trash2,
} from "lucide-react";
import { agentTemplates, type AgentTemplateId } from "@/lib/agent-templates";
import { consumeEvents, download, providerNames, request } from "@/lib/client";
import Turnstile from "./turnstile";
interface Run {
  id: string;
  template: string;
  provider: string;
  task: string;
  status: string;
  created_at: string;
  error_code?: string | null;
}
interface Step {
  id: string;
  position: number;
  role: string;
  provider: string;
  model: string;
  content: string;
  status: string;
  charged_usd?: number;
  estimated?: boolean;
}
export default function AgentLab({
  ar,
  auth,
  turnstileSiteKey,
}: {
  ar: boolean;
  auth: SupabaseClient | null;
  turnstileSiteKey: string | null;
}) {
  const [template, setTemplate] = useState<AgentTemplateId>("hive"),
    [provider, setProvider] = useState("openai"),
    [specialists, setSpecialists] = useState(3),
    [task, setTask] = useState(""),
    [token, setToken] = useState(""),
    [reset, setReset] = useState(0),
    [busy, setBusy] = useState(false),
    [steps, setSteps] = useState<Step[]>([]),
    [runs, setRuns] = useState<Run[]>([]),
    [notice, setNotice] = useState(""),
    [run, setRun] = useState<Run | null>(null),
    [configured, setConfigured] = useState<string[]>([]),
    [budgetEnabled, setBudgetEnabled] = useState(false);
  const abort = useRef<AbortController | null>(null);
  const t = (a: string, e: string) => (ar ? a : e);
  async function refresh() {
    if (!auth) return;
    const list = await request<Run[]>(auth, "/agents/runs");
    setRuns(list);
  }
  useEffect(() => {
    let active = true;
    request<any>(null, "/config")
      .then((c) => {
        if (!active) return;
        setConfigured(
          c.providers.filter((p: any) => p.configured).map((p: any) => p.id),
        );
        setBudgetEnabled(c.budgetEnabled);
      })
      .catch(() => {});
    if (auth) void refresh().catch((e) => setNotice(e.message));
    return () => {
      active = false;
      abort.current?.abort();
    };
  }, [auth]);
  async function load(id: string) {
    setNotice("");
    try {
      const r = await request<any>(auth, "/agents/runs/" + id);
      setRun(r);
      setSteps(
        r.steps.map((s: any) => ({ ...s, estimated: !s.usage_reported })),
      );
      setTask(r.task);
      setTemplate(r.template);
      setProvider(r.provider);
    } catch (e) {
      setNotice(e instanceof Error ? e.message : "RUN_LOAD_FAILED");
    }
  }
  async function start() {
    if (!auth) {
      setNotice(
        t(
          "سجّل الدخول وفعّل المصادقة الثنائية أولًا.",
          "Sign in and verify two-factor authentication first.",
        ),
      );
      return;
    }
    if (!token) {
      setNotice(
        t("أكمل التحقق الأمني أولًا.", "Complete security verification first."),
      );
      return;
    }
    if (!configured.includes(provider)) {
      setNotice(t("هذا المزود غير مُعدّ.", "This provider is not configured."));
      return;
    }
    if (!budgetEnabled) {
      setNotice(
        t(
          "ميزانية التشغيل لم تُفعّل.",
          "A spending budget has not been enabled.",
        ),
      );
      return;
    }
    setBusy(true);
    setNotice("");
    setSteps([]);
    setRun(null);
    const controller = new AbortController();
    abort.current = controller;
    try {
      const session = (await auth.auth.getSession()).data.session;
      if (!session) throw Error("AUTH_REQUIRED");
      const response = await fetch("/api/agents/runs", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + session.access_token,
        },
        body: JSON.stringify({
          template,
          provider,
          task,
          specialists,
          turnstileToken: token,
        }),
        signal: controller.signal,
      });
      if (!response.ok) {
        const e = (await response.json()) as any;
        throw Error(e.error || "RUN_FAILED");
      }
      let finished = false;
      await consumeEvents(response, (event, data) => {
        if (event === "run")
          setRun({
            id: data.id,
            template,
            provider,
            task,
            status: "running",
            created_at: new Date().toISOString(),
          });
        if (event === "step")
          setSteps((prev) => [...prev, { ...data, content: "" }]);
        if (event === "delta")
          setSteps((prev) =>
            prev.map((s) =>
              s.id === data.id ? { ...s, content: s.content + data.text } : s,
            ),
          );
        if (event === "step_done")
          setSteps((prev) =>
            prev.map((s) =>
              s.id === data.id
                ? {
                    ...s,
                    status: data.status,
                    charged_usd: data.chargedUsd,
                    estimated: data.estimated,
                  }
                : s,
            ),
          );
        if (event === "error") setNotice(data.error);
        if (event === "done") {
          finished = true;
          setRun((prev) => (prev ? { ...prev, status: data.status } : prev));
        }
      });
      if (!finished && !controller.signal.aborted)
        throw Error("STREAM_INTERRUPTED");
    } catch (e) {
      if (controller.signal.aborted) {
        setNotice(
          t(
            "توقف التشغيل. النتائج الجزئية محفوظة، وقد تُحتسب تكلفتها.",
            "Run stopped. Partial results are saved and may retain a reserved charge.",
          ),
        );
        setRun((prev) => (prev ? { ...prev, status: "cancelled" } : prev));
      } else setNotice(e instanceof Error ? e.message : "RUN_FAILED");
    } finally {
      setBusy(false);
      abort.current = null;
      setToken("");
      setReset((x) => x + 1);
      await refresh().catch(() => {});
    }
  }
  const selected = agentTemplates.find((x) => x.id === template)!;
  return (
    <section className="management agent-lab">
      <span className="eyebrow">NEXORA SPECIALIST LAB</span>
      <h1>{t("مجلس الذكاء الاصطناعي", "Your AI specialist council")}</h1>
      <p>
        {t(
          "وكلاء متخصصون يحللون ويراجعون ويجمعون نتيجة واحدة باستخدام استدعاءات حقيقية للنموذج الذي تختاره.",
          "Specialists analyze, challenge and synthesize using real calls to your selected model.",
        )}
      </p>
      <div className="panel boundary">
        <Layers3 size={21} />
        <div>
          <b>{t("تشغيل محدود وواضح", "Bounded and transparent execution")}</b>
          <p>
            {t(
              "كل تشغيل يستخدم من 2 إلى 4 استدعاءات منفصلة ومحتسبة. النتائج تحليلات أو مقترحات كود وخطط؛ لا ينفذ هذا المختبر كودًا ولا يتحكم بمواقع أو حسابات أو خوادم، ولا يدرب نماذج ولا يشغّل مهامًا مجدولة.",
              "Each run makes 2–4 separately budgeted calls. Results are analyses, code proposals and plans. This lab does not execute code, control external accounts or servers, train models, or schedule background work.",
            )}
          </p>
        </div>
      </div>
      <div className="agent-layout">
        <div>
          <div className="panel">
            <label>
              {t("نوع المختبر", "Lab template")}
              <select
                disabled={busy}
                value={template}
                onChange={(e) => setTemplate(e.target.value as AgentTemplateId)}
              >
                {agentTemplates.map((x) => (
                  <option key={x.id} value={x.id}>
                    {ar ? x.ar : x.name}
                  </option>
                ))}
              </select>
            </label>
            <p className="fine">
              {ar ? selected.descriptionAr : selected.description}
            </p>
            <div className="agent-options">
              <label>
                {t("المزود", "Provider")}
                <select
                  disabled={busy}
                  value={provider}
                  onChange={(e) => setProvider(e.target.value)}
                >
                  {Object.entries(providerNames).map(([id, name]) => (
                    <option value={id} key={id}>
                      {name}
                      {configured.includes(id)
                        ? ""
                        : t(" · يحتاج إعدادًا", " · setup required")}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                {t("المتخصصون", "Specialists")}
                <select
                  disabled={busy}
                  value={specialists}
                  onChange={(e) => setSpecialists(Number(e.target.value))}
                >
                  {[2, 3, 4].map((n) => (
                    <option value={n} key={n}>
                      {n}
                    </option>
                  ))}
                </select>
              </label>
            </div>
            <label>
              {t("المهمة والبيانات المتاحة", "Task and available evidence")}
              <textarea
                rows={7}
                value={task}
                minLength={10}
                maxLength={12000}
                disabled={busy}
                onChange={(e) => setTask(e.target.value)}
                placeholder={t(
                  "صف المشكلة، والهدف، والقيود، والبيانات التي يمكن الاعتماد عليها…",
                  "Describe the problem, goal, constraints and evidence the specialists may rely on…",
                )}
              />
            </label>
            {turnstileSiteKey && (
              <Turnstile
                siteKey={turnstileSiteKey}
                action="chat"
                onToken={setToken}
                resetKey={reset}
              />
            )}
            <div className="agent-actions">
              <button
                className="primary"
                disabled={busy || task.trim().length < 10}
                onClick={start}
              >
                <ArrowUpRight size={16} />
                {t("تشغيل المتخصصين", "Run specialists")}
              </button>
              {busy && (
                <button
                  className="danger"
                  onClick={() => abort.current?.abort()}
                >
                  <Square size={15} />
                  {t("إيقاف", "Stop")}
                </button>
              )}
            </div>
            {(!configured.length || !budgetEnabled) && (
              <p className="fine">
                {t(
                  "التشغيل ينتظر مفاتيح المزودين والنماذج والأسعار والميزانية. لا توجد نتائج تجريبية.",
                  "Execution requires configured provider keys, models, prices and a budget. No demo results are generated.",
                )}
              </p>
            )}
          </div>
          <div className="panel">
            <div className="section-heading">
              <h3>{t("التشغيلات المحفوظة", "Saved runs")}</h3>
              {runs.some(
                (r) =>
                  r.status === "running" &&
                  Date.parse(r.created_at) < Date.now() - 600000,
              ) && (
                <button
                  disabled={busy}
                  onClick={async () => {
                    try {
                      const result = await request<{ released: number }>(
                        auth,
                        "/agents/reconcile",
                        { method: "POST", body: "{}" },
                      );
                      setNotice(
                        t(
                          "تم إنهاء التشغيلات المنقطعة: ",
                          "Interrupted runs released: ",
                        ) + result.released,
                      );
                      await refresh();
                    } catch (e) {
                      setNotice(
                        e instanceof Error ? e.message : "RECONCILE_FAILED",
                      );
                    }
                  }}
                >
                  {t("معالجة المنقطع", "Recover interrupted runs")}
                </button>
              )}
            </div>
            {runs.length ? (
              runs.map((r) => (
                <div className="saved-run" key={r.id}>
                  <button disabled={busy} onClick={() => load(r.id)}>
                    <span>{r.task}</span>
                    <small>
                      {r.template} · {r.status}
                    </small>
                  </button>
                  <button
                    aria-label="Delete run"
                    disabled={busy || r.status === "running"}
                    onClick={async () => {
                      if (
                        !window.confirm(
                          t(
                            "حذف هذا التشغيل؟ تبقى سجلات التكلفة.",
                            "Delete this run? Billing records remain.",
                          ),
                        )
                      )
                        return;
                      try {
                        await request(auth, "/agents/runs/" + r.id, {
                          method: "DELETE",
                          body: "{}",
                        });
                        await refresh();
                        if (run?.id === r.id) {
                          setRun(null);
                          setSteps([]);
                        }
                      } catch (e) {
                        setNotice(
                          e instanceof Error ? e.message : "DELETE_FAILED",
                        );
                      }
                    }}
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              ))
            ) : (
              <p className="fine">
                {t("لم تُحفظ تشغيلات بعد.", "No saved runs yet.")}
              </p>
            )}
          </div>
        </div>
        <div>
          <div className="panel">
            <div className="section-heading">
              <h3>
                <Activity size={18} />
                {t("مراحل العمل", "Specialist outputs")}
              </h3>
              {steps.length > 0 && (
                <button
                  onClick={() =>
                    download(
                      "nexora-agent-run.md",
                      `# ${selected.name}\n\n${task}\n\n` +
                        steps
                          .map(
                            (s) => `## ${s.role} (${s.status})\n\n${s.content}`,
                          )
                          .join("\n\n"),
                    )
                  }
                >
                  <Download size={15} />
                  {t("تصدير", "Export")}
                </button>
              )}
            </div>
            {run && (
              <p className="fine">
                {t("الحالة", "Status")}: {run.status}
              </p>
            )}
            {!steps.length && (
              <p>
                {t(
                  "تظهر هنا مخرجات المزود الحقيقية بعد التشغيل. الوكلاء لا يملكون أدوات تنفيذ خارجية في هذا الإصدار.",
                  "Actual provider outputs appear here after a run. Specialists have no external execution tools in this version.",
                )}
              </p>
            )}
            {steps.map((s) => (
              <article className="agent-step" key={s.id}>
                <div className="agent-step-title">
                  <b>
                    {s.position + 1}. {s.role}
                  </b>
                  <span>{s.status}</span>
                </div>
                <small>
                  {providerNames[s.provider]} · {s.model}
                  {s.charged_usd !== undefined
                    ? ` · $${s.charged_usd.toFixed(5)}${s.estimated ? " (estimated)" : ""}`
                    : ""}
                </small>
                <div className="markdown">
                  <Markdown remarkPlugins={[remarkGfm]}>
                    {s.content || t("جارٍ التوليد…", "Generating…")}
                  </Markdown>
                </div>
              </article>
            ))}
          </div>
          {notice && (
            <div className="notice" role="status">
              {notice}
            </div>
          )}
        </div>
      </div>
      <style jsx>{`
        .agent-layout {
          display: grid;
          grid-template-columns: minmax(260px, 0.8fr) minmax(0, 1.2fr);
          gap: 20px;
          margin-top: 25px;
        }
        .boundary {
          display: flex;
          align-items: flex-start;
          gap: 15px;
          margin-top: 24px;
        }
        .boundary > svg {
          flex-shrink: 0;
          color: #a892db;
        }
        .boundary b {
          font-size: 13px;
        }
        .boundary p {
          font-size: 12px;
          margin: 7px 0 0;
        }
        .agent-options {
          display: grid;
          grid-template-columns: 1fr 90px;
          gap: 14px;
        }
        .agent-actions {
          display: flex;
          gap: 10px;
          margin-top: 12px;
        }
        .agent-actions button {
          font-size: 12px;
        }
        .saved-run {
          display: flex;
          border-top: 1px solid #252735;
          padding: 8px 0;
          align-items: center;
        }
        .saved-run > button {
          background: none;
          border: 0;
          padding: 7px;
        }
        .saved-run > button:first-child {
          flex: 1;
          display: block;
          text-align: start;
          min-width: 0;
        }
        .saved-run span {
          display: block;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          font-size: 12px;
        }
        .saved-run small {
          display: block;
          margin-top: 5px;
        }
        .agent-step {
          border-top: 1px solid #2c2b3a;
          padding: 20px 0;
        }
        .agent-step-title {
          display: flex;
          justify-content: space-between;
          gap: 10px;
          font-size: 12px;
          margin-bottom: 7px;
        }
        .agent-step-title span {
          font-size: 10px;
          color: #9b8abd;
        }
        .agent-step .markdown {
          margin-top: 16px;
        }
        .agent-lab textarea {
          width: 100%;
          font-size: 13px;
          line-height: 1.8;
          resize: vertical;
          min-height: 140px;
        }
        .agent-lab .section-heading {
          align-items: center;
        }
        .agent-lab .section-heading button {
          font-size: 10px;
          padding: 7px 10px;
        }
        @media (max-width: 1000px) {
          .agent-layout {
            grid-template-columns: 1fr;
          }
        }
        @media (max-width: 580px) {
          .agent-lab textarea {
            font-size: 16px;
          }
          .agent-options {
            grid-template-columns: minmax(0, 1fr) 90px;
          }
          .boundary {
            gap: 10px;
          }
          .boundary p {
            font-size: 11px;
          }
          .agent-actions {
            flex-wrap: wrap;
          }
        }
      `}</style>
    </section>
  );
}
