"use client";
import { useEffect, useRef } from "react";
declare global {
  interface Window {
    turnstile?: {
      render: (el: HTMLElement, options: Record<string, unknown>) => string;
      remove: (id: string) => void;
    };
  }
}
let loading: Promise<void> | null = null;
function load() {
  if (window.turnstile) return Promise.resolve();
  if (!loading)
    loading = new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src =
        "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit";
      script.async = true;
      script.onload = () => resolve();
      script.onerror = () => {
        loading = null;
        reject(Error("CAPTCHA_LOAD_FAILED"));
      };
      document.head.appendChild(script);
    });
  return loading;
}
export default function Turnstile({
  siteKey,
  action,
  onToken,
  resetKey = 0,
}: {
  siteKey: string;
  action: string;
  onToken: (token: string) => void;
  resetKey?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const callback = useRef(onToken);
  callback.current = onToken;
  useEffect(() => {
    let id: string | undefined,
      disposed = false;
    load()
      .then(() => {
        if (!disposed && ref.current)
          id = window.turnstile!.render(ref.current, {
            sitekey: siteKey,
            theme: "dark",
            action,
            callback: (token: string) => callback.current(token),
            "expired-callback": () => callback.current(""),
            "error-callback": () => callback.current(""),
          });
      })
      .catch(() => callback.current(""));
    return () => {
      disposed = true;
      if (id) window.turnstile?.remove(id);
    };
  }, [siteKey, action, resetKey]);
  return <div className="captcha" ref={ref} />;
}
