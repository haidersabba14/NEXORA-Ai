"use client";
import { useState, useEffect } from "react";
import type { SupabaseClient } from "@supabase/supabase-js";
import dynamic from "next/dynamic";
import { request, providerNames } from "@/lib/client";
import Turnstile from "./turnstile";
const FileStudio = dynamic(() => import("./file-studio"), {
  loading: () => <p>Loading file tools…</p>,
});
const AgentLab = dynamic(() => import("./agent-lab"), {
  loading: () => <p>Loading agent lab…</p>,
});
export default function CapabilitiesHub({
  ar,
  auth,
  siteKey,
  authorized,
  onSignIn,
}: {
  ar: boolean;
  auth: SupabaseClient | null;
  siteKey: string | null;
  authorized: boolean;
  onSignIn: () => void;
}) {
  const [tab, setTab] = useState("agents");
  const t = (a: string, e: string) => (ar ? a : e);
  return (
    <section className="management">
      <span className="eyebrow">NEXORA GOD MODE · CAPABILITY CENTER</span>
      <h1>{t("مختبر الإمكانات", "Capability center")}</h1>
      <p>
        {t(
          "كل قدرة لها صلاحيات وميزانية وحدود واضحة. الاسم لا يمنح تحكمًا مطلقًا أو تنفيذًا بلا أدوات.",
          "Every capability has explicit permissions, budgets and limits. The name does not grant unrestricted control or execution.",
        )}
      </p>
      <div className="capability-tabs">
        {[
          ["agents", t("مجلس الوكلاء", "Agent council")],
          ["media", t("صور وفيديو", "Images & video")],
          ["files", t("إنشاء الملفات", "File studio")],
          ["automation", t("الأتمتة المستمرة", "Always-on")],
          ["memory", t("الذاكرة والخصوصية", "Memory & privacy")],
        ].map(([id, label]) => (
          <button
            key={id}
            className={tab === id ? "selected" : ""}
            onClick={() => setTab(id)}
          >
            {label}
          </button>
        ))}
      </div>
      {!authorized && tab !== "files" && (
        <div className="panel">
          <h2>
            {t("حساب محمي قبل تشغيل AI", "Secure sign-in before AI execution")}
          </h2>
          <p>
            {t(
              "إنشاء الملفات يعمل محليًا. بقية القدرات تتطلب حسابًا بمصادقة ثنائية وخدمات مُعدّة.",
              "File creation runs locally. Other capabilities require MFA and configured services.",
            )}
          </p>
          <button className="primary" onClick={onSignIn}>
            {t("تسجيل الدخول", "Sign in")}
          </button>
        </div>
      )}
      {authorized && tab === "agents" && (
        <AgentLab ar={ar} auth={auth} turnstileSiteKey={siteKey} />
      )}{" "}
      {tab === "files" && <FileStudio ar={ar} />}{" "}
      {authorized && tab === "media" && (
        <MediaStudio ar={ar} auth={auth} siteKey={siteKey} />
      )}{" "}
      {authorized && tab === "memory" && <MemorySettings ar={ar} auth={auth} />}{" "}
      {authorized && tab === "automation" && (
        <AutomationSettings ar={ar} auth={auth} siteKey={siteKey} />
      )}
      <div className="panel capability-boundary">
        <h3>
          {t(
            "القدرات التي تتطلب بنية إضافية",
            "Capabilities requiring additional infrastructure",
          )}
        </h3>
        <p>
          {t(
            "تشغيل كود غير موثوق أو نشر تطبيقات من داخل NEXORA يحتاج صندوق عزل وخدمات نشر موصولة. تدريب نماذج خاصة يحتاج بيانات مرخّصة وخوادم GPU. تعديل الأنظمة والفواتير وإرسال رسائل خارجية يحتاج تكاملات وصلاحيات منفصلة. مخرجات المحاكاة والبحث العلمي والتنبؤات فرضيات تحتاج تحققًا، وليست نتائج تجارب حقيقية أو ضمانات.",
            "Executing untrusted code or deploying apps from NEXORA requires a sandbox and connected deployment services. Private model training requires licensed data and GPU infrastructure. System changes, invoices and external messages require separate integrations and permissions. Simulation, science and forecast outputs are hypotheses requiring validation, not completed experiments or guarantees.",
          )}
        </p>
      </div>
    </section>
  );
}
function MemorySettings({
  ar,
  auth,
}: {
  ar: boolean;
  auth: SupabaseClient | null;
}) {
  const [enabled, setEnabled] = useState(false),
    [content, setContent] = useState(""),
    [notice, setNotice] = useState("");
  useEffect(() => {
    request(auth, "/memory")
      .then((r) => {
        setEnabled(!!r.enabled);
        setContent(r.content);
      })
      .catch((e) => setNotice(e.message));
  }, [auth]);
  return (
    <div className="panel">
      <h2>{ar ? "ذاكرة تختارها أنت" : "Memory you control"}</h2>
      <p>
        {ar
          ? "الذاكرة معطلة افتراضيًا. عند تفعيلها ترسل التفضيلات مع محادثاتك إلى المزود المختار؛ لا تضف كلمات مرور أو أسرارًا. لا تُستخرج ذكريات تلقائيًا."
          : "Memory is off by default. Enabled preferences are sent with chats to your selected provider. Do not add secrets. Memories are not extracted automatically."}
      </p>
      <label className="inline-check">
        <input
          type="checkbox"
          checked={enabled}
          onChange={(e) => setEnabled(e.target.checked)}
        />
        {ar
          ? "استخدام تفضيلاتي في المحادثات"
          : "Use my preferences in conversations"}
      </label>
      <textarea
        rows={5}
        maxLength={3000}
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder={
          ar
            ? "اللغة، أسلوب الإجابة، تفضيلات العمل…"
            : "Language, response style, work preferences…"
        }
      />
      <div className="button-row">
        <button
          className="primary"
          onClick={async () => {
            try {
              await request(auth, "/memory", {
                method: "PUT",
                body: JSON.stringify({ enabled, content }),
              });
              setNotice(ar ? "تم حفظ الإعدادات" : "Saved");
            } catch (e) {
              setNotice((e as Error).message);
            }
          }}
        >
          {ar ? "حفظ" : "Save"}
        </button>
        <button
          className="danger"
          onClick={async () => {
            try {
              await request(auth, "/memory", { method: "DELETE", body: "{}" });
              setEnabled(false);
              setContent("");
              setNotice(ar ? "حُذفت الذاكرة" : "Memory deleted");
            } catch (e) {
              setNotice((e as Error).message);
            }
          }}
        >
          {ar ? "حذف الذاكرة" : "Delete memory"}
        </button>
      </div>
      {notice && <p role="status">{notice}</p>}
    </div>
  );
}
function AutomationSettings({
  ar,
  auth,
  siteKey,
}: {
  ar: boolean;
  auth: SupabaseClient | null;
  siteKey: string | null;
}) {
  const [tasks, setTasks] = useState<any[]>([]),
    [title, setTitle] = useState(""),
    [prompt, setPrompt] = useState(""),
    [provider, setProvider] = useState("openai"),
    [hours, setHours] = useState(24),
    [kind, setKind] = useState("prompt"),
    [token, setToken] = useState(""),
    [reset, setReset] = useState(0),
    [notice, setNotice] = useState("");
  async function refresh() {
    setTasks(await request(auth, "/schedules"));
  }
  useEffect(() => {
    void refresh().catch((e) => setNotice(e.message));
  }, [auth]);
  return (
    <div>
      <div className="panel">
        <h2>NEXORA ALWAYS-ON</h2>
        <p>
          {ar
            ? "مهام مجدولة على Cloudflare Cron؛ نتائجها هنا وفي سجل المحادثات. لا تُرسل رسائل خارجية. فحص الصحة يراقب قاعدة NEXORA فقط؛ مهام النص لا تتصفح المواقع أو تتحكم بخوادم خارجية. الجدولة بالساعة UTC وبحد 24 مهمة للحساب."
            : "Cloudflare Cron runs scheduled jobs; results appear here and in history. No external messages are sent. Health checks cover NEXORA’s database only; text jobs do not browse or control external systems. Hourly UTC scheduling, up to 24 jobs per account."}
        </p>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            try {
              await request(auth, "/schedules", {
                method: "POST",
                body: JSON.stringify({
                  title,
                  prompt,
                  provider,
                  intervalHours: hours,
                  kind,
                  turnstileToken: token,
                }),
              });
              await refresh();
              setTitle("");
              setPrompt("");
              setNotice(ar ? "تمت جدولة المهمة" : "Task scheduled");
            } catch (e) {
              setNotice((e as Error).message);
            } finally {
              setToken("");
              setReset((x) => x + 1);
            }
          }}
        >
          <label>
            {ar ? "اسم المهمة" : "Task name"}
            <input
              required
              maxLength={100}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </label>
          <label>
            {ar ? "نوع المهمة" : "Task type"}
            <select value={kind} onChange={(e) => setKind(e.target.value)}>
              <option value="prompt">
                {ar ? "تحليل AI مجدول" : "Scheduled AI analysis"}
              </option>
              <option value="health">
                {ar
                  ? "فحص قاعدة بيانات NEXORA"
                  : "NEXORA database health check"}
              </option>
            </select>
          </label>
          <label>
            {ar ? "تعليمات المهمة" : "Instructions"}
            <textarea
              required
              maxLength={4000}
              rows={3}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
            />
          </label>
          <div className="settings-grid">
            <label>
              {ar ? "المزود" : "Provider"}
              <select
                value={provider}
                onChange={(e) => setProvider(e.target.value)}
              >
                {Object.keys(providerNames).map((p) => (
                  <option key={p} value={p}>
                    {providerNames[p]}
                  </option>
                ))}
              </select>
            </label>
            <label>
              {ar ? "الفاصل بالساعات" : "Interval in hours"}
              <input
                type="number"
                min={1}
                max={168}
                value={hours}
                onChange={(e) => setHours(Number(e.target.value))}
              />
            </label>
          </div>
          {siteKey && (
            <Turnstile
              siteKey={siteKey}
              action="chat"
              resetKey={reset}
              onToken={setToken}
            />
          )}
          <button className="primary" disabled={!token}>
            {ar ? "جدولة ضمن حصتي" : "Schedule within my quota"}
          </button>
        </form>
        {notice && <p role="status">{notice}</p>}
      </div>
      {tasks.map((task) => (
        <div className="panel" key={task.id}>
          <h3>{task.title}</h3>
          <p>
            {task.last_status || "pending"} ·{" "}
            {ar ? "الموعد التالي" : "Next run"}: {task.next_run}
          </p>
          <div className="button-row">
            <button
              onClick={async () => {
                try {
                  await request(auth, "/schedules/" + task.id, {
                    method: "PATCH",
                    body: JSON.stringify({ enabled: !task.enabled }),
                  });
                  await refresh();
                } catch (e) {
                  setNotice((e as Error).message);
                }
              }}
            >
              {task.enabled
                ? ar
                  ? "إيقاف"
                  : "Pause"
                : ar
                  ? "تفعيل"
                  : "Enable"}
            </button>
            <button
              onClick={async () => {
                try {
                  await request(auth, "/schedules/" + task.id, {
                    method: "DELETE",
                    body: "{}",
                  });
                  await refresh();
                } catch (e) {
                  setNotice((e as Error).message);
                }
              }}
            >
              {ar ? "حذف" : "Delete"}
            </button>
          </div>
          {task.last_output && (
            <details>
              <summary>{ar ? "نتيجة آخر تشغيل" : "Latest result"}</summary>
              <pre className="task-output">{task.last_output}</pre>
            </details>
          )}
        </div>
      ))}
    </div>
  );
}
function MediaStudio({
  ar,
  auth,
  siteKey,
}: {
  ar: boolean;
  auth: SupabaseClient | null;
  siteKey: string | null;
}) {
  const [kind, setKind] = useState("image"),
    [prompt, setPrompt] = useState(""),
    [jobs, setJobs] = useState<any[]>([]),
    [token, setToken] = useState(""),
    [reset, setReset] = useState(0),
    [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(false),
    [capabilities, setCapabilities] = useState<any>(null);
  async function refresh() {
    const result = await request(auth, "/studio/jobs");
    setJobs(Array.isArray(result) ? result : result.jobs || []);
  }
  useEffect(() => {
    void refresh().catch((e) => setNotice(e.message));
    request(auth, "/studio/config")
      .then(setCapabilities)
      .catch(() => {});
  }, [auth]);
  async function asset(job: any) {
    try {
      const session = (await auth!.auth.getSession()).data.session;
      const r = await fetch("/api/studio/jobs/" + job.id + "/artifact", {
        headers: { Authorization: "Bearer " + session!.access_token },
      });
      if (!r.ok) throw Error("DOWNLOAD_FAILED");
      const url = URL.createObjectURL(await r.blob());
      const a = document.createElement("a");
      a.href = url;
      a.download =
        "nexora-" + job.id + (job.kind === "video" ? ".mp4" : ".png");
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (e) {
      setNotice((e as Error).message);
    }
  }
  return (
    <div className="panel">
      <h2>{ar ? "استوديو الصور والفيديو" : "Image & video studio"}</h2>
      <p>
        {ar
          ? "توليد حقيقي عبر OpenAI Images وGoogle Veo. يتطلب إعداد نموذج وتسعير أقصى لكل طلب وR2. قد يستهلك رصيد API مدفوعًا. لا يتم إنشاء نتيجة تجريبية عند غياب الخدمة."
          : "Real generation using OpenAI Images and Google Veo. Requires configured models, per-request cost ceilings and R2. May use paid API credits. Missing services never produce demo results."}
      </p>
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          try {
            await request(
              auth,
              "/studio/" + (kind === "image" ? "images" : "videos"),
              {
                method: "POST",
                body: JSON.stringify({ prompt, turnstileToken: token }),
              },
            );
            await refresh();
            setNotice(
              ar
                ? "سُجل طلب التوليد؛ تحقق من الحالة."
                : "Generation request recorded; check its status.",
            );
          } catch (e) {
            setNotice((e as Error).message);
          } finally {
            setBusy(false);
            setToken("");
            setReset((x) => x + 1);
          }
        }}
      >
        <label>
          {ar ? "النوع" : "Type"}
          <select value={kind} onChange={(e) => setKind(e.target.value)}>
            <option value="image">{ar ? "صورة" : "Image"}</option>
            <option value="video">{ar ? "فيديو" : "Video"}</option>
          </select>
        </label>
        <label>
          {ar ? "الوصف" : "Prompt"}
          <textarea
            rows={4}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            required
            maxLength={4000}
          />
        </label>
        {siteKey && (
          <Turnstile
            siteKey={siteKey}
            action="chat"
            resetKey={reset}
            onToken={setToken}
          />
        )}
        <button
          className="primary"
          disabled={busy || !token || !capabilities?.[kind]?.configured}
        >
          {busy
            ? ar
              ? "جارٍ الطلب…"
              : "Requesting…"
            : ar
              ? "توليد ضمن الميزانية"
              : "Generate within budget"}
        </button>
      </form>
      {!capabilities?.[kind]?.configured && (
        <p className="notice">
          {ar
            ? "هذه القدرة غير مُعدّة؛ يلزم مفتاح النموذج وتسعير وR2."
            : "This capability needs its model key, pricing and R2 configuration."}
        </p>
      )}
      {notice && (
        <div role="status" className="notice">
          {notice}
        </div>
      )}
      {jobs.map((job) => (
        <div key={job.id} className="media-job">
          <b>
            {job.kind} · {job.status}
          </b>
          <small>
            {job.model} · {job.error || job.createdAt}
          </small>
          <div className="button-row">
            {job.status === "running" && (
              <button
                onClick={async () => {
                  try {
                    await request(auth, "/studio/jobs/" + job.id + "/poll", {
                      method: "POST",
                      body: "{}",
                    });
                    await refresh();
                  } catch (e) {
                    setNotice((e as Error).message);
                  }
                }}
              >
                {ar ? "تحديث الحالة" : "Check status"}
              </button>
            )}
            {job.status === "complete" && (
              <button onClick={() => asset(job)}>
                {ar ? "تنزيل الملف" : "Download file"}
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
