"use client";
import { ImagePlus, X } from "lucide-react";
export default function VisionInput({
  ar,
  image,
  onImage,
  onText,
  disabled,
}: {
  ar: boolean;
  image: string;
  onImage: (value: string) => void;
  onText: (text: string) => void;
  disabled: boolean;
}) {
  async function read(file: File) {
    if (file.type.startsWith("image/")) {
      if (file.size > 10000000)
        throw Error(ar ? "الصورة أكبر من 10MB." : "Image exceeds 10MB.");
      const url = URL.createObjectURL(file);
      try {
        const im = new Image();
        im.src = url;
        await im.decode();
        const canvas = document.createElement("canvas");
        const ratio = Math.min(1, 1024 / Math.max(im.width, im.height));
        canvas.width = Math.round(im.width * ratio);
        canvas.height = Math.round(im.height * ratio);
        canvas
          .getContext("2d")!
          .drawImage(im, 0, 0, canvas.width, canvas.height);
        let data = "";
        for (const quality of [0.75, 0.5, 0.3, 0.15]) {
          data = canvas.toDataURL("image/jpeg", quality);
          if (data.length < 125000) break;
        }
        if (data.length >= 125000)
          throw Error(
            ar
              ? "قصّ الصورة لتقليل حجمها."
              : "Crop the image to reduce its size.",
          );
        onImage(data);
      } finally {
        URL.revokeObjectURL(url);
      }
    } else if (/\.(txt|md|csv|json)$/i.test(file.name)) {
      if (file.size > 50000)
        throw Error(ar ? "الملف النصي كبير." : "Text file is too large.");
      onText((await file.text()).slice(0, 18000));
    } else
      throw Error(
        ar
          ? "أرفق صورة أو ملف TXT/MD/CSV/JSON. حوّل صفحات PDF إلى صور للرؤية."
          : "Attach an image or TXT/MD/CSV/JSON. Convert PDF pages to images for vision.",
      );
  }
  return (
    <div className="vision-input">
      <label className="attach-button">
        <ImagePlus size={15} />
        {ar ? "صورة أو مستند نصي" : "Image or text document"}
        <input
          type="file"
          disabled={disabled}
          accept="image/png,image/jpeg,image/webp,.txt,.md,.csv,.json"
          onChange={async (e) => {
            try {
              const f = e.target.files?.[0];
              if (f) await read(f);
            } catch (error) {
              window.alert(
                error instanceof Error ? error.message : "FILE_FAILED",
              );
            } finally {
              e.target.value = "";
            }
          }}
        />
      </label>
      {image && (
        <div className="image-preview">
          <img src={image} alt={ar ? "صورة مرفقة" : "Attached image"} />
          <button
            type="button"
            aria-label="Remove image"
            onClick={() => onImage("")}
          >
            <X size={13} />
          </button>
          <small>
            {ar
              ? "ترسل للمزود المختار؛ لا تحفظ الصورة في سجل المحادثة."
              : "Sent to the selected provider; the image is not stored in chat history."}
          </small>
        </div>
      )}
    </div>
  );
}
