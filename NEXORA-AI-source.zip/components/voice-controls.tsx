"use client";
import { useState, useRef, useEffect } from "react";
import { Mic, MicOff, Volume2, VolumeX } from "lucide-react";
export default function VoiceControls({
  ar,
  onTranscript,
  text,
  disabled,
}: {
  ar: boolean;
  onTranscript: (text: string) => void;
  text: string;
  disabled: boolean;
}) {
  const [available, setAvailable] = useState(false),
    [listening, setListening] = useState(false),
    [speaking, setSpeaking] = useState(false),
    [notice, setNotice] = useState("");
  const recognition = useRef<any>(null);
  useEffect(() => {
    const w = window as any;
    setAvailable(!!(w.SpeechRecognition || w.webkitSpeechRecognition));
    return () => {
      recognition.current?.abort();
      window.speechSynthesis?.cancel();
    };
  }, []);
  function listen() {
    if (listening) {
      recognition.current?.stop();
      return;
    }
    const w = window as any;
    const Speech = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!Speech) return;
    setNotice("");
    const r = new Speech();
    r.lang = ar ? "ar-SA" : "en-US";
    r.continuous = false;
    r.interimResults = false;
    r.onresult = (e: any) => onTranscript(e.results[0][0].transcript);
    r.onend = () => setListening(false);
    r.onerror = (e: any) => {
      setListening(false);
      setNotice(
        e.error === "not-allowed"
          ? ar
            ? "اسمح بالميكروفون من إعدادات المتصفح."
            : "Allow microphone access in your browser settings."
          : ar
            ? "تعذر التعرف الصوتي على هذا المتصفح."
            : "Speech recognition failed in this browser.",
      );
    };
    recognition.current = r;
    try {
      r.start();
      setListening(true);
    } catch {
      setNotice(ar ? "الميكروفون غير متاح." : "Microphone unavailable.");
    }
  }
  function speak() {
    if (!window.speechSynthesis) return;
    if (speaking) {
      speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }
    const utterance = new SpeechSynthesisUtterance(text.slice(0, 10000));
    utterance.lang = ar ? "ar-SA" : "en-US";
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);
    speechSynthesis.speak(utterance);
    setSpeaking(true);
  }
  return (
    <div className="voice-controls">
      <button type="button" disabled={!available || disabled} onClick={listen}>
        {listening ? <MicOff size={15} /> : <Mic size={15} />}{" "}
        {ar ? "تحدث" : "Speak"}
      </button>
      <button type="button" disabled={!text} onClick={speak}>
        {speaking ? <VolumeX size={15} /> : <Volume2 size={15} />}{" "}
        {ar ? "استمع" : "Listen"}
      </button>
      <small>
        {available
          ? ar
            ? "صوت المتصفح؛ اضغط إرسال بعد الإملاء. قد يعالج مزود المتصفح الصوت."
            : "Browser speech; send after dictation. Your browser’s speech provider may process audio."
          : ar
            ? "الإملاء الصوتي غير مدعوم في هذا المتصفح."
            : "Speech input is unavailable in this browser."}
      </small>
      {notice && <small role="status">{notice}</small>}
    </div>
  );
}
