PRAGMA foreign_keys = ON;
CREATE TABLE users (id TEXT PRIMARY KEY, email TEXT NOT NULL, name TEXT NOT NULL DEFAULT '', avatar TEXT NOT NULL DEFAULT '', disabled INTEGER NOT NULL DEFAULT 0, daily_usd REAL NOT NULL DEFAULT 1 CHECK(daily_usd>=0), monthly_usd REAL NOT NULL DEFAULT 10 CHECK(monthly_usd>=0), revoked_before INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')));
CREATE TABLE conversations (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), title TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE INDEX conversations_owner ON conversations(user_id, updated_at);
CREATE TABLE messages (id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE, role TEXT NOT NULL CHECK(role IN ('user','assistant')), content TEXT NOT NULL, provider TEXT, request_id TEXT, status TEXT NOT NULL DEFAULT 'complete', created_at TEXT NOT NULL);
CREATE INDEX messages_conversation ON messages(conversation_id, created_at);
CREATE TABLE requests (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), conversation_id TEXT REFERENCES conversations(id) ON DELETE SET NULL, provider TEXT NOT NULL, model TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'reserved', reserved_usd REAL NOT NULL, charged_usd REAL NOT NULL, input_tokens INTEGER, output_tokens INTEGER, usage_reported INTEGER NOT NULL DEFAULT 0, error_code TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE INDEX requests_usage ON requests(user_id, created_at);
CREATE TABLE rate_limits (key TEXT PRIMARY KEY, count INTEGER NOT NULL, expires_at INTEGER NOT NULL);
CREATE TABLE recovery_codes (user_id TEXT NOT NULL REFERENCES users(id), hash TEXT NOT NULL, used INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(user_id,hash));
CREATE TABLE audit_logs (id TEXT PRIMARY KEY, actor_id TEXT, action TEXT NOT NULL, target_id TEXT, code TEXT, created_at TEXT NOT NULL);
CREATE INDEX audit_time ON audit_logs(created_at);
CREATE TABLE provider_health (provider TEXT PRIMARY KEY, status TEXT NOT NULL, checked_at TEXT NOT NULL, code TEXT);
-- One row serializes quota reservations across users and Worker instances.
CREATE TABLE quota_lock (id INTEGER PRIMARY KEY CHECK(id=1), version INTEGER NOT NULL DEFAULT 0);
INSERT INTO quota_lock(id) VALUES(1);
CREATE TABLE comparison_grants (hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), provider TEXT NOT NULL, expires_at INTEGER NOT NULL);
