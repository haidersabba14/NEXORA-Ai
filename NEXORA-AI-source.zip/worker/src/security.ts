import { createRemoteJWKSet, jwtVerify } from "jose";
import { HTTPException } from "hono/http-exception";
import type { Env, Identity } from "./types";
const jwksCache = new Map<string, ReturnType<typeof createRemoteJWKSet>>();
export function deny(
  code: string,
  status: 401 | 403 | 409 | 429 | 503 = 403,
): never {
  throw new HTTPException(status, { message: code });
}
export async function authenticate(
  request: Request,
  env: Env,
): Promise<Identity> {
  if (!env.SUPABASE_URL || !env.SUPABASE_ANON_KEY)
    deny("AUTH_NOT_CONFIGURED", 503);
  const token = request.headers
    .get("Authorization")
    ?.match(/^Bearer (\S+)$/)?.[1];
  if (!token) deny("AUTH_REQUIRED", 401);
  const issuer = env.SUPABASE_URL.replace(/\/$/, "") + "/auth/v1";
  let claims;
  try {
    let keys = jwksCache.get(issuer);
    if (!keys) {
      keys = createRemoteJWKSet(new URL(issuer + "/.well-known/jwks.json"));
      jwksCache.set(issuer, keys);
    }
    claims = (
      await jwtVerify(token, keys, {
        issuer,
        audience: "authenticated",
        algorithms: ["ES256", "RS256"],
        requiredClaims: ["sub", "iat", "exp"],
      })
    ).payload;
  } catch {
    deny("INVALID_SESSION", 401);
  }
  if (
    !Number.isInteger(claims.iat) ||
    !Number.isInteger(claims.exp) ||
    Number(claims.iat) > Date.now() / 1000 + 30 ||
    Number(claims.exp) <= Number(claims.iat)
  )
    deny("INVALID_SESSION", 401);
  // Check the current auth user as well as the signed JWT. Never trust user_metadata roles.
  let r: Response;
  try {
    r = await fetch(issuer + "/user", {
      headers: {
        Authorization: `Bearer ${token}`,
        apikey: env.SUPABASE_ANON_KEY,
      },
      signal: AbortSignal.timeout(10000),
    });
  } catch {
    deny("AUTH_UNAVAILABLE", 503);
  }
  if (!r.ok) deny("INVALID_SESSION", 401);
  const user = (await r.json()) as any;
  if (!user.id || user.id !== claims.sub || !user.email_confirmed_at)
    deny("EMAIL_VERIFICATION_REQUIRED");
  const row = await env.DB.prepare(
    "SELECT disabled, revoked_before FROM users WHERE id=?",
  )
    .bind(user.id)
    .first<{ disabled: number; revoked_before: number }>();
  if (row?.disabled) deny("ACCOUNT_DISABLED");
  if (row && Number(claims.iat) <= row.revoked_before)
    deny("SESSION_REVOKED", 401);
  return {
    id: user.id,
    email: user.email,
    aal: String(claims.aal || "aal1"),
    iat: Number(claims.iat),
    claims,
    admin: user.app_metadata?.role === "admin",
  };
}
export function requireMFA(identity: Identity) {
  if (identity.aal !== "aal2") deny("MFA_REQUIRED");
}
export async function rateLimit(
  env: Env,
  key: string,
  limit: number,
  seconds: number,
) {
  const now = Math.floor(Date.now() / 1000),
    window = Math.floor(now / seconds),
    bucket = `${key}:${window}`;
  const row = await env.DB.prepare(
    "INSERT INTO rate_limits(key,count,expires_at) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1 RETURNING count",
  )
    .bind(bucket, now + seconds)
    .first<{ count: number }>();
  if (!row || row.count > limit) deny("RATE_LIMITED", 429);
  // Bounded cleanup of expired buckets, never remove an active bucket.
  await env.DB.prepare(
    "DELETE FROM rate_limits WHERE key IN (SELECT key FROM rate_limits WHERE expires_at<? LIMIT 100)",
  )
    .bind(now)
    .run();
}
export async function hashCode(code: string, env: Env, userId: string) {
  if (!env.RECOVERY_PEPPER) deny("RECOVERY_NOT_CONFIGURED", 503);
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(env.RECOVERY_PEPPER),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const hash = await crypto.subtle.sign(
    "HMAC",
    key,
    new TextEncoder().encode(userId + ":" + code.trim().toUpperCase()),
  );
  return Array.from(new Uint8Array(hash), (b) =>
    b.toString(16).padStart(2, "0"),
  ).join("");
}
export async function turnstile(env: Env, token: string, ip: string) {
  if (!env.TURNSTILE_SECRET_KEY) deny("TURNSTILE_NOT_CONFIGURED", 503);
  const r = await fetch(
    "https://challenges.cloudflare.com/turnstile/v0/siteverify",
    {
      method: "POST",
      body: new URLSearchParams({
        secret: env.TURNSTILE_SECRET_KEY,
        response: token,
        remoteip: ip,
      }),
      signal: AbortSignal.timeout(10000),
    },
  );
  const result = (await r.json()) as any;
  if (
    !result.success ||
    result.hostname !== new URL(env.APP_ORIGIN).hostname ||
    result.action !== "chat"
  )
    deny("TURNSTILE_FAILED");
}
