import { z } from "zod";
import { Env, Provider, ModelConfig, ChatMessage, secretNames } from "./types";
const configSchema = z.record(
  z.enum(["openai", "gemini", "deepseek", "anthropic"]),
  z.object({
    model: z.string().min(1).max(100),
    input: z.number().positive().max(1000),
    output: z.number().positive().max(1000),
  }),
);
export function modelConfig(env: Env): Record<Provider, ModelConfig> | null {
  try {
    return configSchema.parse(JSON.parse(env.MODEL_CONFIG_JSON || ""));
  } catch {
    return null;
  }
}
export class ProviderError extends Error {
  constructor(
    public code: string,
    public status = 502,
  ) {
    super(code);
  }
}
export async function* parseSSE(
  body: ReadableStream<Uint8Array>,
): AsyncGenerator<{ event: string; data: string }> {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  try {
    while (true) {
      const { done, value } = await reader.read();
      buffer += decoder.decode(value, { stream: !done });
      if (buffer.length > 2_000_000)
        throw new ProviderError("UPSTREAM_EVENT_TOO_LARGE");
      let match: RegExpExecArray | null;
      while ((match = /\r?\n\r?\n/.exec(buffer))) {
        const block = buffer.slice(0, match.index);
        buffer = buffer.slice(match.index + match[0].length);
        let event = "message";
        const data: string[] = [];
        for (const line of block.split(/\r?\n/)) {
          if (line.startsWith("event:")) event = line.slice(6).trim();
          if (line.startsWith("data:"))
            data.push(line.slice(5).replace(/^ /, ""));
        }
        if (data.length) yield { event, data: data.join("\n") };
      }
      if (done) break;
    }
  } finally {
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}
export interface Chunk {
  text?: string;
  input?: number;
  output?: number;
  done?: boolean;
}
export function extract(provider: Provider, data: any): Chunk {
  if (data.error || data.type === "error")
    throw new ProviderError("PROVIDER_STREAM_ERROR");
  if (provider === "openai") {
    if (data.type === "response.failed" || data.type === "response.incomplete")
      throw new ProviderError("PROVIDER_INCOMPLETE");
    if (data.type === "response.output_text.delta") return { text: data.delta };
    if (data.type === "response.completed")
      return {
        input: data.response?.usage?.input_tokens,
        output: data.response?.usage?.output_tokens,
        done: true,
      };
  }
  if (provider === "deepseek") {
    const c: Chunk = { text: data.choices?.[0]?.delta?.content };
    if (data.usage) {
      c.input = data.usage.prompt_tokens;
      c.output = data.usage.completion_tokens;
    }
    return c;
  }
  if (provider === "gemini") {
    if (data.promptFeedback?.blockReason)
      throw new ProviderError("CONTENT_BLOCKED", 422);
    return {
      text: data.candidates?.[0]?.content?.parts
        ?.map((p: any) => (p.thought ? "" : p.text || ""))
        .join(""),
      input: data.usageMetadata?.promptTokenCount,
      output: data.usageMetadata
        ? (data.usageMetadata.candidatesTokenCount || 0) +
          (data.usageMetadata.thoughtsTokenCount || 0)
        : undefined,
    };
  }
  if (provider === "anthropic") {
    if (data.type === "message_start")
      return { input: data.message?.usage?.input_tokens };
    if (
      data.type === "content_block_delta" &&
      data.delta?.type === "text_delta"
    )
      return { text: data.delta.text };
    if (data.type === "message_delta")
      return { output: data.usage?.output_tokens };
    if (data.type === "message_stop") return { done: true };
  }
  return {};
}
export function providerRequest(
  env: Env,
  provider: Provider,
  model: string,
  messages: ChatMessage[],
  maxTokens: number,
) {
  const key = String(env[secretNames[provider]] || "");
  if (!key) throw new ProviderError("PROVIDER_NOT_CONFIGURED", 503);
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
  };
  let url: string;
  let body: unknown;
  if (provider === "openai") {
    url = "https://api.openai.com/v1/responses";
    headers.Authorization = `Bearer ${key}`;
    body = {
      model,
      input: messages.map((m) =>
        m.image
          ? {
              role: m.role,
              content: [
                { type: "input_text", text: m.content },
                { type: "input_image", image_url: m.image, detail: "low" },
              ],
            }
          : m,
      ),
      stream: true,
      max_output_tokens: maxTokens,
      store: false,
    };
  } else if (provider === "deepseek") {
    if (messages.some((m) => m.image))
      throw new ProviderError("VISION_NOT_SUPPORTED", 422);
    url = "https://api.deepseek.com/chat/completions";
    headers.Authorization = `Bearer ${key}`;
    body = {
      model,
      messages,
      stream: true,
      stream_options: { include_usage: true },
      max_tokens: maxTokens,
    };
  } else if (provider === "gemini") {
    url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse`;
    headers["x-goog-api-key"] = key;
    body = {
      systemInstruction: messages.some((m) => m.role === "system")
        ? {
            parts: [
              {
                text: messages
                  .filter((m) => m.role === "system")
                  .map((m) => m.content)
                  .join("\n"),
              },
            ],
          }
        : undefined,
      contents: messages
        .filter((m) => m.role !== "system")
        .map((m) => ({
          role: m.role === "assistant" ? "model" : "user",
          parts: [
            { text: m.content },
            ...(m.image
              ? [
                  {
                    inlineData: {
                      mimeType: m.image.slice(5, m.image.indexOf(";")),
                      data: m.image.split(",")[1],
                    },
                  },
                ]
              : []),
          ],
        })),
      generationConfig: { maxOutputTokens: maxTokens },
    };
  } else {
    url = "https://api.anthropic.com/v1/messages";
    headers["x-api-key"] = key;
    headers["anthropic-version"] = "2023-06-01";
    body = {
      model,
      system:
        messages
          .filter((m) => m.role === "system")
          .map((m) => m.content)
          .join("\n") || undefined,
      messages: messages
        .filter((m) => m.role !== "system")
        .map((m) =>
          m.image
            ? {
                role: m.role,
                content: [
                  {
                    type: "image",
                    source: {
                      type: "base64",
                      media_type: m.image.slice(5, m.image.indexOf(";")),
                      data: m.image.split(",")[1],
                    },
                  },
                  { type: "text", text: m.content },
                ],
              }
            : m,
        ),
      stream: true,
      max_tokens: maxTokens,
    };
  }
  return { url, init: { method: "POST", headers, body: JSON.stringify(body) } };
}
export async function* generate(
  env: Env,
  provider: Provider,
  model: string,
  messages: ChatMessage[],
  signal: AbortSignal,
  maxTokens = 2048,
): AsyncGenerator<Chunk> {
  const r = providerRequest(env, provider, model, messages, maxTokens);
  let response: Response;
  try {
    response = await fetch(r.url, {
      ...r.init,
      signal: AbortSignal.any([signal, AbortSignal.timeout(120000)]),
    });
  } catch {
    throw new ProviderError(
      signal.aborted ? "CANCELLED" : "PROVIDER_UNREACHABLE",
    );
  }
  if (!response.ok || !response.body) {
    await response.body?.cancel();
    throw new ProviderError(
      response.status === 429
        ? "PROVIDER_RATE_LIMIT"
        : response.status === 401 || response.status === 403
          ? "PROVIDER_AUTH_ERROR"
          : "PROVIDER_REQUEST_FAILED",
      response.status === 429 ? 429 : 502,
    );
  }
  let complete = false;
  for await (const event of parseSSE(response.body)) {
    if (event.data === "[DONE]") {
      complete = true;
      break;
    }
    let data: any;
    try {
      data = JSON.parse(event.data);
    } catch {
      throw new ProviderError("INVALID_PROVIDER_EVENT");
    }
    const c = extract(provider, data);
    if (c.done) complete = true;
    if (
      provider === "gemini" &&
      data.candidates?.some((x: any) => x.finishReason)
    )
      complete = true;
    yield c;
  }
  if (!complete) throw new ProviderError("PROVIDER_STREAM_INTERRUPTED");
}
export async function probe(
  env: Env,
  provider: Provider,
  model: string,
): Promise<string> {
  const key = String(env[secretNames[provider]] || "");
  if (!key) return "not_configured";
  const urls: Record<Provider, string> = {
    openai: `https://api.openai.com/v1/models/${encodeURIComponent(model)}`,
    deepseek: "https://api.deepseek.com/models",
    anthropic: `https://api.anthropic.com/v1/models/${encodeURIComponent(model)}`,
    gemini: `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}`,
  };
  const headers: Record<string, string> =
    provider === "gemini"
      ? { "x-goog-api-key": key }
      : provider === "anthropic"
        ? { "x-api-key": key, "anthropic-version": "2023-06-01" }
        : { Authorization: `Bearer ${key}` };
  try {
    const r = await fetch(urls[provider], {
      headers,
      signal: AbortSignal.timeout(10000),
    });
    const ok = r.ok;
    const data = (await r.json()) as any;
    if (
      provider === "deepseek" &&
      ok &&
      !data.data?.some((m: any) => m.id === model)
    )
      return "model_unavailable";
    return ok ? "verified" : r.status === 429 ? "rate_limited" : "unavailable";
  } catch {
    return "unreachable";
  }
}
