import type { Env, Identity, Provider, ModelConfig } from "./types";
import { deny } from "./security";
export function reservationCost(
  messages: { content: string }[],
  config: ModelConfig,
  maxTokens = 2048,
) {
  const bytes = new TextEncoder().encode(JSON.stringify(messages)).length;
  return (
    ((bytes + 4096) * config.input + maxTokens * config.output) / 1_000_000
  );
}
export async function reserve(
  env: Env,
  identity: Identity,
  conversation: string,
  provider: Provider,
  config: ModelConfig,
  cost: number,
) {
  const id = crypto.randomUUID(),
    now = new Date().toISOString(),
    day = now.slice(0, 10),
    month = now.slice(0, 7);
  const daily = Number(env.GLOBAL_DAILY_USD || 0),
    monthly = Number(env.GLOBAL_MONTHLY_USD || 0);
  if (
    !Number.isFinite(daily) ||
    !Number.isFinite(monthly) ||
    daily <= 0 ||
    monthly <= 0
  )
    deny("BUDGET_NOT_ENABLED", 503);
  // A single SQLite write statement serializes concurrent reservations. Retain billing records on history deletion.
  const result = await env.DB.prepare(
    `INSERT INTO requests(id,user_id,conversation_id,provider,model,reserved_usd,charged_usd,created_at,updated_at)
 SELECT ?,?,?,?,?,?,?,?,? FROM users u WHERE u.id=? AND u.disabled=0
 AND (SELECT COUNT(*) FROM requests WHERE user_id=u.id AND status='reserved')<4
 AND COALESCE((SELECT SUM(charged_usd) FROM requests WHERE user_id=u.id AND created_at>=?),0)+?<=u.daily_usd
 AND COALESCE((SELECT SUM(charged_usd) FROM requests WHERE user_id=u.id AND created_at>=?),0)+?<=u.monthly_usd
 AND COALESCE((SELECT SUM(charged_usd) FROM requests WHERE created_at>=?),0)+?<=?
 AND COALESCE((SELECT SUM(charged_usd) FROM requests WHERE created_at>=?),0)+?<=?`,
  )
    .bind(
      id,
      identity.id,
      conversation,
      provider,
      config.model,
      cost,
      cost,
      now,
      now,
      identity.id,
      day,
      cost,
      month,
      cost,
      day,
      cost,
      daily,
      month,
      cost,
      monthly,
    )
    .run();
  if (!result.meta.changes) deny("QUOTA_OR_CONCURRENCY_LIMIT", 429);
  return id;
}
