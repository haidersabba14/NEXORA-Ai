import { Hono } from "hono";
import { HTTPException } from "hono/http-exception";
import { z } from "zod";
import type { Bindings, Env, Identity, Provider } from "./types";
import { deny, rateLimit, requireMFA, turnstile } from "./security";
import { reserve } from "./quota";

/** Opt-in media generation. Parent must mount after its JWT authentication middleware. */
export interface MediaEnv extends Env {
  STUDIO_CONFIG_JSON?: string;
  BUCKET?: R2Bucket;
}
const imageConfigSchema = z.object({
  model: z
    .string()
    .regex(/^gpt-image-[a-zA-Z0-9.-]+$/)
    .max(100),
  worstCaseUsd: z.number().positive().max(100),
  maxBytes: z
    .number()
    .int()
    .min(100000)
    .max(8 * 1024 * 1024)
    .default(8 * 1024 * 1024),
});
const videoConfigSchema = z.object({
  model: z
    .string()
    .regex(/^veo-[a-zA-Z0-9.-]+$/)
    .max(100),
  worstCaseUsd: z.number().positive().max(100),
  durationSeconds: z
    .union([z.literal(4), z.literal(6), z.literal(8)])
    .default(8),
  maxBytes: z
    .number()
    .int()
    .min(100000)
    .max(24 * 1024 * 1024)
    .default(24 * 1024 * 1024),
});
const studioConfigSchema = z
  .object({
    image: imageConfigSchema.optional(),
    video: videoConfigSchema.optional(),
  })
  .strict();
export type StudioConfig = z.infer<typeof studioConfigSchema>;
export function studioConfig(env: MediaEnv): StudioConfig | null {
  try {
    return studioConfigSchema.parse(JSON.parse(env.STUDIO_CONFIG_JSON || ""));
  } catch {
    return null;
  }
}
export function imagePayload(model: string, prompt: string) {
  return {
    model,
    prompt,
    n: 1,
    size: "1024x1024",
    quality: "low",
    output_format: "png",
  };
}
export function videoPayload(prompt: string, durationSeconds: number) {
  return {
    instances: [{ prompt }],
    parameters: {
      sampleCount: 1,
      aspectRatio: "16:9",
      resolution: "720p",
      durationSeconds,
    },
  };
}
export function operationURL(name: string, model: string): string {
  const suffix = name.startsWith(`models/${model}/`)
    ? name.slice(`models/${model}/`.length)
    : name;
  if (!/^operations\/[a-zA-Z0-9._-]{1,200}$/.test(suffix))
    throw new Error("INVALID_VIDEO_OPERATION");
  return "https://generativelanguage.googleapis.com/v1beta/" + name;
}
/** Only the Google Files endpoint may receive the API key. Redirects never inherit it. */
export function checkedVideoURL(value: string, first = true): URL {
  const url = new URL(value);
  const allowed = first
    ? url.hostname === "generativelanguage.googleapis.com" &&
      /^\/v1beta\/files\/[a-zA-Z0-9._-]+(?::download)?$/.test(url.pathname)
    : ["generativelanguage.googleapis.com", "storage.googleapis.com"].includes(
        url.hostname,
      );
  if (
    !allowed ||
    url.protocol !== "https:" ||
    url.port ||
    url.username ||
    url.password ||
    url.searchParams.has("key")
  )
    throw new Error("INVALID_VIDEO_DOWNLOAD_URL");
  return url;
}
function safeError(error: unknown): string {
  return error instanceof StudioError ? error.code : "MEDIA_OPERATION_FAILED";
}
class StudioError extends Error {
  constructor(
    public code: string,
    public status = 502,
  ) {
    super(code);
  }
}
interface Job {
  id: string;
  user_id: string;
  request_id: string;
  conversation_id: string;
  kind: "image" | "video";
  provider: Provider;
  model: string;
  status: "running" | "complete" | "error";
  operation_name: string | null;
  object_key: string | null;
  content_type: string | null;
  byte_length: number | null;
  max_bytes: number;
  error_code: string | null;
  created_at: string;
  updated_at: string;
}
const date = () => new Date().toISOString();
function publicJob(job: Job) {
  return {
    id: job.id,
    kind: job.kind,
    provider: job.provider,
    model: job.model,
    status: job.status,
    error: job.error_code,
    bytes: job.byte_length,
    contentType: job.content_type,
    createdAt: job.created_at,
    updatedAt: job.updated_at,
    artifact:
      job.status === "complete" ? `/api/studio/jobs/${job.id}/artifact` : null,
    costEstimated: true,
  };
}
async function limitedBytes(
  response: Response,
  limit: number,
): Promise<Uint8Array> {
  const declared = Number(response.headers.get("Content-Length") || 0);
  if (declared > limit) {
    await response.body?.cancel();
    throw new StudioError("MEDIA_TOO_LARGE");
  }
  if (!response.body) throw new StudioError("EMPTY_MEDIA_RESPONSE");
  const reader = response.body.getReader(),
    chunks: Uint8Array[] = [];
  let size = 0;
  try {
    while (true) {
      const next = await reader.read();
      if (next.done) break;
      size += next.value.byteLength;
      if (size > limit) throw new StudioError("MEDIA_TOO_LARGE");
      chunks.push(next.value);
    }
  } finally {
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
  const value = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    value.set(chunk, offset);
    offset += chunk.length;
  }
  return value;
}
async function jsonResponse(
  response: Response,
  limit = 1024 * 1024,
): Promise<any> {
  if (!response.ok) {
    await response.body?.cancel();
    throw new StudioError(
      response.status === 429
        ? "PROVIDER_RATE_LIMIT"
        : response.status === 401 || response.status === 403
          ? "PROVIDER_AUTH_ERROR"
          : "PROVIDER_REQUEST_FAILED",
      response.status === 429 ? 429 : 502,
    );
  }
  try {
    return JSON.parse(
      new TextDecoder().decode(await limitedBytes(response, limit)),
    );
  } catch (error) {
    if (error instanceof StudioError) throw error;
    throw new StudioError("INVALID_PROVIDER_RESPONSE");
  }
}
async function remote(
  url: string,
  init: RequestInit = {},
  timeout = 120000,
): Promise<Response> {
  try {
    return await fetch(url, {
      ...init,
      signal: AbortSignal.timeout(timeout),
      redirect: "manual",
    });
  } catch {
    throw new StudioError("PROVIDER_UNREACHABLE");
  }
}
export function decodePNG(base64: string, limit: number): Uint8Array {
  if (
    typeof base64 !== "string" ||
    base64.length > Math.ceil((limit * 4) / 3) + 8 ||
    !/^[A-Za-z0-9+/]+={0,2}$/.test(base64)
  )
    throw new StudioError("INVALID_IMAGE_RESPONSE");
  let binary: string;
  try {
    binary = atob(base64);
  } catch {
    throw new StudioError("INVALID_IMAGE_RESPONSE");
  }
  if (binary.length > limit || binary.length < 8)
    throw new StudioError("MEDIA_TOO_LARGE");
  const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
  if (
    ![137, 80, 78, 71, 13, 10, 26, 10].every(
      (value, index) => bytes[index] === value,
    )
  )
    throw new StudioError("INVALID_IMAGE_RESPONSE");
  return bytes;
}
async function fetchVideo(
  uri: string,
  key: string,
  limit: number,
): Promise<Uint8Array> {
  let url = checkedVideoURL(uri);
  for (let hop = 0; hop < 4; hop++) {
    const headers: Record<string, string> =
      url.hostname === "generativelanguage.googleapis.com"
        ? { "x-goog-api-key": key }
        : {};
    const response = await remote(url.toString(), { headers }, 30000);
    if ([301, 302, 303, 307, 308].includes(response.status)) {
      const location = response.headers.get("Location");
      await response.body?.cancel();
      if (!location) throw new StudioError("INVALID_VIDEO_DOWNLOAD_URL");
      url = checkedVideoURL(new URL(location, url).toString(), false);
      continue;
    }
    if (!response.ok) {
      await response.body?.cancel();
      throw new StudioError("VIDEO_DOWNLOAD_FAILED");
    }
    const type = response.headers.get("Content-Type")?.split(";")[0];
    if (type !== "video/mp4" && type !== "application/octet-stream") {
      await response.body?.cancel();
      throw new StudioError("INVALID_VIDEO_CONTENT");
    }
    const bytes = await limitedBytes(response, limit);
    if (
      bytes.length < 12 ||
      String.fromCharCode(...bytes.slice(4, 8)) !== "ftyp"
    )
      throw new StudioError("INVALID_VIDEO_CONTENT");
    return bytes;
  }
  throw new StudioError("VIDEO_REDIRECT_LIMIT");
}
async function createJob(
  env: MediaEnv,
  user: Identity,
  kind: "image" | "video",
  model: string,
  cost: number,
  maxBytes: number,
  prompt: string,
): Promise<Job> {
  const conversation = crypto.randomUUID(),
    id = crypto.randomUUID(),
    created = date(),
    provider: Provider = kind === "image" ? "openai" : "gemini";
  await env.DB.prepare(
    "INSERT INTO conversations(id,user_id,title,created_at,updated_at) VALUES(?,?,?,?,?)",
  )
    .bind(
      conversation,
      user.id,
      `[${kind === "image" ? "Image" : "Video"} Studio] ${prompt.slice(0, 90)}`,
      created,
      created,
    )
    .run();
  let requestId: string;
  try {
    requestId = await reserve(
      env,
      user,
      conversation,
      provider,
      { model, input: 1, output: 1 },
      cost,
    );
  } catch (error) {
    await env.DB.prepare("DELETE FROM conversations WHERE id=? AND user_id=?")
      .bind(conversation, user.id)
      .run();
    throw error;
  }
  await env.DB.batch([
    env.DB.prepare(
      "INSERT INTO studio_jobs(id,user_id,request_id,conversation_id,kind,provider,model,status,max_bytes,created_at,updated_at) VALUES(?,?,?,?,?,?,?,'running',?,?,?)",
    ).bind(
      id,
      user.id,
      requestId,
      conversation,
      kind,
      provider,
      model,
      maxBytes,
      created,
      created,
    ),
    env.DB.prepare(
      "INSERT INTO messages(id,conversation_id,role,content,created_at) VALUES(?,?,'user',?,?)",
    ).bind(crypto.randomUUID(), conversation, prompt, created),
  ]);
  return (await env.DB.prepare("SELECT * FROM studio_jobs WHERE id=?")
    .bind(id)
    .first<Job>())!;
}
async function finish(
  env: MediaEnv,
  job: Job,
  key?: string,
  type?: string,
  bytes?: number,
  error?: string,
) {
  const completed = date(),
    status = error ? "error" : "complete";
  // Media prices remain conservative fixed estimates; no unreported usage or actual invoice cost is fabricated.
  await env.DB.batch([
    env.DB.prepare(
      "UPDATE studio_jobs SET status=?,object_key=?,content_type=?,byte_length=?,error_code=?,poll_locked_until=0,updated_at=? WHERE id=?",
    ).bind(
      status,
      key || null,
      type || null,
      bytes ?? null,
      error || null,
      completed,
      job.id,
    ),
    env.DB.prepare(
      "UPDATE requests SET status=?,error_code=?,updated_at=? WHERE id=?",
    ).bind(status, error || null, completed, job.request_id),
    env.DB.prepare(
      "INSERT INTO messages(id,conversation_id,role,content,provider,request_id,status,created_at) SELECT ?,id,'assistant',?,?,?,?,? FROM conversations WHERE id=?",
    ).bind(
      crypto.randomUUID(),
      error
        ? `Media generation failed: ${error}`
        : `Generated ${job.kind} saved in the private media studio.`,
      job.provider,
      job.request_id,
      status,
      completed,
      job.conversation_id,
    ),
  ]);
}
function configured(env: MediaEnv, kind: "image" | "video") {
  const cfg = studioConfig(env)?.[kind];
  if (!cfg)
    deny(
      kind === "image"
        ? "IMAGE_GENERATION_NOT_CONFIGURED"
        : "VIDEO_GENERATION_NOT_CONFIGURED",
      503,
    );
  if (!env.BUCKET) deny("MEDIA_STORAGE_NOT_CONFIGURED", 503);
  if (!(kind === "image" ? env.OPENAI_API_KEY : env.GEMINI_API_KEY))
    deny("PROVIDER_NOT_CONFIGURED", 503);
  return cfg;
}
async function ownedJob(
  env: MediaEnv,
  id: string,
  userId: string,
): Promise<Job> {
  const parsed = z.uuid().parse(id);
  const row = await env.DB.prepare(
    "SELECT * FROM studio_jobs WHERE id=? AND user_id=?",
  )
    .bind(parsed, userId)
    .first<Job>();
  if (!row) throw new HTTPException(404, { message: "NOT_FOUND" });
  return row;
}
const promptSchema = z.object({
  prompt: z.string().trim().min(1).max(4000),
  turnstileToken: z.string().min(1).max(4096),
});
const media = new Hono<Bindings>();
media.use("*", async (c, next) => {
  const user = c.get("identity");
  if (!user) deny("AUTH_REQUIRED", 401);
  requireMFA(user);
  await next();
});
media.onError((error, c) => {
  if (error instanceof HTTPException)
    return c.json({ error: error.message }, error.status);
  if (error instanceof z.ZodError)
    return c.json({ error: "INVALID_INPUT" }, 400);
  if (error instanceof SyntaxError)
    return c.json({ error: "INVALID_JSON" }, 400);
  return c.json(
    { error: safeError(error) },
    error instanceof StudioError && error.status === 429 ? 429 : 502,
  );
});
media.get("/config", (c) => {
  const env = c.env as MediaEnv,
    cfg = studioConfig(env);
  return c.json({
    storageConfigured: !!env.BUCKET,
    image: {
      configured: !!(cfg?.image && env.BUCKET && env.OPENAI_API_KEY),
      model: cfg?.image?.model || null,
      estimatedUsd: cfg?.image?.worstCaseUsd ?? null,
    },
    video: {
      configured: !!(cfg?.video && env.BUCKET && env.GEMINI_API_KEY),
      model: cfg?.video?.model || null,
      estimatedUsd: cfg?.video?.worstCaseUsd ?? null,
      durationSeconds: cfg?.video?.durationSeconds ?? null,
    },
  });
});
media.get("/jobs", async (c) => {
  const rows = await c.env.DB.prepare(
    "SELECT * FROM studio_jobs WHERE user_id=? ORDER BY created_at DESC LIMIT 30",
  )
    .bind(c.get("identity").id)
    .all<Job>();
  return c.json({ jobs: rows.results.map(publicJob) });
});
media.post("/images", async (c) => {
  const env = c.env as MediaEnv,
    user = c.get("identity"),
    cfg = configured(env, "image");
  const input = promptSchema.parse(await c.req.json());
  await rateLimit(env, "image:" + user.id, 4, 60);
  await turnstile(
    env,
    input.turnstileToken,
    c.req.header("CF-Connecting-IP") || "",
  );
  const job = await createJob(
    env,
    user,
    "image",
    cfg.model,
    cfg.worstCaseUsd,
    cfg.maxBytes,
    input.prompt,
  );
  const work = (async () => {
    try {
      const response = await remote(
        "https://api.openai.com/v1/images/generations",
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${env.OPENAI_API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(imagePayload(cfg.model, input.prompt)),
        },
      );
      const result = await jsonResponse(
        response,
        Math.ceil(cfg.maxBytes * 1.5) + 100000,
      );
      const bytes = decodePNG(result.data?.[0]?.b64_json, cfg.maxBytes),
        key = `studio/${user.id}/${job.id}.png`;
      await env.BUCKET!.put(key, bytes, {
        httpMetadata: { contentType: "image/png" },
        customMetadata: { owner: user.id, job: job.id },
      });
      await finish(env, job, key, "image/png", bytes.byteLength);
    } catch (error) {
      await finish(env, job, undefined, undefined, undefined, safeError(error));
    }
  })();
  // Generation and accounting survive a browser disconnect without restarting the paid request.
  try {
    c.executionCtx.waitUntil(work);
  } catch {
    /* Direct unit invocations have no Worker execution context. */
  }
  await work;
  return c.json(publicJob(await ownedJob(env, job.id, user.id)), 201);
});
media.post("/videos", async (c) => {
  const env = c.env as MediaEnv,
    user = c.get("identity"),
    cfg = configured(env, "video") as z.infer<typeof videoConfigSchema>;
  const input = promptSchema.parse(await c.req.json());
  await rateLimit(env, "video:" + user.id, 2, 60);
  await turnstile(
    env,
    input.turnstileToken,
    c.req.header("CF-Connecting-IP") || "",
  );
  const job = await createJob(
    env,
    user,
    "video",
    cfg.model,
    cfg.worstCaseUsd,
    cfg.maxBytes,
    input.prompt,
  );
  const work = (async () => {
    try {
      const response = await remote(
        `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(cfg.model)}:predictLongRunning`,
        {
          method: "POST",
          headers: {
            "x-goog-api-key": env.GEMINI_API_KEY!,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(videoPayload(input.prompt, cfg.durationSeconds)),
        },
        30000,
      );
      const operation = await jsonResponse(response);
      operationURL(operation.name, cfg.model);
      await env.DB.prepare(
        "UPDATE studio_jobs SET operation_name=?,updated_at=? WHERE id=?",
      )
        .bind(operation.name, date(), job.id)
        .run();
      return {
        job: publicJob(await ownedJob(env, job.id, user.id)),
        status: 202 as const,
      };
    } catch (error) {
      await finish(env, job, undefined, undefined, undefined, safeError(error));
      return {
        job: publicJob(await ownedJob(env, job.id, user.id)),
        status: 502 as const,
      };
    }
  })();
  try {
    c.executionCtx.waitUntil(work);
  } catch {
    /* Direct tests have no Worker execution context. */
  }
  const result = await work;
  return c.json(result.job, result.status);
});
media.post("/jobs/:id/poll", async (c) => {
  const env = c.env as MediaEnv,
    user = c.get("identity");
  let job = await ownedJob(env, c.req.param("id"), user.id);
  if (job.status !== "running" || job.kind !== "video")
    return c.json(publicJob(job));
  if (!env.BUCKET || !env.GEMINI_API_KEY)
    deny("MEDIA_STORAGE_OR_PROVIDER_NOT_CONFIGURED", 503);
  await rateLimit(env, "video-poll:" + user.id, 12, 60);
  if (Date.now() - Date.parse(job.created_at) > 24 * 3600000) {
    await finish(
      env,
      job,
      undefined,
      undefined,
      undefined,
      "VIDEO_OPERATION_EXPIRED",
    );
    return c.json(publicJob(await ownedJob(env, job.id, user.id)));
  }
  const seconds = Math.floor(Date.now() / 1000);
  const lock = await env.DB.prepare(
    "UPDATE studio_jobs SET poll_locked_until=? WHERE id=? AND user_id=? AND status='running' AND poll_locked_until<? RETURNING id",
  )
    .bind(seconds + 90, job.id, user.id, seconds)
    .first();
  if (!lock) deny("MEDIA_POLL_IN_PROGRESS", 409);
  let terminal = false;
  try {
    if (!job.operation_name)
      throw new StudioError("VIDEO_OPERATION_NOT_AVAILABLE");
    const response = await remote(
      operationURL(job.operation_name, job.model),
      { headers: { "x-goog-api-key": env.GEMINI_API_KEY } },
      15000,
    );
    const operation = await jsonResponse(response);
    if (!operation.done) {
      await env.DB.prepare(
        "UPDATE studio_jobs SET poll_locked_until=0,error_code=NULL,updated_at=? WHERE id=?",
      )
        .bind(date(), job.id)
        .run();
      return c.json(publicJob(await ownedJob(env, job.id, user.id)), 202);
    }
    if (operation.error) {
      terminal = true;
      throw new StudioError("VIDEO_PROVIDER_FAILED");
    }
    const uri =
      operation.response?.generateVideoResponse?.generatedSamples?.[0]?.video
        ?.uri;
    if (typeof uri !== "string") {
      terminal = true;
      throw new StudioError(
        operation.response?.generateVideoResponse?.raiMediaFilteredCount
          ? "CONTENT_BLOCKED"
          : "VIDEO_RESULT_MISSING",
      );
    }
    const bytes = await fetchVideo(uri, env.GEMINI_API_KEY, job.max_bytes),
      key = `studio/${user.id}/${job.id}.mp4`;
    await env.BUCKET.put(key, bytes, {
      httpMetadata: { contentType: "video/mp4" },
      customMetadata: { owner: user.id, job: job.id },
    });
    await finish(env, job, key, "video/mp4", bytes.byteLength);
  } catch (error) {
    if (terminal)
      await finish(env, job, undefined, undefined, undefined, safeError(error));
    else
      await env.DB.prepare(
        "UPDATE studio_jobs SET poll_locked_until=0,error_code=?,updated_at=? WHERE id=?",
      )
        .bind(safeError(error), date(), job.id)
        .run();
  }
  return c.json(publicJob(await ownedJob(env, job.id, user.id)));
});
media.get("/jobs/:id/artifact", async (c) => {
  const env = c.env as MediaEnv,
    user = c.get("identity");
  await rateLimit(env, "media-download:" + user.id, 30, 60);
  const job = await ownedJob(env, c.req.param("id"), user.id);
  if (!env.BUCKET) deny("MEDIA_STORAGE_NOT_CONFIGURED", 503);
  if (job.status !== "complete" || !job.object_key)
    throw new HTTPException(404, { message: "NOT_FOUND" });
  const object = await env.BUCKET.get(job.object_key);
  if (!object) throw new HTTPException(404, { message: "NOT_FOUND" });
  return new Response(object.body, {
    headers: {
      "Content-Type": job.content_type || "application/octet-stream",
      "Content-Length": String(object.size),
      "Content-Disposition": `attachment; filename="nexora-${job.id}.${job.kind === "image" ? "png" : "mp4"}"`,
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
});
media.delete("/jobs/:id", async (c) => {
  const env = c.env as MediaEnv,
    user = c.get("identity"),
    job = await ownedJob(env, c.req.param("id"), user.id);
  if (job.status === "running") deny("GENERATION_IN_PROGRESS", 409);
  if (job.object_key) {
    if (!env.BUCKET) deny("MEDIA_STORAGE_NOT_CONFIGURED", 503);
    await env.BUCKET.delete(job.object_key);
  }
  await env.DB.prepare("DELETE FROM studio_jobs WHERE id=? AND user_id=?")
    .bind(job.id, user.id)
    .run();
  return c.json({ ok: true });
});
export default media;
