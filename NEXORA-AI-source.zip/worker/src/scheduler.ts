import { Hono } from "hono";
import { z } from "zod";
import { Bindings, Env, providers, Identity, ChatMessage } from "./types";
import { deny, rateLimit, turnstile } from "./security";
import { generate, modelConfig, ProviderError } from "./providers";
import { reserve, reservationCost } from "./quota";
const iso = () => new Date().toISOString();
export const schedules = new Hono<Bindings>();
schedules.get("/", async (c) => {
  const rows = await c.env.DB.prepare(
    "SELECT * FROM scheduled_tasks WHERE user_id=? ORDER BY created_at DESC LIMIT 24",
  )
    .bind(c.get("identity").id)
    .all();
  return c.json(rows.results);
});
schedules.post("/", async (c) => {
  const d = z
    .object({
      title: z.string().trim().min(1).max(100),
      prompt: z.string().trim().min(1).max(4000),
      provider: z.enum(providers),
      intervalHours: z.number().int().min(1).max(168),
      kind: z.enum(["prompt", "health"]).default("prompt"),
      turnstileToken: z.string().min(1).max(4096),
    })
    .parse(await c.req.json());
  await rateLimit(c.env, "schedule:" + c.get("identity").id, 10, 3600);
  await turnstile(
    c.env,
    d.turnstileToken,
    c.req.header("CF-Connecting-IP") || "",
  );
  const count = await c.env.DB.prepare(
    "SELECT COUNT(*) count FROM scheduled_tasks WHERE user_id=?",
  )
    .bind(c.get("identity").id)
    .first<{ count: number }>();
  if ((count?.count || 0) >= 24) deny("SCHEDULE_LIMIT");
  const id = crypto.randomUUID();
  await c.env.DB.prepare(
    "INSERT INTO scheduled_tasks(id,user_id,title,prompt,provider,interval_hours,kind,next_run,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
  )
    .bind(
      id,
      c.get("identity").id,
      d.title,
      d.prompt,
      d.provider,
      d.intervalHours,
      d.kind,
      new Date(Date.now() + d.intervalHours * 3600000).toISOString(),
      iso(),
    )
    .run();
  return c.json({ id }, 201);
});
schedules.patch("/:id", async (c) => {
  const d = z.object({ enabled: z.boolean() }).parse(await c.req.json());
  const result = await c.env.DB.prepare(
    "UPDATE scheduled_tasks SET enabled=? WHERE id=? AND user_id=?",
  )
    .bind(d.enabled ? 1 : 0, c.req.param("id"), c.get("identity").id)
    .run();
  if (!result.meta.changes) return c.json({ error: "NOT_FOUND" }, 404);
  return c.json({ ok: true });
});
schedules.delete("/:id", async (c) => {
  await c.env.DB.prepare("DELETE FROM scheduled_tasks WHERE id=? AND user_id=?")
    .bind(c.req.param("id"), c.get("identity").id)
    .run();
  return c.json({ ok: true });
});
export async function runScheduled(env: Env) {
  const due = await env.DB.prepare(
    "SELECT t.*,u.email FROM scheduled_tasks t JOIN users u ON u.id=t.user_id WHERE t.enabled=1 AND t.next_run<=? AND u.disabled=0 ORDER BY t.next_run LIMIT 4",
  )
    .bind(iso())
    .all<any>();
  for (const task of due.results) {
    const start = iso();
    const locked = await env.DB.prepare(
      "UPDATE scheduled_tasks SET next_run=?,last_run=?,last_status='running' WHERE id=? AND enabled=1 AND next_run<=? RETURNING id",
    )
      .bind(
        new Date(Date.now() + task.interval_hours * 3600000).toISOString(),
        start,
        task.id,
        start,
      )
      .first();
    if (!locked) continue;
    let requestId: string | undefined;
    let text = "",
      input: number | undefined,
      output: number | undefined,
      status = "complete",
      error: string | null = null,
      cost = 0;
    const cfg = modelConfig(env)?.[task.provider as (typeof providers)[number]];
    try {
      if (task.kind === "health") {
        await env.DB.prepare("SELECT 1").first();
        text = JSON.stringify({
          database: "connected",
          checked_at: iso(),
          scope:
            "NEXORA internal database only; external systems are not connected.",
        });
      } else {
        if (!cfg) throw new ProviderError("PROVIDER_NOT_CONFIGURED", 503);
        let conversation = task.conversation_id;
        if (!conversation) {
          conversation = crypto.randomUUID();
          await env.DB.prepare(
            "INSERT INTO conversations(id,user_id,title,created_at,updated_at) VALUES(?,?,?,?,?)",
          )
            .bind(
              conversation,
              task.user_id,
              "[Scheduled] " + task.title,
              start,
              start,
            )
            .run();
          await env.DB.prepare(
            "UPDATE scheduled_tasks SET conversation_id=? WHERE id=?",
          )
            .bind(conversation, task.id)
            .run();
        }
        const messages: ChatMessage[] = [
          {
            role: "system",
            content:
              "Execute this scheduled analysis within this text-only environment. Do not claim to have visited websites, monitored external servers, sent messages or executed code. State evidence limits.",
          },
          { role: "user", content: task.prompt },
        ];
        const memory = await env.DB.prepare(
          "SELECT enabled,content FROM memory_settings WHERE user_id=?",
        )
          .bind(task.user_id)
          .first<any>();
        if (memory?.enabled && memory.content)
          messages.unshift({
            role: "system",
            content: "User preferences: " + memory.content,
          });
        cost = reservationCost(messages, cfg);
        const identity: Identity = {
          id: task.user_id,
          email: task.email,
          aal: "aal2",
          iat: 0,
          claims: {},
          admin: false,
        };
        requestId = await reserve(
          env,
          identity,
          conversation,
          task.provider,
          cfg,
          cost,
        );
        for await (const chunk of generate(
          env,
          task.provider,
          cfg.model,
          messages,
          AbortSignal.timeout(120000),
        )) {
          if (chunk.text) text += chunk.text;
          if (chunk.input !== undefined) input = chunk.input;
          if (chunk.output !== undefined) output = chunk.output;
          if (text.length > 100000) throw new ProviderError("OUTPUT_LIMIT");
        }
        await env.DB.batch([
          env.DB.prepare(
            "INSERT INTO messages(id,conversation_id,role,content,created_at) VALUES(?,?,?,?,?)",
          ).bind(crypto.randomUUID(), conversation, "user", task.prompt, start),
          env.DB.prepare(
            "INSERT INTO messages(id,conversation_id,role,content,provider,request_id,created_at) VALUES(?,?,?,?,?,?,?)",
          ).bind(
            crypto.randomUUID(),
            conversation,
            "assistant",
            text,
            task.provider,
            requestId,
            iso(),
          ),
          env.DB.prepare(
            "UPDATE conversations SET updated_at=? WHERE id=?",
          ).bind(iso(), conversation),
        ]);
      }
    } catch (e) {
      status = "error";
      error = e instanceof ProviderError ? e.code : "SCHEDULE_FAILED";
    } finally {
      if (requestId && cfg) {
        const reported =
          Number.isInteger(input) &&
          Number.isInteger(output) &&
          input! >= 0 &&
          output! >= 0;
        const charged =
          status === "complete" && reported
            ? (input! * cfg.input + output! * cfg.output) / 1e6
            : cost;
        await env.DB.prepare(
          "UPDATE requests SET status=?,charged_usd=?,input_tokens=?,output_tokens=?,usage_reported=?,error_code=?,updated_at=? WHERE id=?",
        )
          .bind(
            status,
            charged,
            input ?? null,
            output ?? null,
            reported ? 1 : 0,
            error,
            iso(),
            requestId,
          )
          .run();
      }
      await env.DB.prepare(
        "UPDATE scheduled_tasks SET last_status=?,last_output=? WHERE id=?",
      )
        .bind(error || status, text.slice(0, 40000), task.id)
        .run();
    }
  }
}
export function scheduled(
  _event: ScheduledController,
  env: Env,
  ctx: ExecutionContext,
) {
  ctx.waitUntil(runScheduled(env));
}
