import { Hono } from "hono";
import media from "./media";
import agents from "./agents";
import { schedules, scheduled } from "./scheduler";
import { extensions, searchCost, searchWeb, validateImage } from "./extensions";
import { HTTPException } from "hono/http-exception";
import { streamSSE } from "hono/streaming";
import { z } from "zod";
import { bodyLimit } from "hono/body-limit";
import scriptHashes from "./csp.generated.json";
import {
  authenticate,
  deny,
  requireMFA,
  rateLimit,
  hashCode,
  turnstile,
} from "./security";
import { modelConfig, generate, probe, ProviderError } from "./providers";
import { reserve, reservationCost } from "./quota";
import { Bindings, providers, secretNames, ChatMessage } from "./types";
const app = new Hono<Bindings>();
const now = () => new Date().toISOString();
async function audit(
  env: Bindings["Bindings"],
  actor: string,
  action: string,
  target?: string,
  code?: string,
) {
  await env.DB.prepare(
    "INSERT INTO audit_logs(id,actor_id,action,target_id,code,created_at) VALUES(?,?,?,?,?,?)",
  )
    .bind(
      crypto.randomUUID(),
      actor,
      action,
      target || null,
      code || null,
      now(),
    )
    .run();
}
app.use(
  "/api/*",
  bodyLimit({
    maxSize: 150000,
    onError: (c) => c.json({ error: "PAYLOAD_TOO_LARGE" }, 413),
  }),
);
app.use("*", async (c, next) => {
  c.set("requestId", crypto.randomUUID());
  if (
    c.req.path.startsWith("/api/") &&
    Number(c.req.header("Content-Length") || 0) > 150000
  )
    return c.json({ error: "PAYLOAD_TOO_LARGE" }, 413);
  if (
    c.req.path.startsWith("/api/") &&
    !["GET", "HEAD"].includes(c.req.method)
  ) {
    const origin = c.req.header("Origin");
    if (!c.env.APP_ORIGIN || origin !== c.env.APP_ORIGIN)
      return c.json({ error: "ORIGIN_REJECTED" }, 403);
    if (!c.req.header("Content-Type")?.startsWith("application/json"))
      return c.json({ error: "JSON_REQUIRED" }, 415);
  }
  await next();
  c.header("X-Content-Type-Options", "nosniff");
  c.header("Referrer-Policy", "strict-origin-when-cross-origin");
  c.header("X-Frame-Options", "DENY");
  c.header(
    "Permissions-Policy",
    "camera=(), microphone=(self), geolocation=()",
  );
  c.header("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  c.header("X-Request-ID", c.get("requestId"));
  if (c.req.path.startsWith("/api/")) c.header("Cache-Control", "no-store");
  // Hash only the inline Next hydration scripts in this exact static build. Markdown never enables raw HTML.
  c.header(
    "Content-Security-Policy",
    `default-src 'self'; script-src 'self' ${scriptHashes.map((hash) => "'sha256-" + hash + "'").join(" ")} https://challenges.cloudflare.com; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self' https://*.supabase.co https://challenges.cloudflare.com; frame-src https://challenges.cloudflare.com; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'`,
  );
});
app.onError((err, c) => {
  if (err instanceof HTTPException)
    return c.json(
      { error: err.message, requestId: c.get("requestId") },
      err.status,
    );
  if (err instanceof z.ZodError)
    return c.json(
      {
        error: "INVALID_INPUT",
        fields: err.issues.map((x) => x.path.join(".")),
      },
      400,
    );
  if (err instanceof SyntaxError) return c.json({ error: "INVALID_JSON" }, 400);
  console.error(
    JSON.stringify({ requestId: c.get("requestId"), code: "INTERNAL_ERROR" }),
  );
  return c.json(
    { error: "INTERNAL_ERROR", requestId: c.get("requestId") },
    500,
  );
});
app.get("/api/health", async (c) => {
  try {
    await c.env.DB.prepare("SELECT 1").first();
    return c.json({ status: "ok", database: "connected", time: now() });
  } catch {
    return c.json({ status: "degraded", database: "unavailable" }, 503);
  }
});
app.get("/api/config", (c) => {
  const config = modelConfig(c.env);
  return c.json({
    supabaseUrl: c.env.SUPABASE_URL || null,
    supabaseAnonKey: c.env.SUPABASE_ANON_KEY || null,
    turnstileSiteKey: c.env.TURNSTILE_SITE_KEY || null,
    authConfigured: !!(c.env.SUPABASE_URL && c.env.SUPABASE_ANON_KEY),
    budgetEnabled:
      Number(c.env.GLOBAL_DAILY_USD) > 0 &&
      Number(c.env.GLOBAL_MONTHLY_USD) > 0,
    providers: providers.map((id) => ({
      id,
      model: config?.[id]?.model || null,
      configured: !!c.env[secretNames[id]] && !!config?.[id],
      status: "not_tested",
    })),
  });
});
app.use("/api/*", async (c, next) => {
  await rateLimit(
    c.env,
    "ip:" + (c.req.header("CF-Connecting-IP") || "local"),
    200,
    60,
  );
  const identity = await authenticate(c.req.raw, c.env);
  c.set("identity", identity);
  await rateLimit(c.env, `api:${identity.id}`, 120, 60);
  if (!["/api/session", "/api/recovery/redeem"].includes(c.req.path))
    requireMFA(identity);
  await next();
});
app.get("/api/session", async (c) => {
  const u = c.get("identity");
  await c.env.DB.prepare(
    "INSERT INTO users(id,email) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET email=excluded.email",
  )
    .bind(u.id, u.email)
    .run();
  const profile = await c.env.DB.prepare(
    "SELECT id,email,name,avatar,daily_usd,monthly_usd FROM users WHERE id=?",
  )
    .bind(u.id)
    .first();
  return c.json({
    ...profile,
    aal: u.aal,
    admin: u.admin,
    recoveryEnabled: !!(
      c.env.RECOVERY_PEPPER && c.env.SUPABASE_SERVICE_ROLE_KEY
    ),
  });
});
async function revokeAuthSessions(c: any, requireSuccess = false) {
  const r = await fetch(c.env.SUPABASE_URL + "/auth/v1/logout?scope=global", {
    method: "POST",
    headers: {
      Authorization: c.req.header("Authorization") || "",
      apikey: c.env.SUPABASE_ANON_KEY,
    },
    signal: AbortSignal.timeout(10000),
  });
  if (!r.ok && (requireSuccess || r.status !== 401))
    deny("SESSION_REVOCATION_FAILED", 503);
}
app.post("/api/session/revoke", async (c) => {
  const id = c.get("identity").id;
  await revokeAuthSessions(c);
  await c.env.DB.prepare("UPDATE users SET revoked_before=? WHERE id=?")
    .bind(Math.floor(Date.now() / 1000), id)
    .run();
  await audit(c.env, id, "sessions_revoked");
  return c.json({ ok: true });
});
app.patch("/api/profile", async (c) => {
  const data = z
    .object({
      name: z.string().trim().max(80),
      avatar: z
        .string()
        .max(200000)
        .refine(
          (x) =>
            !x ||
            /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(x),
        ),
    })
    .parse(await c.req.json());
  await c.env.DB.prepare("UPDATE users SET name=?,avatar=? WHERE id=?")
    .bind(data.name, data.avatar, c.get("identity").id)
    .run();
  return c.json({ ok: true });
});
app.get("/api/providers", async (c) => {
  const results = await c.env.DB.prepare("SELECT * FROM provider_health").all();
  const config = modelConfig(c.env);
  return c.json({
    providers: providers.map((id) => ({
      id,
      model: config?.[id]?.model || null,
      configured: !!c.env[secretNames[id]] && !!config?.[id],
      ...results.results.find((x) => x.provider === id),
    })),
  });
});
app.post("/api/providers/probe", async (c) => {
  await rateLimit(c.env, "probe:" + c.get("identity").id, 2, 60);
  const configs = modelConfig(c.env);
  const results = await Promise.all(
    providers.map(async (id) => {
      const status = configs
        ? await probe(c.env, id, configs[id].model)
        : "not_configured";
      const checked = now();
      await c.env.DB.prepare(
        "INSERT INTO provider_health(provider,status,checked_at) VALUES(?,?,?) ON CONFLICT(provider) DO UPDATE SET status=excluded.status,checked_at=excluded.checked_at",
      )
        .bind(id, status, checked)
        .run();
      return { id, status, checked_at: checked };
    }),
  );
  return c.json({ providers: results });
});
app.get("/api/conversations", async (c) => {
  const q = (c.req.query("q") || "").slice(0, 200);
  const data = await c.env.DB.prepare(
    `SELECT DISTINCT c.* FROM conversations c WHERE c.user_id=? AND (?='' OR instr(lower(c.title),lower(?))>0 OR EXISTS(SELECT 1 FROM messages m WHERE m.conversation_id=c.id AND instr(lower(m.content),lower(?))>0)) ORDER BY c.updated_at DESC LIMIT 100`,
  )
    .bind(c.get("identity").id, q, q, q)
    .all();
  return c.json(data.results);
});
app.post("/api/conversations", async (c) => {
  const { title } = z
    .object({ title: z.string().trim().min(1).max(120) })
    .parse(await c.req.json());
  const id = crypto.randomUUID(),
    date = now();
  await c.env.DB.prepare(
    "INSERT INTO conversations(id,user_id,title,created_at,updated_at) VALUES(?,?,?,?,?)",
  )
    .bind(id, c.get("identity").id, title, date, date)
    .run();
  return c.json({ id, title, created_at: date, updated_at: date }, 201);
});
async function own(c: any) {
  const id = c.req.param("id");
  const row = await c.env.DB.prepare(
    "SELECT * FROM conversations WHERE id=? AND user_id=?",
  )
    .bind(id, c.get("identity").id)
    .first();
  if (!row) throw new HTTPException(404, { message: "NOT_FOUND" });
  return row;
}
app.get("/api/conversations/:id", async (c) => {
  const row = await own(c);
  const messages = await c.env.DB.prepare(
    "SELECT id,role,content,provider,status,created_at FROM messages WHERE conversation_id=? ORDER BY created_at,rowid",
  )
    .bind(row.id)
    .all();
  return c.json({ ...row, messages: messages.results });
});
app.delete("/api/conversations/:id", async (c) => {
  const row = await own(c);
  if (
    await c.env.DB.prepare(
      "SELECT 1 FROM requests WHERE conversation_id=? AND status='reserved'",
    )
      .bind(row.id)
      .first()
  )
    deny("GENERATION_IN_PROGRESS", 409);
  await c.env.DB.prepare("DELETE FROM conversations WHERE id=? AND user_id=?")
    .bind(row.id, c.get("identity").id)
    .run();
  return c.json({ ok: true });
});
async function grantHash(value: string) {
  const data = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(value),
  );
  return Array.from(new Uint8Array(data), (b) =>
    b.toString(16).padStart(2, "0"),
  ).join("");
}
app.post("/api/comparison/grants", async (c) => {
  const { turnstileToken } = z
    .object({ turnstileToken: z.string().min(1).max(4096) })
    .parse(await c.req.json());
  await rateLimit(c.env, "compare:" + c.get("identity").id, 5, 60);
  await turnstile(
    c.env,
    turnstileToken,
    c.req.header("CF-Connecting-IP") || "",
  );
  const grants: Record<string, string> = {};
  const statements = [];
  for (const provider of providers) {
    const value = crypto.randomUUID() + crypto.randomUUID();
    grants[provider] = value;
    statements.push(
      c.env.DB.prepare(
        "INSERT INTO comparison_grants(hash,user_id,provider,expires_at) VALUES(?,?,?,?)",
      ).bind(
        await grantHash(value),
        c.get("identity").id,
        provider,
        Math.floor(Date.now() / 1000) + 120,
      ),
    );
  }
  statements.push(
    c.env.DB.prepare("DELETE FROM comparison_grants WHERE expires_at<?").bind(
      Math.floor(Date.now() / 1000),
    ),
  );
  await c.env.DB.batch(statements);
  return c.json({ grants });
});
app.post("/api/chat", async (c) => {
  const input = z
    .object({
      conversationId: z.uuid(),
      provider: z.enum(providers),
      message: z.string().trim().min(1).max(20000),
      mode: z.enum(["standard", "deep", "code", "web"]).default("standard"),
      image: z.string().max(134100).optional(),
      turnstileToken: z.string().min(1).max(4096),
    })
    .parse(await c.req.json());
  const user = c.get("identity");
  await rateLimit(c.env, "chat:" + user.id, 20, 60);
  if (input.turnstileToken.startsWith("grant:")) {
    const grant = await c.env.DB.prepare(
      "DELETE FROM comparison_grants WHERE hash=? AND user_id=? AND provider=? AND expires_at>? RETURNING hash",
    )
      .bind(
        await grantHash(input.turnstileToken.slice(6)),
        user.id,
        input.provider,
        Math.floor(Date.now() / 1000),
      )
      .first();
    if (!grant) deny("INVALID_COMPARISON_GRANT");
  } else
    await turnstile(
      c.env,
      input.turnstileToken,
      c.req.header("CF-Connecting-IP") || "",
    );
  const conversation = await c.env.DB.prepare(
    "SELECT id FROM conversations WHERE id=? AND user_id=?",
  )
    .bind(input.conversationId, user.id)
    .first();
  if (!conversation) throw new HTTPException(404, { message: "NOT_FOUND" });
  const configs = modelConfig(c.env);
  if (!configs || !c.env[secretNames[input.provider]])
    deny("PROVIDER_NOT_CONFIGURED", 503);
  const cfg = configs[input.provider];
  if (input.image) {
    validateImage(input.image);
    if (input.provider === "deepseek") deny("VISION_NOT_SUPPORTED");
  }
  const webFee = input.mode === "web" ? searchCost(c.env) : 0;
  const memory = await c.env.DB.prepare(
    "SELECT enabled,content FROM memory_settings WHERE user_id=?",
  )
    .bind(user.id)
    .first<{ enabled: number; content: string }>();
  const instruction =
    input.mode === "deep"
      ? "Analyze the problem carefully. Compare feasible solutions, assumptions, risks and uncertainty. Give a clear justified conclusion without exposing private internal reasoning."
      : input.mode === "code"
        ? "Act as a careful software engineer. Produce runnable code, explain setup, identify security concerns, and suggest meaningful tests. Do not claim code was executed or deployed unless actual tool evidence is present."
        : "";
  const history = await c.env.DB.prepare(
    "SELECT role,content FROM messages WHERE conversation_id=? AND status='complete' AND (role='user' OR provider=?) ORDER BY created_at DESC,rowid DESC LIMIT 20",
  )
    .bind(input.conversationId, input.provider)
    .all<ChatMessage>();
  const messages: ChatMessage[] = [
    ...(instruction ? [{ role: "system" as const, content: instruction }] : []),
    ...(memory?.enabled && memory.content
      ? [
          {
            role: "system" as const,
            content:
              "User-controlled preferences (not authorization to access external tools): " +
              memory.content,
          },
        ]
      : []),
    ...history.results.reverse(),
    {
      role: "user",
      content: input.message,
      ...(input.image ? { image: input.image } : {}),
    },
  ];
  if (
    new TextEncoder().encode(
      JSON.stringify(messages.map(({ image, ...m }) => m)),
    ).length > 64000
  )
    throw new HTTPException(413, { message: "CONTEXT_TOO_LONG" });
  const cost =
      reservationCost(
        messages.map(({ image, ...m }) => m),
        cfg,
      ) +
      webFee +
      (input.mode === "web" ? (48000 * cfg.input) / 1e6 : 0) +
      (input.image ? (32768 * cfg.input) / 1e6 : 0),
    requestId = await reserve(
      c.env,
      user,
      input.conversationId,
      input.provider,
      cfg,
      cost,
    );
  const created = now();
  await c.env.DB.batch([
    c.env.DB.prepare(
      "INSERT INTO messages(id,conversation_id,role,content,created_at) VALUES(?,?,?,?,?)",
    ).bind(
      crypto.randomUUID(),
      input.conversationId,
      "user",
      input.message,
      created,
    ),
    c.env.DB.prepare("UPDATE conversations SET updated_at=? WHERE id=?").bind(
      created,
      input.conversationId,
    ),
  ]);
  return streamSSE(c, async (stream) => {
    const controller = new AbortController();
    stream.onAbort(() => controller.abort());
    // Retain the final database write after a browser disconnect. The upstream
    // request still receives an abort; waitUntil only protects accounting cleanup.
    let persistenceFinished!: () => void;
    const persistence = new Promise<void>((resolve) => {
      persistenceFinished = resolve;
    });
    try {
      c.executionCtx.waitUntil(persistence);
    } catch {
      /* Local adapters may omit ExecutionContext. */
    }
    let text = "",
      inTokens: number | undefined,
      outTokens: number | undefined,
      status = "complete",
      code: string | null = null;
    try {
      await stream.writeSSE({
        event: "start",
        data: JSON.stringify({
          requestId,
          provider: input.provider,
          model: cfg.model,
        }),
      });
      let sources = "";
      if (input.mode === "web") {
        const found = await searchWeb(c.env, input.message, controller.signal);
        messages.splice(Math.max(0, messages.length - 1), 0, {
          role: "system",
          content: found.context,
        });
        sources = found.sources;
      }
      for await (const chunk of generate(
        c.env,
        input.provider,
        cfg.model,
        messages,
        controller.signal,
      )) {
        if (chunk.input !== undefined) inTokens = chunk.input;
        if (chunk.output !== undefined) outTokens = chunk.output;
        if (chunk.text) {
          text += chunk.text;
          if (text.length > 1000000) throw new ProviderError("OUTPUT_LIMIT");
          await stream.writeSSE({
            event: "delta",
            data: JSON.stringify({ text: chunk.text }),
          });
        }
      }
      if (sources) {
        text += sources;
        await stream.writeSSE({
          event: "delta",
          data: JSON.stringify({ text: sources }),
        });
      }
    } catch (error) {
      status = controller.signal.aborted ? "cancelled" : "error";
      code = error instanceof ProviderError ? error.code : "GENERATION_FAILED";
      if (!controller.signal.aborted)
        await stream
          .writeSSE({
            event: "error",
            data: JSON.stringify({ error: code, requestId }),
          })
          .catch(() => {});
    } finally {
      const reported =
        Number.isInteger(inTokens) &&
        Number.isInteger(outTokens) &&
        inTokens! >= 0 &&
        outTokens! >= 0;
      const actual = reported
        ? (inTokens! * cfg.input + outTokens! * cfg.output) / 1000000 + webFee
        : cost;
      // Incomplete/cancelled calls retain the conservative reservation unless complete usage is known.
      const charged =
        status === "complete" && reported ? actual : Math.max(cost, actual);
      const finished = now();
      try {
        await c.env.DB.batch([
          c.env.DB.prepare(
            "UPDATE requests SET status=?,charged_usd=?,input_tokens=?,output_tokens=?,usage_reported=?,error_code=?,updated_at=? WHERE id=?",
          ).bind(
            status,
            charged,
            inTokens ?? null,
            outTokens ?? null,
            reported ? 1 : 0,
            code,
            finished,
            requestId,
          ),
          c.env.DB.prepare(
            "INSERT INTO messages(id,conversation_id,role,content,provider,request_id,status,created_at) VALUES(?,?,?,?,?,?,?,?)",
          ).bind(
            crypto.randomUUID(),
            input.conversationId,
            "assistant",
            text,
            input.provider,
            requestId,
            status,
            finished,
          ),
          c.env.DB.prepare(
            "UPDATE conversations SET updated_at=? WHERE id=?",
          ).bind(finished, input.conversationId),
        ]);
      } finally {
        persistenceFinished();
      }
      if (!controller.signal.aborted)
        await stream
          .writeSSE({
            event: "done",
            data: JSON.stringify({
              status,
              usage: reported ? { input: inTokens, output: outTokens } : null,
              chargedUsd: charged,
              estimated: status !== "complete" || !reported,
            }),
          })
          .catch(() => {});
    }
  });
});
app.get("/api/usage", async (c) => {
  const u = c.get("identity");
  const result = await c.env.DB.prepare(
    "SELECT provider,COUNT(*) requests,SUM(input_tokens) input_tokens,SUM(output_tokens) output_tokens,SUM(charged_usd) charged_usd,SUM(CASE WHEN usage_reported=0 THEN 1 ELSE 0 END) estimated_requests FROM requests WHERE user_id=? AND created_at>=? GROUP BY provider",
  )
    .bind(u.id, now().slice(0, 7))
    .all();
  const total = await c.env.DB.prepare(
    "SELECT COUNT(*) count FROM conversations WHERE user_id=?",
  )
    .bind(u.id)
    .first();
  return c.json({ models: result.results, conversations: total?.count || 0 });
});
app.post("/api/recovery/codes", async (c) => {
  const u = c.get("identity");
  if (!c.env.SUPABASE_SERVICE_ROLE_KEY) deny("RECOVERY_NOT_CONFIGURED", 503);
  const codes = Array.from({ length: 10 }, () =>
    Array.from(crypto.getRandomValues(new Uint8Array(12)), (b) =>
      b.toString(16).padStart(2, "0"),
    )
      .join("")
      .toUpperCase(),
  );
  const hashes = await Promise.all(
    codes.map((code) => hashCode(code, c.env, u.id)),
  );
  await c.env.DB.batch([
    c.env.DB.prepare("DELETE FROM recovery_codes WHERE user_id=?").bind(u.id),
    ...hashes.map((hash) =>
      c.env.DB.prepare(
        "INSERT INTO recovery_codes(user_id,hash) VALUES(?,?)",
      ).bind(u.id, hash),
    ),
  ]);
  await audit(c.env, u.id, "recovery_codes_generated");
  return c.json({ codes });
});
app.post("/api/recovery/redeem", async (c) => {
  const u = c.get("identity");
  await rateLimit(c.env, "recover:" + u.id, 5, 3600);
  if (!c.env.SUPABASE_SERVICE_ROLE_KEY) deny("RECOVERY_NOT_CONFIGURED", 503);
  const { code } = z
    .object({ code: z.string().regex(/^[a-fA-F0-9]{24}$/) })
    .parse(await c.req.json());
  const methods = u.claims.amr as { method: string; timestamp: number }[];
  if (
    !methods?.some(
      (x) =>
        x.method === "password" &&
        Number.isInteger(x.timestamp) &&
        x.timestamp > Date.now() / 1000 - 300 &&
        x.timestamp <= Date.now() / 1000 + 30,
    )
  )
    deny("FRESH_PASSWORD_LOGIN_REQUIRED");
  const hash = await hashCode(code, c.env, u.id);
  const startedAt = Math.floor(Date.now() / 1000);
  // D1 executes batch statements in one transaction. changes() refers to the
  // immediately preceding lock statement, so invalid or concurrent redemptions
  // cannot consume a code without acquiring the account lock.
  const lock = await c.env.DB.batch([
    c.env.DB.prepare(
      "UPDATE users SET disabled=1,revoked_before=? WHERE id=? AND disabled=0 AND EXISTS(SELECT 1 FROM recovery_codes WHERE user_id=? AND hash=? AND used=0)",
    ).bind(startedAt, u.id, u.id, hash),
    c.env.DB.prepare(
      "UPDATE recovery_codes SET used=1 WHERE user_id=? AND hash=? AND used=0 AND changes()=1",
    ).bind(u.id, hash),
  ]);
  if (lock[0].meta.changes !== 1 || lock[1].meta.changes !== 1)
    deny("INVALID_RECOVERY_CODE");
  // Keep the account disabled throughout destructive factor operations. If any
  // provider call fails, even an existing refresh token that mints a new JWT
  // remains blocked until an operator investigates and re-enables the account.
  await audit(c.env, u.id, "mfa_recovery_started");
  const base =
    c.env.SUPABASE_URL +
    "/auth/v1/admin/users/" +
    encodeURIComponent(u.id) +
    "/factors";
  const headers = {
    Authorization: `Bearer ${c.env.SUPABASE_SERVICE_ROLE_KEY}`,
    apikey: c.env.SUPABASE_SERVICE_ROLE_KEY,
  };
  let listed: Response;
  try {
    listed = await fetch(base, { headers, signal: AbortSignal.timeout(10000) });
  } catch {
    deny("RECOVERY_PROVIDER_FAILED", 503);
  }
  if (!listed.ok) deny("RECOVERY_PROVIDER_FAILED", 503);
  const result = (await listed.json()) as any;
  const factors = Array.isArray(result) ? result : result.factors;
  if (
    !Array.isArray(factors) ||
    factors.some((factor) => typeof factor.id !== "string")
  )
    deny("RECOVERY_PROVIDER_FAILED", 503);
  for (const factor of factors) {
    let deleted: Response;
    try {
      deleted = await fetch(base + "/" + encodeURIComponent(factor.id), {
        method: "DELETE",
        headers,
        signal: AbortSignal.timeout(10000),
      });
    } catch {
      deny("RECOVERY_PROVIDER_FAILED", 503);
    }
    if (!deleted.ok) deny("RECOVERY_PROVIDER_FAILED", 503);
  }
  // A 401 is ambiguous after factor mutations; only a confirmed successful
  // global logout allows the recovery lock to be released.
  await revokeAuthSessions(c, true);
  await c.env.DB.prepare(
    "UPDATE users SET disabled=0,revoked_before=? WHERE id=?",
  )
    .bind(Math.floor(Date.now() / 1000), u.id)
    .run();
  await audit(c.env, u.id, "mfa_recovered");
  return c.json({ ok: true, reauthenticate: true });
});
app.use("/api/admin/*", async (c, next) => {
  if (!c.get("identity").admin) deny("ADMIN_REQUIRED");
  await next();
});
app.post("/api/admin/reconcile", async (c) => {
  const cutoff = new Date(Date.now() - 600000).toISOString();
  const result = await c.env.DB.prepare(
    "UPDATE requests SET status='abandoned',error_code='WORKER_INTERRUPTED',updated_at=? WHERE status='reserved' AND created_at<?",
  )
    .bind(now(), cutoff)
    .run();
  await audit(c.env, c.get("identity").id, "reservations_reconciled");
  return c.json({ released: result.meta.changes });
});
app.get("/api/admin/overview", async (c) => {
  const [users, conversations, usage, errors, health] = await Promise.all([
    c.env.DB.prepare(
      "SELECT id,email,name,disabled,daily_usd,monthly_usd,created_at FROM users ORDER BY created_at DESC LIMIT 100",
    ).all(),
    c.env.DB.prepare("SELECT COUNT(*) count FROM conversations").first(),
    c.env.DB.prepare(
      "SELECT provider,model,COUNT(*) requests,SUM(charged_usd) charged_usd,SUM(input_tokens) input_tokens,SUM(output_tokens) output_tokens,SUM(usage_reported) reported_requests FROM requests GROUP BY provider,model",
    ).all(),
    c.env.DB.prepare(
      "SELECT id,provider,error_code,status,created_at FROM requests WHERE error_code IS NOT NULL ORDER BY created_at DESC LIMIT 50",
    ).all(),
    c.env.DB.prepare("SELECT * FROM provider_health").all(),
  ]);
  return c.json({
    users: users.results,
    usersTotal: (
      await c.env.DB.prepare("SELECT COUNT(*) count FROM users").first()
    )?.count,
    conversations: conversations?.count,
    usage: usage.results,
    errors: errors.results,
    health: health.results,
  });
});
app.patch("/api/admin/users/:id", async (c) => {
  const data = z
    .object({
      disabled: z.boolean(),
      dailyUsd: z.number().min(0).max(1000),
      monthlyUsd: z.number().min(0).max(10000),
    })
    .parse(await c.req.json());
  const id = z.uuid().parse(c.req.param("id"));
  if (id === c.get("identity").id && data.disabled) deny("CANNOT_DISABLE_SELF");
  await c.env.DB.prepare(
    "UPDATE users SET disabled=?,daily_usd=?,monthly_usd=? WHERE id=?",
  )
    .bind(data.disabled ? 1 : 0, data.dailyUsd, data.monthlyUsd, id)
    .run();
  await audit(c.env, c.get("identity").id, "user_limits_updated", id);
  return c.json({ ok: true });
});
app.route("/api", extensions);
app.route("/api/studio", media);
app.route("/api/agents", agents);
app.route("/api/schedules", schedules);
app.all("/api/*", (c) => c.json({ error: "NOT_FOUND" }, 404));
app.all("*", (c) => c.env.ASSETS.fetch(c.req.raw));
export default Object.assign(app, { scheduled });
