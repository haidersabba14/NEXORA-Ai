export type Provider = "openai" | "gemini" | "deepseek" | "anthropic";
export const providers: Provider[] = [
  "openai",
  "gemini",
  "deepseek",
  "anthropic",
];
export interface ModelConfig {
  model: string;
  input: number;
  output: number;
}
export interface Env {
  DB: D1Database;
  ASSETS: Fetcher;
  APP_ORIGIN: string;
  SUPABASE_URL: string;
  SUPABASE_ANON_KEY: string;
  SUPABASE_SERVICE_ROLE_KEY?: string;
  OPENAI_API_KEY?: string;
  GEMINI_API_KEY?: string;
  DEEPSEEK_API_KEY?: string;
  ANTHROPIC_API_KEY?: string;
  TURNSTILE_SITE_KEY?: string;
  TURNSTILE_SECRET_KEY?: string;
  MODEL_CONFIG_JSON?: string;
  GLOBAL_DAILY_USD?: string;
  GLOBAL_MONTHLY_USD?: string;
  RECOVERY_PEPPER?: string;
  BRAVE_SEARCH_API_KEY?: string;
  SEARCH_CONFIG_JSON?: string;
}
export interface Identity {
  id: string;
  email: string;
  aal: string;
  iat: number;
  claims: Record<string, unknown>;
  admin: boolean;
}
export type Bindings = {
  Bindings: Env;
  Variables: { identity: Identity; requestId: string };
};
export interface ChatMessage {
  image?: string;
  role: "user" | "assistant" | "system";
  content: string;
}
export const secretNames: Record<Provider, keyof Env> = {
  openai: "OPENAI_API_KEY",
  gemini: "GEMINI_API_KEY",
  deepseek: "DEEPSEEK_API_KEY",
  anthropic: "ANTHROPIC_API_KEY",
};
