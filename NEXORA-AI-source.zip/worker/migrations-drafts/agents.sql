-- Parent must append this schema as a NEW numbered D1 migration; do not edit applied migrations.
CREATE TABLE agent_runs (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id),
  conversation_id TEXT REFERENCES conversations(id) ON DELETE SET NULL,
  template TEXT NOT NULL,
  provider TEXT NOT NULL,
  task TEXT NOT NULL,
  status TEXT NOT NULL,
  error_code TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX agent_runs_owner ON agent_runs(user_id,created_at);
CREATE UNIQUE INDEX agent_runs_one_active ON agent_runs(user_id) WHERE status='running';
CREATE TABLE agent_steps (
  id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL REFERENCES agent_runs(id) ON DELETE CASCADE,
  position INTEGER NOT NULL,
  role TEXT NOT NULL,
  provider TEXT NOT NULL,
  model TEXT NOT NULL,
  request_id TEXT REFERENCES requests(id),
  content TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL,
  charged_usd REAL NOT NULL DEFAULT 0,
  usage_reported INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(run_id,position)
);
