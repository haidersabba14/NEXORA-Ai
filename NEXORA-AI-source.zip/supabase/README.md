# Supabase configuration

The application uses Supabase Auth only; operational tables live in Cloudflare D1. There is no PostgreSQL chat schema to migrate.

Configure the managed Supabase project in its dashboard as described in `docs/MOBILE-SETUP.md`: confirmed email, TOTP, asymmetric JWT signing/JWKS, Turnstile CAPTCHA, auth rate limits, SMTP, exact URL allowlists, and optionally Google OAuth. These settings cannot be applied with an anon key. The service role in this project is used only by the server's recovery path; it is not a project-management token.

Supabase owns password hashing, TOTP secrets, factors, email confirmation and refresh sessions. D1 holds only profile display fields, quota records, application revocation timestamps, and HMACs of application recovery codes. No fixture/test user is seeded into a real Supabase project.
