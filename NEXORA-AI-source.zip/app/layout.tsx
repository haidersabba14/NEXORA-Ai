import type { Metadata, Viewport } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "NEXORA AI — Intelligence, connected.",
  description:
    "Your private workspace for OpenAI, Gemini, DeepSeek and Claude.",
  applicationName: "NEXORA AI",
};
export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#080a11",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body>{children}</body>
    </html>
  );
}
