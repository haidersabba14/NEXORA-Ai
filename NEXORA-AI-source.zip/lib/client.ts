import type { SupabaseClient } from "@supabase/supabase-js";
export interface Provider {
  id: string;
  model: string | null;
  configured: boolean;
  status?: string;
  checked_at?: string;
}
export interface Config {
  supabaseUrl: string | null;
  supabaseAnonKey: string | null;
  authConfigured: boolean;
  turnstileSiteKey: string | null;
  budgetEnabled: boolean;
  providers: Provider[];
}
export interface Profile {
  id: string;
  email: string;
  name: string;
  avatar: string;
  aal: string;
  admin: boolean;
  daily_usd: number;
  monthly_usd: number;
  recoveryEnabled: boolean;
}
export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  provider?: string;
  status?: string;
}
export interface Conversation {
  id: string;
  title: string;
  updated_at: string;
}
export class APIError extends Error {
  constructor(
    public code: string,
    public status: number,
  ) {
    super(code);
  }
}
export async function request<T = any>(
  auth: SupabaseClient | null,
  path: string,
  init: RequestInit = {},
): Promise<T> {
  const session = auth ? (await auth.auth.getSession()).data.session : null;
  const r = await fetch("/api" + path, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(session ? { Authorization: `Bearer ${session.access_token}` } : {}),
      ...init.headers,
    },
  });
  const data = (await r.json()) as any;
  if (!r.ok) throw new APIError(data.error || "REQUEST_FAILED", r.status);
  return data;
}
export async function consumeEvents(
  response: Response,
  onEvent: (event: string, data: any) => void,
) {
  if (!response.body) throw Error("EMPTY_RESPONSE");
  const reader = response.body.getReader(),
    decoder = new TextDecoder();
  let buffer = "";
  try {
    while (true) {
      const { value, done } = await reader.read();
      buffer += decoder.decode(value, { stream: !done });
      let match: RegExpExecArray | null;
      while ((match = /\r?\n\r?\n/.exec(buffer))) {
        const event = buffer.slice(0, match.index);
        buffer = buffer.slice(match.index + match[0].length);
        const lines = event.split(/\r?\n/);
        const type =
          lines
            .find((x) => x.startsWith("event:"))
            ?.slice(6)
            .trim() || "message";
        const data = lines
          .filter((x) => x.startsWith("data:"))
          .map((x) => x.slice(5).trimStart())
          .join("\n");
        if (data) onEvent(type, JSON.parse(data));
      }
      if (done) break;
    }
  } finally {
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}
export const providerNames: Record<string, string> = {
  openai: "ChatGPT",
  gemini: "Gemini",
  deepseek: "DeepSeek",
  anthropic: "Claude",
};
export function download(
  name: string,
  content: string,
  type = "text/markdown",
) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
