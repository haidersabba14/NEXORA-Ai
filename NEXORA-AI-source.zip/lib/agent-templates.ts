export const agentTemplates = [
  {
    id: "hive",
    name: "NEXORA HIVE MIND",
    ar: "مجلس المراجعة",
    description: "Independent analysis, a critical review, and a synthesis.",
    descriptionAr: "تحليل مستقل، ومراجعة نقدية، ثم خلاصة مشتركة.",
    roles: [
      "Problem solver",
      "Independent challenger",
      "Evidence reviewer",
      "Final synthesizer",
    ],
  },
  {
    id: "workforce",
    name: "AI DIGITAL WORKFORCE",
    ar: "فريق العمل الرقمي",
    description:
      "Product, engineering and quality roles produce a project handoff.",
    descriptionAr:
      "أدوار المنتج والهندسة والجودة تُعدّ تسليمًا منظمًا للمشروع.",
    roles: [
      "Product lead",
      "Engineering lead",
      "Quality and security reviewer",
      "Delivery coordinator",
    ],
  },
  {
    id: "scenario",
    name: "SCENARIO LAB",
    ar: "مختبر السيناريوهات",
    description:
      "Compare explicitly described scenarios, assumptions and tradeoffs.",
    descriptionAr: "مقارنة سيناريوهات محددة مع الافتراضات والمفاضلات.",
    roles: [
      "Scenario designer",
      "Scenario analyst",
      "Uncertainty reviewer",
      "Decision report author",
    ],
  },
  {
    id: "scientist",
    name: "AI SCIENTIST LAB",
    ar: "مختبر الفرضيات",
    description:
      "Propose hypotheses, experiment protocols and validation criteria.",
    descriptionAr: "اقتراح فرضيات وبروتوكولات تجارب ومعايير تحقق.",
    roles: [
      "Hypothesis researcher",
      "Experiment designer",
      "Statistical reviewer",
      "Research protocol editor",
    ],
  },
  {
    id: "appfactory",
    name: "APP FACTORY",
    ar: "مصنع مقترحات التطبيقات",
    description:
      "Produce architecture, code proposals, test cases and deployment instructions.",
    descriptionAr: "إنتاج معمارية ومقترحات كود وحالات اختبار وتعليمات نشر.",
    roles: [
      "Application architect",
      "Implementation author",
      "Test and security reviewer",
      "Release plan author",
    ],
  },
  {
    id: "evaluate",
    name: "AGENT EVALUATION",
    ar: "تقييم وتطوير الوكلاء",
    description: "Review supplied outputs and propose measurable improvements.",
    descriptionAr: "مراجعة مخرجات مقدمة واقتراح تحسينات قابلة للقياس.",
    roles: [
      "Evaluation designer",
      "Performance analyst",
      "Adversarial reviewer",
      "Improvement proposal editor",
    ],
  },
  {
    id: "toolcreator",
    name: "AI TOOL CREATOR",
    ar: "تصميم الأدوات",
    description: "Draft a tool contract, implementation and safe test plan.",
    descriptionAr: "صياغة عقد أداة وتنفيذ مقترح وخطة اختبار آمنة.",
    roles: [
      "Tool specification author",
      "Tool implementation author",
      "Security reviewer",
      "Tool handoff editor",
    ],
  },
  {
    id: "forecast",
    name: "PREDICTIVE ANALYSIS",
    ar: "تحليل التوقعات",
    description:
      "Analyze supplied data and disclose uncertainty and limitations.",
    descriptionAr: "تحليل البيانات المقدمة مع توضيح عدم اليقين والحدود.",
    roles: [
      "Data assumptions analyst",
      "Forecast analyst",
      "Uncertainty and bias reviewer",
      "Forecast report editor",
    ],
  },
  {
    id: "control",
    name: "CONTROL CENTER ANALYST",
    ar: "محلل لوحة التحكم",
    description:
      "Read your actual workspace usage snapshot and propose next actions.",
    descriptionAr: "قراءة لقطة استخدام حقيقية لمساحتك واقتراح الخطوات التالية.",
    roles: [
      "Workspace diagnostics analyst",
      "Operations planner",
      "Risk reviewer",
      "Operations report editor",
    ],
  },
  {
    id: "business",
    name: "BUSINESS OPERATIONS LAB",
    ar: "مختبر عمليات الأعمال",
    description:
      "Draft support, store and reporting workflows for operator review.",
    descriptionAr: "إعداد إجراءات الدعم والمتجر والتقارير لمراجعة المشغّل.",
    roles: [
      "Business process analyst",
      "Operations designer",
      "Financial and privacy reviewer",
      "Business runbook author",
    ],
  },
  {
    id: "alwayson",
    name: "ALWAYS-ON RUNBOOK",
    ar: "دليل متابعة المشاريع",
    description:
      "Design a monitoring runbook; this run does not schedule background work.",
    descriptionAr: "تصميم دليل متابعة؛ هذا التشغيل لا ينشئ مهام خلفية مجدولة.",
    roles: [
      "Monitoring requirements analyst",
      "Incident response planner",
      "Escalation reviewer",
      "Monitoring runbook editor",
    ],
  },
  {
    id: "private-model",
    name: "PRIVATE MODEL PLANNING",
    ar: "تخطيط النماذج الخاصة",
    description:
      "Assess a private model project; no training or server provisioning occurs.",
    descriptionAr: "تقييم مشروع نموذج خاص؛ لا ينفذ تدريبًا أو إنشاء خوادم.",
    roles: [
      "Private model architect",
      "Data governance reviewer",
      "Evaluation and cost analyst",
      "Private deployment plan editor",
    ],
  },
] as const;
export type AgentTemplateId = (typeof agentTemplates)[number]["id"];
export function planAgentRoles(id: AgentTemplateId, count: number) {
  const template = agentTemplates.find((t) => t.id === id);
  if (!template) throw Error("UNKNOWN_AGENT_TEMPLATE");
  const size = Math.min(4, Math.max(2, Math.floor(count)));
  return [...template.roles.slice(0, size - 1), template.roles[3]];
}
