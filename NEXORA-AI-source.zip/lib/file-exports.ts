/** Local document export helpers. None of these functions call an AI or upload data. */
export type ExportKind = "pdf" | "pptx" | "xlsx";
export interface ExportInput {
  title: string;
  content: string;
  ar: boolean;
}
export interface SlideSection {
  title: string;
  body: string;
}
const MAX_CONTENT = 50_000;
export function normalizeDocument(input: ExportInput): ExportInput {
  const title = input.title.trim() || "NEXORA";
  const content = input.content.replace(/\r\n?/g, "\n").trim();
  if (!content) throw new Error("CONTENT_REQUIRED");
  if (content.length > MAX_CONTENT || title.length > 120)
    throw new Error("DOCUMENT_TOO_LARGE");
  if (/[\x00-\x08\x0B\x0C\x0E-\x1F]/.test(title + content))
    throw new Error("UNSUPPORTED_CONTROL_CHARACTER");
  return { title, content, ar: input.ar };
}
export function safeFilename(title: string): string {
  return (
    title
      .replace(/[<>:"/\\|?*\x00-\x1F]/g, "-")
      .replace(/[. ]+$/g, "")
      .slice(0, 90) || "nexora-document"
  );
}
/** RFC 4180-style CSV: quoted commas/newlines and escaped double quotes are supported. */
export function parseCSV(text: string): string[][] {
  if (!text.trim()) throw new Error("CONTENT_REQUIRED");
  if (text.length > MAX_CONTENT) throw new Error("DOCUMENT_TOO_LARGE");
  const rows: string[][] = [];
  let row: string[] = [],
    field = "",
    quoted = false,
    closed = false;
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (quoted) {
      if (char === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          quoted = false;
          closed = true;
        }
      } else field += char;
    } else if (char === '"') {
      if (field || closed) throw new Error("INVALID_CSV");
      quoted = true;
    } else if (char === ",") {
      row.push(field);
      field = "";
      closed = false;
    } else if (char === "\n" || char === "\r") {
      if (char === "\r" && text[i + 1] === "\n") i++;
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
      closed = false;
    } else {
      if (closed && char.trim()) throw new Error("INVALID_CSV");
      if (!closed) field += char;
    }
    if (row.length >= 30 || rows.length >= 1000)
      throw new Error("TABLE_TOO_LARGE");
  }
  if (quoted) throw new Error("INVALID_CSV");
  if (field || row.length || closed) {
    row.push(field);
    rows.push(row);
  }
  while (rows.length && rows[rows.length - 1].every((cell) => !cell.trim()))
    rows.pop();
  if (!rows.length || rows.some((r) => r.length > 30))
    throw new Error("TABLE_TOO_LARGE");
  const width = Math.max(...rows.map((r) => r.length));
  return rows.map((r) => [...r, ...Array(width - r.length).fill("")]);
}
export function presentationSections(
  content: string,
  fallbackTitle: string,
): SlideSection[] {
  const sections = content
    .trim()
    .split(/\n\s*\n/)
    .filter(Boolean)
    .map((block, index) => {
      const lines = block.split("\n"),
        heading = lines[0].match(/^#{1,3}\s+(.+)$/);
      return {
        title: heading ? heading[1] : `${fallbackTitle} · ${index + 1}`,
        body: heading ? lines.slice(1).join("\n") : block,
      };
    });
  if (!sections.length) throw new Error("CONTENT_REQUIRED");
  if (
    sections.length > 30 ||
    sections.some((s) => s.body.length > 1800 || s.title.length > 120)
  )
    throw new Error("SLIDES_TOO_DENSE");
  return sections;
}
function save(blob: Blob, name: string) {
  const link = document.createElement("a"),
    url = URL.createObjectURL(blob);
  link.href = url;
  link.download = name;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}
let font: Promise<string> | null = null;
async function arabicFont(): Promise<string> {
  if (!font)
    font = fetch("/fonts/Amiri-Regular.ttf")
      .then(async (response) => {
        if (!response.ok) throw new Error("FONT_UNAVAILABLE");
        const bytes = new Uint8Array(await response.arrayBuffer());
        let binary = "";
        for (let i = 0; i < bytes.length; i += 8192)
          binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
        return btoa(binary);
      })
      .catch((error) => {
        font = null;
        throw error;
      });
  return font;
}
export async function makePDF(input: ExportInput): Promise<Blob> {
  const { title, content, ar } = normalizeDocument(input);
  const [{ jsPDF }, data] = await Promise.all([import("jspdf"), arabicFont()]);
  const doc = new jsPDF({ format: "a4", unit: "mm", compress: true });
  doc.addFileToVFS("Amiri-Regular.ttf", data);
  doc.addFont("Amiri-Regular.ttf", "Amiri", "normal");
  doc.setFont("Amiri", "normal");
  const metadata = doc.getFont().metadata as unknown as {
    characterToGlyph?: (point: number) => number;
  };
  for (const char of title + content) {
    const point = char.codePointAt(0)!;
    if (
      !/\s/.test(char) &&
      (point > 0xffff || !metadata.characterToGlyph?.(point))
    )
      throw new Error("PDF_UNSUPPORTED_CHARACTER");
  }
  doc.setProperties({
    title,
    author: "NEXORA AI",
    creator: "NEXORA File Studio",
  });
  // jsPDF's global R2L flag reverses Latin and double-reverses Arabic.
  // Shape logical Unicode input, then output visual glyph order per line instead.
  doc.setR2L(false);
  const margin = 19,
    width = 172,
    maxY = 277;
  let y = 24;
  function line(text: string, size: number, color: [number, number, number]) {
    doc.setFontSize(size);
    doc.setTextColor(...color);
    const lines = doc.splitTextToSize(text, width) as string[];
    const height = size * 0.52;
    for (const value of lines) {
      if (y + height > maxY) {
        doc.addPage();
        y = 22;
      }
      doc.text(value, ar ? 191 : margin, y, {
        align: ar ? "right" : "left",
        isInputVisual: false,
        isOutputVisual: true,
        isOutputRtl: false,
      });
      y += height;
    }
  }
  line(title, 23, [72, 53, 125]);
  y += 6;
  content.split("\n").forEach((paragraph) => {
    if (paragraph.trim()) line(paragraph, 13, [38, 42, 55]);
    else y += 3;
  });
  return doc.output("blob");
}
export async function makePresentation(input: ExportInput): Promise<Blob> {
  const { title, content, ar } = normalizeDocument(input),
    sections = presentationSections(content, title);
  const { default: PptxGenJS } = await import("pptxgenjs");
  const pptx = new PptxGenJS();
  pptx.layout = "LAYOUT_WIDE";
  pptx.author = "NEXORA AI";
  pptx.subject = title;
  pptx.title = title;
  pptx.company = "NEXORA AI";
  pptx.theme = {
    headFontFace: "Arial",
    bodyFontFace: "Arial",
  };
  const cover = pptx.addSlide();
  cover.background = { color: "0C1020" };
  cover.addText("NEXORA AI", {
    x: 0.7,
    y: 0.6,
    w: 12,
    h: 0.4,
    fontSize: 14,
    color: "AB91EB",
    charSpacing: 3,
    align: ar ? "right" : "left",
    rtlMode: ar,
    lang: ar ? "ar-SA" : "en-US",
  });
  cover.addText(title, {
    x: 0.7,
    y: 2.3,
    w: 12,
    h: 2,
    fontSize: 38,
    color: "F0EBFF",
    bold: true,
    align: ar ? "right" : "left",
    rtlMode: ar,
    lang: ar ? "ar-SA" : "en-US",
    fit: "shrink",
    margin: 0,
  });
  for (const [index, section] of sections.entries()) {
    const slide = pptx.addSlide();
    slide.background = { color: "0C1020" };
    slide.addText(section.title, {
      x: 0.7,
      y: 0.6,
      w: 12,
      h: 0.9,
      fontSize: 27,
      color: "C5B2F5",
      bold: true,
      align: ar ? "right" : "left",
      rtlMode: ar,
      lang: ar ? "ar-SA" : "en-US",
      fit: "shrink",
      margin: 0,
    });
    slide.addText(section.body, {
      x: 0.7,
      y: 1.8,
      w: 12,
      h: 4.8,
      fontSize: 22,
      color: "D6D9E6",
      align: ar ? "right" : "left",
      rtlMode: ar,
      lang: ar ? "ar-SA" : "en-US",
      breakLine: false,
      fit: "shrink",
      paraSpaceAfter: 14,
      margin: 0,
    });
    slide.addText(`${index + 1} / ${sections.length}`, {
      x: 0.7,
      y: 7,
      w: 12,
      h: 0.2,
      fontSize: 9,
      color: "7C819A",
      align: ar ? "left" : "right",
    });
  }
  return (await pptx.write({ outputType: "blob" })) as Blob;
}
export async function makeSpreadsheet(input: ExportInput): Promise<Blob> {
  const { title, content, ar } = normalizeDocument(input),
    rows = parseCSV(content);
  const { default: ExcelJS } = await import("exceljs");
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "NEXORA AI";
  workbook.title = title;
  const sheet = workbook.addWorksheet(
    title.replace(/[\\/*?:\[\]]/g, " ").slice(0, 31) || "NEXORA",
    { views: [{ state: "frozen", ySplit: 1, rightToLeft: ar }] },
  );
  // Every cell is text, including leading =/+/-/@. No user input becomes an Excel formula.
  sheet.addRows(rows);
  sheet.getRow(1).font = { bold: true, color: { argb: "FFF2ECFF" } };
  sheet.getRow(1).fill = {
    type: "pattern",
    pattern: "solid",
    fgColor: { argb: "FF59428C" },
  };
  sheet.getRow(1).height = 27;
  sheet.autoFilter = {
    from: { row: 1, column: 1 },
    to: { row: rows.length, column: rows[0].length },
  };
  sheet.columns.forEach((column, index) => {
    column.width = Math.min(
      55,
      Math.max(15, ...rows.slice(0, 100).map((row) => row[index].length + 3)),
    );
    column.alignment = {
      vertical: "top",
      horizontal: ar ? "right" : "left",
      wrapText: true,
    };
  });
  const buffer = await workbook.xlsx.writeBuffer();
  return new Blob([new Uint8Array(buffer as ArrayBuffer)], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
}
export async function exportDocument(
  kind: ExportKind,
  input: ExportInput,
): Promise<void> {
  const doc = normalizeDocument(input);
  const blob =
    kind === "pdf"
      ? await makePDF(doc)
      : kind === "pptx"
        ? await makePresentation(doc)
        : await makeSpreadsheet(doc);
  save(blob, `${safeFilename(doc.title)}.${kind}`);
}
