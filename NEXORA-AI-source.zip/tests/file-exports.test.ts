import { describe, it, expect, vi } from "vitest";
import {
  parseCSV,
  presentationSections,
  normalizeDocument,
  safeFilename,
  makePresentation,
  makeSpreadsheet,
  makePDF,
} from "../lib/file-exports";
describe("local file generation", () => {
  it("parses CSV quoted commas, escaped quotes, newlines and Arabic", () => {
    expect(
      parseCSV(
        'الاسم,الوصف\n"مشروع، أول","first, second"\n"A ""quote""","line 1\nline 2"',
      ),
    ).toEqual([
      ["الاسم", "الوصف"],
      ["مشروع، أول", "first, second"],
      ['A "quote"', "line 1\nline 2"],
    ]);
  });
  it("rejects malformed CSV and excessive columns", () => {
    expect(() => parseCSV('A,B\n"unfinished')).toThrow("INVALID_CSV");
    expect(() => parseCSV(Array(31).fill("x").join(","))).toThrow(
      "TABLE_TOO_LARGE",
    );
  });
  it("splits editable slides on blank lines and respects explicit headings", () => {
    expect(
      presentationSections("# Intro\nFirst part\n\nSecond part", "Report"),
    ).toEqual([
      { title: "Intro", body: "First part" },
      { title: "Report · 2", body: "Second part" },
    ]);
    expect(() => presentationSections("x".repeat(1801), "X")).toThrow(
      "SLIDES_TOO_DENSE",
    );
  });
  it("rejects empty and unbounded documents and sanitizes filenames", () => {
    expect(() =>
      normalizeDocument({ title: "x", content: " ", ar: false }),
    ).toThrow("CONTENT_REQUIRED");
    expect(safeFilename("a/b:c?")).toBe("a-b-c-");
    expect(() =>
      normalizeDocument({ title: "x", content: "x".repeat(50001), ar: false }),
    ).toThrow("DOCUMENT_TOO_LARGE");
  });
  it("creates real PPTX and XLSX ZIP archives and preserves formula-like values as text", async () => {
    const pptx = await makePresentation({
      title: "Test",
      content: "# First\nReal slide",
      ar: false,
    });
    expect(new Uint8Array(await pptx.arrayBuffer()).slice(0, 2)).toEqual(
      new Uint8Array([0x50, 0x4b]),
    );
    const xlsx = await makeSpreadsheet({
      title: "Test",
      content: "Name,Value\nExample,=1+1",
      ar: false,
    });
    expect(new Uint8Array(await xlsx.arrayBuffer()).slice(0, 2)).toEqual(
      new Uint8Array([0x50, 0x4b]),
    );
    const { default: ExcelJS } = await import("exceljs");
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(await xlsx.arrayBuffer());
    expect(workbook.worksheets[0].getCell("B2").value).toBe("=1+1");
    expect(workbook.worksheets[0].getCell("B2").formula).toBeUndefined();
  });
});

import { readFileSync } from "node:fs";
describe("Arabic PDF", () => {
  it("embeds a real font and rejects missing glyphs instead of corrupting text", async () => {
    const bytes = readFileSync("public/fonts/Amiri-Regular.ttf");
    const spy = vi
      .spyOn(globalThis, "fetch")
      .mockImplementation(async () => new Response(bytes));
    try {
      const result = await makePDF({
        title: "تقرير المشروع",
        content: "مرحبا بالعالم\nNEXORA report 2026",
        ar: true,
      });
      expect(
        new TextDecoder().decode(
          new Uint8Array(await result.arrayBuffer()).slice(0, 5),
        ),
      ).toBe("%PDF-");
      await expect(
        makePDF({ title: "Report", content: "Hello 😀", ar: false }),
      ).rejects.toThrow("PDF_UNSUPPORTED_CHARACTER");
    } finally {
      spy.mockRestore();
    }
  });
});
