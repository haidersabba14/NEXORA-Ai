import { describe, it, expect } from "vitest";
import {
  parseSSE,
  extract,
  providerRequest,
  modelConfig,
} from "../worker/src/providers";
import type { Env } from "../worker/src/types";
function body(parts: string[]) {
  return new ReadableStream<Uint8Array>({
    start(c) {
      for (const p of parts) c.enqueue(new TextEncoder().encode(p));
      c.close();
    },
  });
}
describe("official protocol adapters (test fixtures, no live API calls)", () => {
  it("parses SSE split across arbitrary chunks and CRLF boundaries", async () => {
    const events = [];
    for await (const e of parseSSE(
      body([
        "event: del",
        'ta\r\ndata: {"text":"hello"}\r',
        "\n\r\ndata: [DONE]\n\n",
      ]),
    ))
      events.push(e);
    expect(events).toEqual([
      { event: "delta", data: '{"text":"hello"}' },
      { event: "message", data: "[DONE]" },
    ]);
  });
  it("supports multiline data and ignores comments", async () => {
    const events = [];
    for await (const e of parseSSE(
      body([": keepalive\n\ndata: one\ndata: two\n\n"]),
    ))
      events.push(e);
    expect(events).toEqual([{ event: "message", data: "one\ntwo" }]);
  });
  it("extracts Responses text and actual usage", () => {
    expect(
      extract("openai", { type: "response.output_text.delta", delta: "Hello" })
        .text,
    ).toBe("Hello");
    expect(
      extract("openai", {
        type: "response.completed",
        response: { usage: { input_tokens: 10, output_tokens: 20 } },
      }),
    ).toEqual({ input: 10, output: 20, done: true });
  });
  it("handles Gemini thinking tokens without displaying thoughts", () => {
    expect(
      extract("gemini", {
        candidates: [
          {
            content: {
              parts: [{ thought: true, text: "hidden" }, { text: "answer" }],
            },
          },
        ],
        usageMetadata: {
          promptTokenCount: 10,
          candidatesTokenCount: 20,
          thoughtsTokenCount: 5,
        },
      }),
    ).toEqual({ text: "answer", input: 10, output: 25 });
  });
  it("extracts Claude start and delta usage", () => {
    expect(
      extract("anthropic", {
        type: "message_start",
        message: { usage: { input_tokens: 15 } },
      }).input,
    ).toBe(15);
    expect(
      extract("anthropic", {
        type: "message_delta",
        usage: { output_tokens: 23 },
      }).output,
    ).toBe(23);
    expect(
      extract("anthropic", {
        type: "content_block_delta",
        delta: { type: "text_delta", text: "hello" },
      }).text,
    ).toBe("hello");
  });
  it("extracts DeepSeek stream usage", () => {
    expect(
      extract("deepseek", {
        choices: [{ delta: { content: "answer" } }],
        usage: { prompt_tokens: 4, completion_tokens: 6 },
      }),
    ).toEqual({ text: "answer", input: 4, output: 6 });
  });
  it("rejects upstream failures and incomplete Responses", () => {
    expect(() => extract("openai", { type: "response.failed" })).toThrow(
      "PROVIDER_INCOMPLETE",
    );
    expect(() =>
      extract("anthropic", { type: "error", error: { message: "SECRET" } }),
    ).toThrow("PROVIDER_STREAM_ERROR");
  });
  it("uses only fixed official hosts and keeps keys out of URLs", () => {
    const env = {
      OPENAI_API_KEY: "private",
      GEMINI_API_KEY: "private",
      DEEPSEEK_API_KEY: "private",
      ANTHROPIC_API_KEY: "private",
    } as Env;
    for (const provider of [
      "openai",
      "gemini",
      "deepseek",
      "anthropic",
    ] as const) {
      const r = providerRequest(
        env,
        provider,
        "configured-model",
        [{ role: "user", content: "Hi" }],
        2048,
      );
      expect(new URL(r.url).protocol).toBe("https:");
      expect(r.url).not.toContain("private");
      expect(JSON.parse(r.init.body as string)).not.toHaveProperty("api_key");
    }
  });
  it("requires configured keys and complete, positive model prices", () => {
    expect(() => providerRequest({} as Env, "openai", "x", [], 20)).toThrow(
      "PROVIDER_NOT_CONFIGURED",
    );
    expect(modelConfig({ MODEL_CONFIG_JSON: "{}" } as Env)).toBeNull();
    expect(
      modelConfig({
        MODEL_CONFIG_JSON: JSON.stringify({
          openai: { model: "x", input: 0, output: 0 },
        }),
      } as Env),
    ).toBeNull();
  });
});
