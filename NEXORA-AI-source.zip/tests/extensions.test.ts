import { describe, it, expect } from "vitest";
import { searchCost, validateImage } from "../worker/src/extensions";
import { providerRequest } from "../worker/src/providers";
import { runScheduled } from "../worker/src/scheduler";
import { database } from "./d1";
import type { Env, ChatMessage } from "../worker/src/types";
describe("opt-in research, vision and scheduled execution", () => {
  it("does not enable paid research without an explicit key and price", () => {
    expect(() => searchCost({} as Env)).toThrow("SEARCH_NOT_CONFIGURED");
    expect(() =>
      searchCost({
        BRAVE_SEARCH_API_KEY: "test",
        SEARCH_CONFIG_JSON: '{"costPerRequestUsd":0}',
      } as Env),
    ).toThrow("SEARCH_NOT_CONFIGURED");
    expect(
      searchCost({
        BRAVE_SEARCH_API_KEY: "test",
        SEARCH_CONFIG_JSON: '{"costPerRequestUsd":0.01}',
      } as Env),
    ).toBe(0.01);
  });
  it("rejects SVG, unsupported types and excessive image dimensions", () => {
    expect(() => validateImage("data:image/svg+xml;base64,PHN2Zz4=")).toThrow(
      "INVALID_IMAGE",
    );
    const bytes = new Uint8Array(25);
    bytes.set([137, 80, 78, 71]);
    new DataView(bytes.buffer).setUint32(16, 4000);
    new DataView(bytes.buffer).setUint32(20, 4000);
    expect(() =>
      validateImage(
        "data:image/png;base64," + btoa(String.fromCharCode(...bytes)),
      ),
    ).toThrow("IMAGE_DIMENSIONS_UNSUPPORTED");
  });
  it("maps system preferences and vision to official provider request shapes", () => {
    const env = {
      OPENAI_API_KEY: "test",
      GEMINI_API_KEY: "test",
      ANTHROPIC_API_KEY: "test",
      DEEPSEEK_API_KEY: "test",
    } as Env;
    const messages: ChatMessage[] = [
      { role: "system", content: "User preference" },
      {
        role: "user",
        content: "Describe",
        image: "data:image/jpeg;base64,/9j/",
      },
    ];
    const openai = JSON.parse(
      providerRequest(env, "openai", "model", messages, 2048).init.body,
    );
    expect(openai.input[1].content[1].type).toBe("input_image");
    const gemini = JSON.parse(
      providerRequest(env, "gemini", "model", messages, 2048).init.body,
    );
    expect(gemini.systemInstruction.parts[0].text).toBe("User preference");
    expect(gemini.contents).toHaveLength(1);
    expect(gemini.contents[0].parts[1].inlineData.mimeType).toBe("image/jpeg");
    const claude = JSON.parse(
      providerRequest(env, "anthropic", "model", messages, 2048).init.body,
    );
    expect(claude.system).toBe("User preference");
    expect(claude.messages[0].content[0].source.media_type).toBe("image/jpeg");
    expect(() =>
      providerRequest(env, "deepseek", "model", messages, 2048),
    ).toThrow("VISION_NOT_SUPPORTED");
  });
  it("executes a due internal health job once without AI calls and skips disabled users", async () => {
    const { db } = database();
    const id = "11111111-1111-4111-8111-111111111111";
    await db
      .prepare("INSERT INTO users(id,email) VALUES(?,?)")
      .bind(id, "test@example.test")
      .run();
    const task = "test-task";
    await db
      .prepare(
        "INSERT INTO scheduled_tasks(id,user_id,title,prompt,provider,interval_hours,kind,next_run,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
      )
      .bind(
        task,
        id,
        "health",
        "check internal database",
        "openai",
        1,
        "health",
        "2000-01-01",
        "2000-01-01",
      )
      .run();
    const env = { DB: db } as Env;
    await runScheduled(env);
    const row = await db
      .prepare("SELECT * FROM scheduled_tasks WHERE id=?")
      .bind(task)
      .first<any>();
    expect(row.last_status).toBe("complete");
    expect(JSON.parse(row.last_output).database).toBe("connected");
    const last = row.last_run;
    await runScheduled(env);
    expect(
      (
        await db
          .prepare("SELECT last_run FROM scheduled_tasks WHERE id=?")
          .bind(task)
          .first<any>()
      ).last_run,
    ).toBe(last);
    await db.prepare("UPDATE users SET disabled=1 WHERE id=?").bind(id).run();
    await db
      .prepare(
        "UPDATE scheduled_tasks SET next_run='2000-01-01',last_status='pending' WHERE id=?",
      )
      .bind(task)
      .run();
    await runScheduled(env);
    expect(
      (
        await db
          .prepare("SELECT last_status FROM scheduled_tasks WHERE id=?")
          .bind(task)
          .first<any>()
      ).last_status,
    ).toBe("pending");
  });
});
