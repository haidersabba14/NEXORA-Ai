import { describe, it, expect, vi } from "vitest";
import { Hono } from "hono";
import { readFileSync } from "node:fs";
import media, {
  studioConfig,
  imagePayload,
  videoPayload,
  operationURL,
  checkedVideoURL,
  decodePNG,
  type MediaEnv,
} from "../worker/src/media";
import type { Bindings, Identity } from "../worker/src/types";
import { database } from "./d1";
const id = "11111111-1111-4111-8111-111111111111",
  other = "22222222-2222-4222-8222-222222222222",
  jobId = "33333333-3333-4333-8333-333333333333",
  conv = "44444444-4444-4444-8444-444444444444",
  requestId = "55555555-5555-4555-8555-555555555555";
const user: Identity = {
  id,
  email: "test@example.com",
  aal: "aal2",
  iat: Math.floor(Date.now() / 1000),
  claims: {},
  admin: false,
};
function app(identity: Identity | null = user) {
  const a = new Hono<Bindings>();
  a.use("*", async (c, next) => {
    if (identity) c.set("identity", identity);
    await next();
  });
  a.route("/api/studio", media);
  return a;
}
function config() {
  return {
    image: { model: "gpt-image-1", worstCaseUsd: 1 },
    video: {
      model: "veo-3.1-generate-preview",
      worstCaseUsd: 8,
      durationSeconds: 8,
    },
  };
}
async function fixture() {
  const { db, sqlite } = database();

  const env = { DB: db, APP_ORIGIN: "https://nexora.test" } as MediaEnv;
  for (const uid of [id, other])
    await db
      .prepare("INSERT INTO users(id,email) VALUES(?,?)")
      .bind(uid, uid + "@example.test")
      .run();
  await db
    .prepare(
      "INSERT INTO conversations(id,user_id,title,created_at,updated_at) VALUES(?,?,?,?,?)",
    )
    .bind(
      conv,
      other,
      "media",
      new Date().toISOString(),
      new Date().toISOString(),
    )
    .run();
  await db
    .prepare(
      "INSERT INTO requests(id,user_id,conversation_id,provider,model,reserved_usd,charged_usd,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
    )
    .bind(
      requestId,
      other,
      conv,
      "openai",
      "gpt-image-1",
      1,
      1,
      new Date().toISOString(),
      new Date().toISOString(),
    )
    .run();
  await db
    .prepare(
      "INSERT INTO studio_jobs(id,user_id,request_id,conversation_id,kind,provider,model,status,max_bytes,created_at,updated_at) VALUES(?,?,?,?,'image','openai','gpt-image-1','complete',1000000,?,?)",
    )
    .bind(
      jobId,
      other,
      requestId,
      conv,
      new Date().toISOString(),
      new Date().toISOString(),
    )
    .run();
  return env;
}
describe("real media protocol configuration and security (no live generation)", () => {
  it("requires positive explicit prices and bounded media storage limits", () => {
    expect(
      studioConfig({ STUDIO_CONFIG_JSON: JSON.stringify(config()) } as MediaEnv)
        ?.video?.durationSeconds,
    ).toBe(8);
    expect(
      studioConfig({
        STUDIO_CONFIG_JSON: JSON.stringify({
          image: { model: "gpt-image-1", worstCaseUsd: 0 },
        }),
      } as MediaEnv),
    ).toBeNull();
    expect(
      studioConfig({
        STUDIO_CONFIG_JSON: JSON.stringify({
          video: { model: "veo-3", worstCaseUsd: 1, maxBytes: 1e9 },
        }),
      } as MediaEnv),
    ).toBeNull();
  });
  it("uses one bounded OpenAI PNG and official Veo REST payloads", () => {
    expect(imagePayload("gpt-image-1", "Draw")).toEqual({
      model: "gpt-image-1",
      prompt: "Draw",
      n: 1,
      size: "1024x1024",
      quality: "low",
      output_format: "png",
    });
    expect(videoPayload("A scene", 8)).toEqual({
      instances: [{ prompt: "A scene" }],
      parameters: {
        sampleCount: 1,
        aspectRatio: "16:9",
        resolution: "720p",
        durationSeconds: 8,
      },
    });
  });
  it("allows only operation identifiers tied to the configured model", () => {
    expect(operationURL("models/veo-3/operations/abc123", "veo-3")).toBe(
      "https://generativelanguage.googleapis.com/v1beta/models/veo-3/operations/abc123",
    );
    expect(() => operationURL("models/other/operations/id", "veo-3")).toThrow();
    expect(() =>
      operationURL("https://evil.test/operations/id", "veo-3"),
    ).toThrow();
    expect(() => operationURL("operations/../files/id", "veo-3")).toThrow();
  });
  it("never downloads arbitrary URLs or sends keys through URL parameters", () => {
    expect(
      checkedVideoURL(
        "https://generativelanguage.googleapis.com/v1beta/files/video-id:download?alt=media",
      ).hostname,
    ).toBe("generativelanguage.googleapis.com");
    expect(
      checkedVideoURL("https://storage.googleapis.com/signed/video.mp4", false)
        .hostname,
    ).toBe("storage.googleapis.com");
    for (const url of [
      "http://generativelanguage.googleapis.com/v1beta/files/id",
      "https://evil.test/video.mp4",
      "https://generativelanguage.googleapis.com.evil.test/v1beta/files/id",
      "https://user:password@generativelanguage.googleapis.com/v1beta/files/id",
      "https://generativelanguage.googleapis.com/v1beta/files/id?key=private",
    ])
      expect(() => checkedVideoURL(url)).toThrow();
  });
  it("validates bounded PNG bytes rather than trusting base64 labels", () => {
    const signature = btoa(
      String.fromCharCode(137, 80, 78, 71, 13, 10, 26, 10),
    );
    expect(decodePNG(signature, 100)).toHaveLength(8);
    expect(() => decodePNG(btoa("<script>"), 100)).toThrow();
    expect(() => decodePNG(signature, 4)).toThrow();
  });
  it("fails closed before calling a provider when config or R2 is missing", async () => {
    const env = await fixture();
    const spy = vi.spyOn(globalThis, "fetch");
    try {
      const a = app();
      let response = await a.request(
        "https://nexora.test/api/studio/images",
        { method: "POST" },
        env,
      );
      expect(response.status).toBe(503);
      expect(((await response.json()) as any).error).toBe(
        "IMAGE_GENERATION_NOT_CONFIGURED",
      );
      env.STUDIO_CONFIG_JSON = JSON.stringify(config());
      response = await a.request(
        "https://nexora.test/api/studio/videos",
        { method: "POST" },
        env,
      );
      expect(response.status).toBe(503);
      expect(((await response.json()) as any).error).toBe(
        "MEDIA_STORAGE_NOT_CONFIGURED",
      );
      expect(spy).not.toHaveBeenCalled();
    } finally {
      spy.mockRestore();
    }
  });
  it("requires MFA independently and never lists another user’s media", async () => {
    const env = await fixture();
    expect(
      (
        await app(null).request(
          "https://nexora.test/api/studio/config",
          {},
          env,
        )
      ).status,
    ).toBe(401);
    expect(
      (
        await app({ ...user, aal: "aal1" }).request(
          "https://nexora.test/api/studio/config",
          {},
          env,
        )
      ).status,
    ).toBe(403);
    const response = await app().request(
      "https://nexora.test/api/studio/jobs",
      {},
      env,
    );
    expect(await response.json()).toEqual({ jobs: [] });
    expect(
      (
        await app().request(
          "https://nexora.test/api/studio/jobs/" + jobId + "/artifact",
          {},
          env,
        )
      ).status,
    ).toBe(404);
    expect(
      (
        await app().request(
          "https://nexora.test/api/studio/jobs/" + jobId,
          { method: "DELETE" },
          env,
        )
      ).status,
    ).toBe(404);
  });
});
