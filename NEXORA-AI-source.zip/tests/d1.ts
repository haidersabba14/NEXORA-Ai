// Test-only adapter: run production SQL against real SQLite, never in production.
import { DatabaseSync } from "node:sqlite";
import { readFileSync, readdirSync } from "node:fs";
export function database() {
  const sqlite = new DatabaseSync(":memory:");
  for (const name of readdirSync("worker/migrations")
    .filter((n) => n.endsWith(".sql"))
    .sort())
    sqlite.exec(readFileSync("worker/migrations/" + name, "utf8"));
  const db = {
    prepare(sql: string) {
      const query = sqlite.prepare(sql);
      let args: any[] = [];
      const stmt = {
        bind(...values: any[]) {
          args = values;
          return stmt;
        },
        async first(column?: string) {
          const row = query.get(...args) as any;
          return column ? row?.[column] : row || null;
        },
        async all() {
          return { results: query.all(...args), success: true };
        },
        async run() {
          const info = query.run(...args);
          return {
            success: true,
            meta: {
              changes: Number(info.changes),
              last_row_id: Number(info.lastInsertRowid),
            },
          };
        },
      };
      return stmt;
    },
    async batch(statements: any[]) {
      sqlite.exec("BEGIN");
      try {
        const results = [];
        for (const statement of statements) results.push(await statement.run());
        sqlite.exec("COMMIT");
        return results;
      } catch (e) {
        sqlite.exec("ROLLBACK");
        throw e;
      }
    },
  };
  return { db: db as unknown as D1Database, sqlite };
}
