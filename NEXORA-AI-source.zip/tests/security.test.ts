import {
  describe,
  it,
  expect,
  beforeAll,
  afterAll,
  beforeEach,
  vi,
} from "vitest";
import { generateKeyPair, exportJWK, SignJWT } from "jose";
import { createServer, type Server } from "node:http";
import app from "../worker/src/index";
import { database } from "./d1";
import { reserve, reservationCost } from "../worker/src/quota";
import type { Env, Identity } from "../worker/src/types";
let server: Server, port: number, privateKey: CryptoKey, jwk: any;
const id = "11111111-1111-4111-8111-111111111111",
  other = "22222222-2222-4222-8222-222222222222",
  conv = "33333333-3333-4333-8333-333333333333";
const identity: Identity = {
  id,
  email: "test@example.com",
  aal: "aal2",
  iat: Math.floor(Date.now() / 1000),
  claims: {},
  admin: false,
};
let env: Env;
let authUser: any;
let logoutStatus = 204;
let factorDeletes = 0;
beforeAll(async () => {
  const keys = await generateKeyPair("ES256");
  privateKey = keys.privateKey;
  jwk = {
    ...(await exportJWK(keys.publicKey)),
    kid: "test-key",
    alg: "ES256",
    use: "sig",
  };
  server = createServer((req, res) => {
    res.setHeader("Content-Type", "application/json");
    if (req.url === "/auth/v1/.well-known/jwks.json")
      res.end(JSON.stringify({ keys: [jwk] }));
    else if (req.url === "/auth/v1/user") res.end(JSON.stringify(authUser));
    else if (req.url === "/auth/v1/logout?scope=global") {
      res.statusCode = logoutStatus;
      res.end();
    } else if (req.url === `/auth/v1/admin/users/${id}/factors`)
      res.end(
        JSON.stringify({
          factors: [{ id: "test-factor", factor_type: "totp" }],
        }),
      );
    else if (
      req.url === `/auth/v1/admin/users/${id}/factors/test-factor` &&
      req.method === "DELETE"
    ) {
      factorDeletes++;
      res.statusCode = 204;
      res.end();
    } else {
      res.statusCode = 404;
      res.end("{}");
    }
  });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  port = (server.address() as any).port;
});
afterAll(() => server.close());
beforeEach(async () => {
  logoutStatus = 204;
  factorDeletes = 0;
  env = {
    DB: database().db,
    ASSETS: { fetch: async () => new Response("asset") } as unknown as Fetcher,
    APP_ORIGIN: "https://nexora.test",
    SUPABASE_URL: `http://127.0.0.1:${port}`,
    SUPABASE_ANON_KEY: "test-public-key",
    GLOBAL_DAILY_USD: "1",
    GLOBAL_MONTHLY_USD: "10",
  };
  authUser = {
    id,
    email: "test@example.com",
    email_confirmed_at: "2026-01-01",
    app_metadata: {},
    user_metadata: { role: "admin" },
  };
  await env.DB.prepare("INSERT INTO users(id,email) VALUES(?,?)")
    .bind(id, identity.email)
    .run();
  await env.DB.prepare("INSERT INTO users(id,email) VALUES(?,?)")
    .bind(other, "other@example.com")
    .run();
  await env.DB.prepare(
    "INSERT INTO conversations(id,user_id,title,created_at,updated_at) VALUES(?,?,?,?,?)",
  )
    .bind(conv, id, "test", new Date().toISOString(), new Date().toISOString())
    .run();
});
async function token(aal = "aal2", extras: Record<string, unknown> = {}) {
  return new SignJWT({ aal, ...extras })
    .setProtectedHeader({ alg: "ES256", kid: "test-key" })
    .setSubject(id)
    .setIssuer(env.SUPABASE_URL + "/auth/v1")
    .setAudience("authenticated")
    .setIssuedAt()
    .setExpirationTime("5m")
    .sign(privateKey);
}
async function call(
  path: string,
  opts: {
    method?: string;
    body?: unknown;
    token?: string;
    origin?: string;
  } = {},
) {
  return app.request(
    "https://nexora.test/api" + path,
    {
      method: opts.method || "GET",
      headers: {
        "Content-Type": "application/json",
        ...(opts.token ? { Authorization: "Bearer " + opts.token } : {}),
        ...(opts.method ? { Origin: opts.origin || env.APP_ORIGIN } : {}),
      },
      ...(opts.body ? { body: JSON.stringify(opts.body) } : {}),
    },
    env,
  );
}
describe("server authorization with real ES256 verification and SQLite", () => {
  it("rejects direct unauthenticated conversation requests", async () => {
    expect((await call("/conversations")).status).toBe(401);
  });
  it("rejects a forged token", async () => {
    expect((await call("/conversations", { token: "not.a.jwt" })).status).toBe(
      401,
    );
  });
  it("rejects AAL1 data access while allowing MFA bootstrap", async () => {
    const jwt = await token("aal1");
    expect((await call("/conversations", { token: jwt })).status).toBe(403);
    expect((await call("/session", { token: jwt })).status).toBe(200);
  });
  it("accepts valid AAL2 signed sessions", async () => {
    const r = await call("/conversations", { token: await token() });
    expect(r.status).toBe(200);
    expect((await r.json()) as any[]).toHaveLength(1);
  });
  it("rejects invalid audience and expired JWTs", async () => {
    const wrong = await new SignJWT({ aal: "aal2" })
      .setProtectedHeader({ alg: "ES256", kid: "test-key" })
      .setSubject(id)
      .setIssuer(env.SUPABASE_URL + "/auth/v1")
      .setAudience("evil")
      .setIssuedAt()
      .setExpirationTime("1m")
      .sign(privateKey);
    expect((await call("/conversations", { token: wrong })).status).toBe(401);
    const expired = await new SignJWT({ aal: "aal2" })
      .setProtectedHeader({ alg: "ES256", kid: "test-key" })
      .setSubject(id)
      .setIssuer(env.SUPABASE_URL + "/auth/v1")
      .setAudience("authenticated")
      .setIssuedAt()
      .setExpirationTime(Math.floor(Date.now() / 1000) - 10)
      .sign(privateKey);
    expect((await call("/conversations", { token: expired })).status).toBe(401);
  });
  it("rejects unconfirmed email", async () => {
    authUser.email_confirmed_at = null;
    expect((await call("/session", { token: await token() })).status).toBe(403);
  });
  it("prevents cross-user read and delete", async () => {
    await env.DB.prepare("UPDATE conversations SET user_id=? WHERE id=?")
      .bind(other, conv)
      .run();
    const jwt = await token();
    expect((await call("/conversations/" + conv, { token: jwt })).status).toBe(
      404,
    );
    expect(
      (await call("/conversations/" + conv, { method: "DELETE", token: jwt }))
        .status,
    ).toBe(404);
  });
  it("rejects client-editable admin metadata", async () => {
    expect(
      (await call("/admin/overview", { token: await token() })).status,
    ).toBe(403);
  });
  it("accepts server-controlled admin metadata", async () => {
    authUser.app_metadata.role = "admin";
    expect(
      (await call("/admin/overview", { token: await token() })).status,
    ).toBe(200);
  });
  it("revokes sessions and disables accounts on the backend", async () => {
    const jwt = await token();
    await env.DB.prepare("UPDATE users SET revoked_before=? WHERE id=?")
      .bind(Math.floor(Date.now() / 1000) + 1, id)
      .run();
    expect((await call("/conversations", { token: jwt })).status).toBe(401);
    await env.DB.prepare(
      "UPDATE users SET revoked_before=0,disabled=1 WHERE id=?",
    )
      .bind(id)
      .run();
    expect((await call("/conversations", { token: jwt })).status).toBe(403);
  });
  it("rejects cross-origin mutations before authentication", async () => {
    expect(
      (
        await call("/conversations", {
          method: "POST",
          origin: "https://evil.test",
          body: { title: "test" },
          token: await token(),
        })
      ).status,
    ).toBe(403);
  });
  it("treats SQL injection as text", async () => {
    const jwt = await token();
    const created = await call("/conversations", {
      method: "POST",
      token: jwt,
      body: { title: "'); DROP TABLE users;--" },
    });
    expect(created.status).toBe(201);
    expect(
      await env.DB.prepare("SELECT COUNT(*) count FROM users").first("count"),
    ).toBe(2);
  });
  it("never exposes secrets through public config", async () => {
    env.OPENAI_API_KEY = "TEST_SECRET_NOT_REAL";
    env.SUPABASE_SERVICE_ROLE_KEY = "PRIVATE_TEST_KEY";
    const r = await call("/config");
    const text = await r.text();
    expect(text).not.toContain("TEST_SECRET_NOT_REAL");
    expect(text).not.toContain("PRIVATE_TEST_KEY");
  });
  it("enforces request validation and payload bounds", async () => {
    expect(
      (
        await call("/conversations", {
          method: "POST",
          token: await token(),
          body: { title: "" },
        })
      ).status,
    ).toBe(400);
    const r = await app.request(
      "https://nexora.test/api/conversations",
      {
        method: "POST",
        headers: {
          Origin: env.APP_ORIGIN,
          "Content-Type": "application/json",
          "Content-Length": "200000",
        },
        body: "{}",
      },
      env,
    );
    expect(r.status).toBe(413);
  });
  it("requires security headers on API responses", async () => {
    const r = await call("/health");
    expect(r.headers.get("X-Content-Type-Options")).toBe("nosniff");
    expect(r.headers.get("Content-Security-Policy")).toContain(
      "object-src 'none'",
    );
  });
});
describe("atomic quotas and accounting", () => {
  const cfg = { model: "test-model", input: 1, output: 2 };
  it("defaults to disabled spend without explicit budget", async () => {
    env.GLOBAL_DAILY_USD = "0";
    await expect(
      reserve(env, identity, conv, "openai", cfg, 0.01),
    ).rejects.toThrow("BUDGET_NOT_ENABLED");
  });
  it("serializes concurrent reservations at the budget boundary", async () => {
    env.GLOBAL_DAILY_USD = ".1";
    const results = await Promise.allSettled([
      reserve(env, identity, conv, "openai", cfg, 0.06),
      reserve(env, identity, conv, "gemini", cfg, 0.06),
    ]);
    expect(results.filter((x) => x.status === "fulfilled")).toHaveLength(1);
    expect(
      (
        (await env.DB.prepare(
          "SELECT SUM(charged_usd) total FROM requests",
        ).first()) as any
      ).total,
    ).toBeCloseTo(0.06);
  });
  it("retains billing when conversation history is deleted", async () => {
    const r = await reserve(env, identity, conv, "openai", cfg, 0.01);
    await env.DB.prepare("UPDATE requests SET status='complete' WHERE id=?")
      .bind(r)
      .run();
    await env.DB.prepare("DELETE FROM conversations WHERE id=?")
      .bind(conv)
      .run();
    const row = (await env.DB.prepare(
      "SELECT charged_usd,conversation_id FROM requests",
    ).first()) as any;
    expect(row.charged_usd).toBe(0.01);
    expect(row.conversation_id).toBeNull();
  });
  it("enforces per-user and concurrency limits", async () => {
    await env.DB.prepare("UPDATE users SET daily_usd=.01 WHERE id=?")
      .bind(id)
      .run();
    await expect(
      reserve(env, identity, conv, "openai", cfg, 0.02),
    ).rejects.toThrow("QUOTA_OR_CONCURRENCY_LIMIT");
    await env.DB.prepare("UPDATE users SET daily_usd=1 WHERE id=?")
      .bind(id)
      .run();
    for (let i = 0; i < 4; i++)
      await reserve(env, identity, conv, "openai", cfg, 0.001);
    await expect(
      reserve(env, identity, conv, "openai", cfg, 0.001),
    ).rejects.toThrow("QUOTA_OR_CONCURRENCY_LIMIT");
  });
  it("reserves UTF-8 input and maximum output conservatively", () => {
    expect(reservationCost([{ content: "مرحبا" }], cfg)).toBeGreaterThan(
      (4096 + 4096) / 1e6,
    );
  });
  it("prevents comparison grant replay and cross-user use", async () => {
    const hash = Array.from(
      new Uint8Array(
        await crypto.subtle.digest(
          "SHA-256",
          new TextEncoder().encode("grant-value"),
        ),
      ),
      (b) => b.toString(16).padStart(2, "0"),
    ).join("");
    await env.DB.prepare(
      "INSERT INTO comparison_grants(hash,user_id,provider,expires_at) VALUES(?,?,?,?)",
    )
      .bind(hash, other, "openai", Math.floor(Date.now() / 1000) + 60)
      .run();
    const r = await call("/chat", {
      method: "POST",
      token: await token(),
      body: {
        conversationId: conv,
        provider: "openai",
        message: "Hi",
        turnstileToken: "grant:grant-value",
      },
    });
    expect(r.status).toBe(403);
    expect(((await r.json()) as any).error).toBe("INVALID_COMPARISON_GRANT");
  });
});

describe("session invalidation and recovery protocol", () => {
  it("invalidates old data tokens after server global logout", async () => {
    const jwt = await token();
    expect(
      (await call("/session/revoke", { method: "POST", token: jwt, body: {} }))
        .status,
    ).toBe(200);
    expect((await call("/conversations", { token: jwt })).status).toBe(401);
  });
  it("requires AAL2 to issue codes and fresh password plus one-use code for recovery", async () => {
    env.RECOVERY_PEPPER = "test-only-pepper-at-least-32-characters";
    env.SUPABASE_SERVICE_ROLE_KEY = "test-only-service-key";
    expect(
      (
        await call("/recovery/codes", {
          method: "POST",
          token: await token("aal1"),
          body: {},
        })
      ).status,
    ).toBe(403);
    const issued = await call("/recovery/codes", {
      method: "POST",
      token: await token(),
      body: {},
    });
    expect(issued.status).toBe(200);
    const { codes } = (await issued.json()) as any;
    expect(codes).toHaveLength(10);
    const hashes = await env.DB.prepare(
      "SELECT hash FROM recovery_codes",
    ).all();
    expect(JSON.stringify(hashes)).not.toContain(codes[0]);
    const payload = { code: codes[0] };
    expect(
      (
        await call("/recovery/redeem", {
          method: "POST",
          token: await token("aal1"),
          body: payload,
        })
      ).status,
    ).toBe(403);
    const jwt = await token("aal1", {
      amr: [{ method: "password", timestamp: Math.floor(Date.now() / 1000) }],
    });
    expect(
      (
        await call("/recovery/redeem", {
          method: "POST",
          token: jwt,
          body: payload,
        })
      ).status,
    ).toBe(200);
    expect(
      await env.DB.prepare("SELECT disabled FROM users WHERE id=?")
        .bind(id)
        .first("disabled"),
    ).toBe(0);
    expect(
      await env.DB.prepare(
        "SELECT COUNT(*) count FROM recovery_codes WHERE used=1",
      ).first("count"),
    ).toBe(1);
    await env.DB.prepare("UPDATE users SET revoked_before=0 WHERE id=?")
      .bind(id)
      .run();
    expect(
      (
        await call("/recovery/redeem", {
          method: "POST",
          token: jwt,
          body: payload,
        })
      ).status,
    ).toBe(403);
  });
});

describe("security failure paths", () => {
  it("requires expiry and issued-at claims and rejects future issued-at", async () => {
    const base = () =>
      new SignJWT({ aal: "aal2" })
        .setProtectedHeader({ alg: "ES256", kid: "test-key" })
        .setSubject(id)
        .setIssuer(env.SUPABASE_URL + "/auth/v1")
        .setAudience("authenticated");
    const noExpiry = await base().setIssuedAt().sign(privateKey);
    const noIssuedAt = await base().setExpirationTime("5m").sign(privateKey);
    const future = await base()
      .setIssuedAt(Math.floor(Date.now() / 1000) + 300)
      .setExpirationTime("10m")
      .sign(privateKey);
    for (const jwt of [noExpiry, noIssuedAt, future])
      expect((await call("/conversations", { token: jwt })).status).toBe(401);
  });
  it("revokes old AAL2 tokens before recovery mutations even when provider logout fails", async () => {
    env.RECOVERY_PEPPER = "test-only-pepper-at-least-32-characters";
    env.SUPABASE_SERVICE_ROLE_KEY = "test-only-service-key";
    const oldToken = await token();
    const issued = await call("/recovery/codes", {
      method: "POST",
      token: oldToken,
      body: {},
    });
    const { codes } = (await issued.json()) as any;
    logoutStatus = 503;
    const jwt = await token("aal1", {
      amr: [{ method: "password", timestamp: Math.floor(Date.now() / 1000) }],
    });
    const response = await call("/recovery/redeem", {
      method: "POST",
      token: jwt,
      body: { code: codes[0] },
    });
    expect(response.status).toBe(503);
    expect(factorDeletes).toBe(1);
    expect((await call("/conversations", { token: oldToken })).status).toBe(
      403,
    );
    expect(
      await env.DB.prepare("SELECT disabled FROM users WHERE id=?")
        .bind(id)
        .first("disabled"),
    ).toBe(1);
    // Model an old refresh token issuing a later JWT: its new iat must not
    // bypass the recovery lock after the global logout failure.
    const refreshed = await new SignJWT({ aal: "aal2" })
      .setProtectedHeader({ alg: "ES256", kid: "test-key" })
      .setSubject(id)
      .setIssuer(env.SUPABASE_URL + "/auth/v1")
      .setAudience("authenticated")
      .setIssuedAt(Math.floor(Date.now() / 1000) + 1)
      .setExpirationTime("5m")
      .sign(privateKey);
    const denied = await call("/conversations", { token: refreshed });
    expect(denied.status).toBe(403);
    expect(((await denied.json()) as any).error).toBe("ACCOUNT_DISABLED");
    expect(
      await env.DB.prepare(
        "SELECT COUNT(*) count FROM recovery_codes WHERE used=1",
      ).first("count"),
    ).toBe(1);
  });
  it("does not accept a future password event as recovery reauthentication", async () => {
    env.RECOVERY_PEPPER = "test-only-pepper-at-least-32-characters";
    env.SUPABASE_SERVICE_ROLE_KEY = "test-only-service-key";
    const issued = await call("/recovery/codes", {
      method: "POST",
      token: await token(),
      body: {},
    });
    const { codes } = (await issued.json()) as any;
    const jwt = await token("aal1", {
      amr: [
        { method: "password", timestamp: Math.floor(Date.now() / 1000) + 3600 },
      ],
    });
    expect(
      (
        await call("/recovery/redeem", {
          method: "POST",
          token: jwt,
          body: { code: codes[0] },
        })
      ).status,
    ).toBe(403);
    expect(
      await env.DB.prepare(
        "SELECT COUNT(*) count FROM recovery_codes WHERE used=1",
      ).first("count"),
    ).toBe(0);
  });
  it("keeps cancellation accounting alive through the Worker execution context", async () => {
    const model = { model: "test-model", input: 1, output: 2 };
    env.MODEL_CONFIG_JSON = JSON.stringify({
      openai: model,
      gemini: model,
      deepseek: model,
      anthropic: model,
    });
    env.OPENAI_API_KEY = "test-not-a-real-key";
    const value = "test-stream-grant";
    const digest = Array.from(
      new Uint8Array(
        await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)),
      ),
      (b) => b.toString(16).padStart(2, "0"),
    ).join("");
    await env.DB.prepare(
      "INSERT INTO comparison_grants(hash,user_id,provider,expires_at) VALUES(?,?,?,?)",
    )
      .bind(digest, id, "openai", Math.floor(Date.now() / 1000) + 60)
      .run();
    const original = globalThis.fetch.bind(globalThis);
    const fetchSpy = vi
      .spyOn(globalThis, "fetch")
      .mockImplementation(async (input, init) => {
        if (String(input) === "https://api.openai.com/v1/responses") {
          return new Response(
            new ReadableStream({
              start(controller) {
                const signal = init?.signal;
                if (signal?.aborted) controller.error(new Error("aborted"));
                else
                  signal?.addEventListener(
                    "abort",
                    () => controller.error(new Error("aborted")),
                    { once: true },
                  );
              },
            }),
            { headers: { "Content-Type": "text/event-stream" } },
          );
        }
        return original(input, init);
      });
    const waits: Promise<unknown>[] = [];
    try {
      const response = await app.fetch(
        new Request("https://nexora.test/api/chat", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Origin: env.APP_ORIGIN,
            Authorization: "Bearer " + (await token()),
          },
          body: JSON.stringify({
            conversationId: conv,
            provider: "openai",
            message: "Hello",
            turnstileToken: "grant:" + value,
          }),
        }),
        env,
        {
          waitUntil(promise) {
            waits.push(promise);
          },
          passThroughOnException() {},
        } as ExecutionContext,
      );
      expect(response.status).toBe(200);
      const reader = response.body!.getReader();
      await reader.read();
      await reader.cancel();
      await Promise.all(waits);
      expect(waits).toHaveLength(1);
      const request = (await env.DB.prepare(
        "SELECT status,charged_usd,reserved_usd FROM requests",
      ).first()) as any;
      expect(request.status).toBe("cancelled");
      expect(request.charged_usd).toBe(request.reserved_usd);
      const assistant = (await env.DB.prepare(
        "SELECT status FROM messages WHERE role='assistant'",
      ).first()) as any;
      expect(assistant.status).toBe("cancelled");
    } finally {
      fetchSpy.mockRestore();
    }
  });
});

describe("memory privacy and expanded route guards", () => {
  it("starts memory off, isolates preferences and supports deletion", async () => {
    const jwt = await token();
    const initial = await call("/memory", { token: jwt });
    expect(((await initial.json()) as any).enabled).toBe(0);
    expect(
      (
        await call("/memory", {
          method: "PUT",
          token: jwt,
          body: { enabled: true, content: "Arabic concise answers" },
        })
      ).status,
    ).toBe(200);
    expect(
      ((await (await call("/memory", { token: jwt })).json()) as any).content,
    ).toBe("Arabic concise answers");
    await env.DB.prepare(
      "INSERT INTO memory_settings(user_id,enabled,content,updated_at) VALUES(?,1,?,?)",
    )
      .bind(other, "PRIVATE_OTHER", "2026-01-01")
      .run();
    expect(await (await call("/memory", { token: jwt })).text()).not.toContain(
      "PRIVATE_OTHER",
    );
    await call("/memory", { method: "DELETE", token: jwt, body: {} });
    expect(
      ((await (await call("/memory", { token: jwt })).json()) as any).enabled,
    ).toBe(0);
  });
  it("requires MFA on agents, studio, memory and schedules APIs", async () => {
    const jwt = await token("aal1");
    for (const route of [
      "/agents/runs",
      "/studio/jobs",
      "/memory",
      "/schedules",
    ])
      expect((await call(route, { token: jwt })).status).toBe(403);
  });
});

describe("atomic recovery lock", () => {
  async function prepareRecovery() {
    env.RECOVERY_PEPPER = "test-only-pepper-at-least-32-characters";
    env.SUPABASE_SERVICE_ROLE_KEY = "test-only-service-key";
    const issued = await call("/recovery/codes", {
      method: "POST",
      token: await token(),
      body: {},
    });
    const { codes } = (await issued.json()) as any;
    const jwt = await token("aal1", {
      amr: [{ method: "password", timestamp: Math.floor(Date.now() / 1000) }],
    });
    return { codes, jwt };
  }
  it("does not disable an account or consume a code when the submitted code is invalid", async () => {
    const { jwt } = await prepareRecovery();
    expect(
      (
        await call("/recovery/redeem", {
          method: "POST",
          token: jwt,
          body: { code: "000000000000000000000000" },
        })
      ).status,
    ).toBe(403);
    expect(
      await env.DB.prepare("SELECT disabled FROM users WHERE id=?")
        .bind(id)
        .first("disabled"),
    ).toBe(0);
    expect(
      await env.DB.prepare(
        "SELECT COUNT(*) count FROM recovery_codes WHERE used=1",
      ).first("count"),
    ).toBe(0);
    expect(factorDeletes).toBe(0);
  });
  it("keeps the account locked when logout returns an ambiguous 401", async () => {
    const { codes, jwt } = await prepareRecovery();
    logoutStatus = 401;
    expect(
      (
        await call("/recovery/redeem", {
          method: "POST",
          token: jwt,
          body: { code: codes[0] },
        })
      ).status,
    ).toBe(503);
    expect(
      await env.DB.prepare("SELECT disabled FROM users WHERE id=?")
        .bind(id)
        .first("disabled"),
    ).toBe(1);
    expect(factorDeletes).toBe(1);
  });
});
