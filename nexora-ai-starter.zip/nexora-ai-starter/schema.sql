-- Optional Supabase schema starter. Run in Supabase SQL Editor only if you need cloud persistence.
-- This creates per-user chat records. Row Level Security prevents users from reading each other's rows.
create table if not exists public.nexora_chats (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'محادثة جديدة',
  messages jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.nexora_chats enable row level security;
create policy "Users can read their own chats"
on public.nexora_chats for select to authenticated using (auth.uid() = user_id);
create policy "Users can create their own chats"
on public.nexora_chats for insert to authenticated with check (auth.uid() = user_id);
create policy "Users can update their own chats"
on public.nexora_chats for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users can delete their own chats"
on public.nexora_chats for delete to authenticated using (auth.uid() = user_id);
