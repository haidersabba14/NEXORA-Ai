/**
 * NEXORA AI Cloudflare Worker starter.
 * Configure AI_API_KEY and AI_API_URL using Wrangler secrets/dashboard.
 * Never place secrets in index.html.
 *
 * Required secret:
 *   AI_API_KEY = your provider's API key
 * Optional variable:
 *   AI_API_URL = provider-compatible chat completions endpoint
 */
const corsHeaders = {
  "Access-Control-Allow-Origin": "*", // Replace with your GitHub Pages origin in production.
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
  "Content-Type": "application/json; charset=utf-8",
};
function json(data, status=200) {
  return new Response(JSON.stringify(data), {status, headers:corsHeaders});
}
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null, {headers:corsHeaders});
    if (url.pathname === "/api/health" && request.method === "GET") {
      return json({ok:true,service:"NEXORA AI backend",aiConfigured:Boolean(env.AI_API_KEY && env.AI_API_URL)});
    }
    if (url.pathname === "/api/chat" && request.method === "POST") {
      let body;
      try { body = await request.json(); } catch { return json({error:"Invalid JSON"},400); }
      const message = typeof body.message === "string" ? body.message.trim() : "";
      if (!message) return json({error:"message is required"},400);
      if (message.length > 12000) return json({error:"Message is too long"},413);
      if (!env.AI_API_KEY || !env.AI_API_URL) {
        return json({error:"AI provider is not configured. Add AI_API_KEY and AI_API_URL as Worker secrets/variables."},503);
      }
      try {
        const upstream = await fetch(env.AI_API_URL, {
          method:"POST",
          headers:{"Authorization":`Bearer ${env.AI_API_KEY}`,"Content-Type":"application/json"},
          body:JSON.stringify({
            model: env.AI_MODEL || "gpt-4o-mini",
            messages:[{role:"system",content:"You are NEXORA AI, a helpful assistant. Reply in the user's language."},{role:"user",content:message}],
            temperature:0.7
          })
        });
        const data = await upstream.json();
        if (!upstream.ok) return json({error:"AI provider request failed",status:upstream.status,details:data?.error?.message || "Provider error"},502);
        const reply = data?.choices?.[0]?.message?.content;
        if (!reply) return json({error:"Unexpected AI provider response format"},502);
        return json({reply});
      } catch (e) {
        return json({error:"Could not reach AI provider"},502);
      }
    }
    return json({error:"Not found"},404);
  }
};